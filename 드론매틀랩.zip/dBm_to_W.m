function [W] = dBm_to_W(dBm)
W = 10^(dBm/10-3); % dBm = 10 * log(W/10^3);
end

