x = 0:0.5:10;
y = 0:0.5:10;
x_ = 0:1:20;
y_ = 0:1:20;
[X,Y]= meshgrid(x,y);
Z = zeros(21,21)+5;
Z = Z + (X-5).*5.*exp(-(X-8).^2-(Y-8).^2)-sqrt((X).^2+(Y).^2)+20.*exp(-(X-5).^2-(Y-4).^2)...
    + sin(2*X) + sin(2*Y)+10;
a=contourf(x_,y_,Z);
load('MyColormaps','mycmap');
colormap(mycmap);
hold on;
axis([0 20 0 20 -5 40]);

i=1;
x_drone(i).in = [0 1];
y_drone(i).in = [1 0];
[X,map,alpha] = imread('plane.png');
drone_(i).in = image(x_drone(i).in,y_drone(i).in,X,'AlphaData',alpha);
% saveplotlyfig(figure, 'your_image_filename.png')