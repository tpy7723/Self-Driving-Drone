x_r=1;
y_r=2;
r_r=5;
th=0:pi/100:2*pi;
a_r=r_r*cos(th)+x_r;
b_r=r_r*sin(th)+y_r;
plot(a,b);
