function [y] = func_dijk(pathloss, penalty)
num = length(pathloss);
num_UAV = num-1;
start = num;
count = 1;

dist(1:num) = 0;
dist(start) = 1;

visit(1:num) = 0;
visit(start) = 1;

pathloss_max(1:num) = 0;
pathloss_max(start) = 1;
            
value = pathloss.*penalty;

while(count < num)
    max_val = 0;
    max_index = 0;
    for order = 1:num
       if visit(order) == 0 && dist(order) < dist(start) * value(order, start)
           dist(order) = dist(start) * value(start, order);
           pathloss_max(order) = pathloss_max(start) * pathloss(start, order);
       end
       if visit(order) == 0 && max_val < dist(order)
           max_val = dist(order);
           max_index = order;
       end
    end
    
    start = max_index;
    visit(start) = 1;
    count = count + 1;
end

y(1, 1:num_UAV) = dist(1:num_UAV); % pathloss*penalty
y(2, 1:num_UAV) = pathloss_max(1:num_UAV); % pathloss��
end