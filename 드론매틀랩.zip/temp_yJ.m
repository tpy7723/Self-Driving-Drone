
pos = load('location.mat');
f_loc = fopen('../2���/f_loc.txt','w+'); %������ ���� w+
% for f_iter = 1 : 20
%     fprintf(f_loc,'{');
%     for num = 1 : 3
%         fprintf(f_loc,'"x%d":%f,',2*num-1,pos.pos(f_iter,2*num-1));
%         fprintf(f_loc,'"y%d":%f',2*num,pos.pos(f_iter,2*num));
%         if num~=3
%             fprintf(f_loc,',');
%         end
%     end



for f_iter = 1 : 20
    fprintf(f_loc,'{');
    for f_num = 1 : 3
        fprintf(f_loc,'"x%d":%f,',2*f_num-1,pos.pos(f_iter,2*f_num-1));
        fprintf(f_loc,'"y%d":%f',2*f_num,pos.pos(f_iter,2*f_num));
        if f_num~=3
            fprintf(f_loc,',');
        end
    end
    fprintf(f_loc,'}\n');
end