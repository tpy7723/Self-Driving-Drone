function [output] = select_distance(Gr,Gt,lamda,Pt,Pmin)

d= sqrt(Gr*Gt*lamda^2*Pt/(Pmin*(4*pi)^2));

output = d;
end

