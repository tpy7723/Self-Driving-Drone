function [count,UAV_connect]=func_count(Distance, cr)
for order1 = 1:length(Distance)
    for order2 = 1:length(Distance)
        if Distance(order1, order2) <= cr
            Connect(order1, order2) = 1;
        else
            Connect(order1, order2) = 0;
        end
    end
end% ���� ���ɿ��� üũ
UAV_connect = Connect;
sink = length(Distance);
num_UAV = length(Distance) - 1;
count(1:num_UAV) = 0; 
for order = 1:num_UAV
    if Connect(order, sink) == 1
        count(order) = 1; %�������� ���� ������ UAV�� 1
    end
end

order1 = 1;
while(order1 <= num_UAV)
    for order2 = 1:num_UAV
        if Connect(order1, order2) == 1 && count(order1) == 1
            if count(order2) == 0
                count(order2) = 1;
                order1 = 1;
            end
        end
    end
    order1 = order1 + 1;
end

count;