function varargout = testGUI_3D(varargin)
% TESTGUI_3D MATLAB code for testGUI_3D.fig
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @testGUI_3D_OpeningFcn, ...
    'gui_OutputFcn',  @testGUI_3D_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before testGUI_3D is made visible.
function testGUI_3D_OpeningFcn(hObject, eventdata, handles, varargin)
global  sensor_type_text num_sensor flag_i ground Z UAV_Color lineColor r height drone_d a b num_UAV pl range_d line_
% Choose default command line output for testGUI_3D
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
cla reset;

% UAV_Color = ["[1 0.8 0.8]";"[0.8 0.8 1]";"[0.8 1 0.8]";"[1 1 0.8]";"[0.87 0.55 0.14]"];
% lineColor = ["green";"red";"blue";"magenta";"[0.87 0.55 0.14]"];
UAV_Color = ["red";"red";"red";"red";"red"];
lineColor = ["black";"black";"black";"black";"black"];

flag_i=0;
flag_d = 0;
flag  = 0;
axes(handles.threeD);
x = 0:0.5:10;
y = 0:0.5:10;
x_ = 0 : 1 : 20;
y_ = 0 : 1 : 20;
[X,Y]= meshgrid(x,y);
Z = (X-5).*5.*exp(-(X-8).^2-(Y-8).^2)-sqrt((X-2).^2+(Y-2).^2)+10.*2.*exp(-(X-5).^2-(Y-4).^2)...
    + sin(2*X) + sin(2*Y)+10;
% ground = surf(x_,y_,Z);
ground = surf(x_,y_,Z,'EdgeColor','none');
camlight left; lighting phong
load('MyColormaps','mycmap');
colormap(mycmap);
set(handles.threeD,'xgrid','on','ygrid','on','zgrid','on','xlim',[0 20],'ylim',[0 20],'zlim',[-5 40]);
xlabel(handles.threeD,'X�Ÿ�(100m)');
ylabel(handles.threeD,'Y�Ÿ�(100m)');
zlabel(handles.threeD,'Z����(10m)');
title(handles.threeD, '3DTopology & Drone movement');
hold on;
load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp');
[sensor_type, num_sensor] = size(sensor_x_temp);
col = hsv(5);
for i=1:sensor_type
    for j=1: num_sensor
        if i==1
            a = plot3(handles.threeD,sensor_x_temp(i, j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i==2
            b = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 3
            c = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 4
            d = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 5
            e = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j), func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        end
    end
end
rotate3d on

antenna = imread('antenna.jpg');
[droneimage(1).in,m_,png(1).in] = imread('plane_r.png');
[droneimage(2).in,m_,png(2).in] = imread('plane_r.png');
[droneimage(3).in,m_,png(3).in] = imread('plane_r.png');
[droneimage(4).in,m_,png(4).in] = imread('plane_r.png');
[droneimage(5).in,m_,png(5).in] = imread('plane_r.png');

%�̹��� ������
a = zeros(num_UAV);
b = zeros(num_UAV);
for i=1:num_UAV
    x_drone(i).in = [a(i) a(i)+1 ; a(i) a(i)+1];
    y_drone(i).in = [b(i)+1 b(i) ; b(i)+1 b(i)];
end
z_drone = [33 33; 30 30];
x_a = 1; y_a = 1; z_a = 1;
x_antenna = [x_a-0.5 x_a+0.5 ; x_a-0.5 x_a+0.5];
y_antenna = [y_a+0.5 y_a-0.5 ; y_a+0.5 y_a-0.5];
z_antenna = [z_a+2 z_a+2; z_a-1 z_a-1];

% �׷����� �̹��� ǥ��
antenna = surf(x_antenna,y_antenna,z_antenna,'CData',antenna,'FaceColor','texturemap');
for i=1:num_UAV
    drone_d(i).in = surf(x_drone(i).in,y_drone(i).in,z_drone,'CData',droneimage(i).in,'FaceColor','texturemap');
    drone_d(i).in.FaceAlpha ='texturemap';
    drone_d(i).in.EdgeColor = 'none';
    drone_d(i).in.AlphaData =max(droneimage(i).in,[],3) ;
%     alpha(drone_(i).in,.6);
end



% UIWAIT makes testGUI_3D wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = testGUI_3D_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in simulation.
function simulation_Callback(hObject, eventdata, handles)
% hObject    handle to simulation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global maxTime num_UAV drone flag UAV_Color lineColor
flag = flag +1;
if flag > 1
    for i = 1 : num_UAV
        delete (drone(i).in);
    end
end

alpha(.6)

for i = 1 : num_UAV +1
    x_drone(i) = 0;   %# The x data for the image corners
    y_drone(i) = 0;             %# The y data for the image corners
    z_drone(i) = func_Zaxis(x_drone(i),y_drone(i));   %# The z data for the image corners
    if(i == num_UAV+1) break; end;
    drone(i).in = plot3(handles.threeD,x_drone(i), y_drone(i),z_drone(i),'-o','MarkerSize',15,'MarkerEdgeColor',UAV_Color(i),...
        'MarkerFaceColor',UAV_Color(i));
end
grid on
hold on

antenna = plot3(handles.threeD,x_drone(num_UAV+1), y_drone(num_UAV+1),z_drone(num_UAV+1),'-d','MarkerSize',25,'MarkerEdgeColor','yellow',...
    'MarkerFaceColor',[1 1 0]);

lo = load('location_best.mat');%%%%%%%%%%%%%%%%%%%%yj,ps
temp_x = x_drone;
temp_y = y_drone;
load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]
for time = 1 : maxTime
    fprintf("time: %d\n", time);
    set(handles.current_3D,'string',num2str(time));
%     fprintf("time: %d\n", time);
%     fprintf("location : %d, %d\n",time_best.pos(time,1),time_best.pos(time,2));
%     fprintf("location : %d, %d\n",time_best.pos(time,3),time_best.pos(time,4));
%     fprintf("location : %d, %d\n",time_best.pos(time,5),time_best.pos(time,6));
    for t = 0:0.1:1
        for i = 1:num_UAV
            x_drone(i) = temp_x(i) + (lo.time_best.pos(time,2*i-1)-temp_x(i))*t;
            y_drone(i) = temp_y(i) + (lo.time_best.pos(time,2*i)-temp_y(i))*t;
            z_drone(i) = func_Zaxis(x_drone(i),y_drone(i))+0.7;
            
            set(drone(i).in, 'Xdata', x_drone(i));
            set(drone(i).in, 'Ydata', y_drone(i));
            set(drone(i).in, 'Zdata', z_drone(i));
        end
        drawnow;
        for i=1:10
            temp = i;
        end
    end
    
    
    for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
        one = drone_numbers(time,i);
        for j = i+1 : 6 % �ִ��а��� +1
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1.)
                line_(i,j)=line([x_drone(one) x_drone(two)],[y_drone(one) y_drone(two)],[z_drone(one),z_drone(two)],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',3,'LineStyle','--');
            elseif(connection_drones(time,one,two)==2.)
                line_(i,j)=line([x_drone(one) x_drone(two)],[y_drone(one) y_drone(two)],[z_drone(one),z_drone(two)],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',3,'LineStyle','-');
            end
        end
    end
    pause(1);
    for i = 6-num_UAV : 5
        for j = i+1 : 6 % �ִ��а��� +1
            one = drone_numbers(time,i);
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1. || connection_drones(time,one,two)==2.)
                delete(line_(i,j));
            end
        end
    end
    temp_x = x_drone;
    temp_y = y_drone;
end


% --- Executes on button press in tempbutton.
function tempbutton_Callback(hObject, eventdata, handles)
global maxTime num_UAV dronex droney flag_d UAV_Color lineColor line_
flag_d = flag_d + 1;
if flag_d > 1
    for i = 1 : num_UAV
        delete(dronex(i).in);
        delete(droney(i).in);
    end
    delete(line_)
end
alpha(.6)

for i = 1 : num_UAV +1 %��� �����
    if(i==num_UAV+1)
        x_antenna = 0;
        y_antenna = 0;
        z_antenna = func_Zaxis(x_antenna,y_antenna)+1;   %# The z data for the image corners
        break;
    end
    
    vertex_x(i).in = [0.75 0 30 ; 1.25 0 30 ; 1.25 2 30 ; 0.75 2 30 ; 0.75 0 31; 1.25 0 31; 1.25 2 31;0.75 2 31];
    vertex_y(i).in = [0 1 30 ; 0 1.5 30 ; 2 1.5 30 ; 2 1 30 ; 0 1 31; 0 1.5 31; 2 1.5 31;2 1 31];
    face_x(i).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    face_y(i).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    %z_drone(i) = 30%func_Zaxis_3(vertex_x(i).in,vertex(i).s);   %# The z data for the image corners
    temp_x(i).in = vertex_x(i).in;
    temp_y(i).in = vertex_y(i).in;
    
    dronex(i).in = patch('Vertices',vertex_x(i).in,'faces',face_x(i).in,'Facecolor',UAV_Color(i),'EdgeColor',UAV_Color(i),'FaceAlpha',.6);%x_drone(1), y_drone(1),z_drone(1),img1);
    droney(i).in = patch('Vertices',vertex_y(i).in,'faces',face_y(i).in,'Facecolor',UAV_Color(i),'EdgeColor',UAV_Color(i),'FaceAlpha',.6);%x_drone(1), y_drone(1),z_drone(1),img1);
    view(3);
end
vertex_a=[0 0 z_antenna;  1 0 z_antenna;   1 1 z_antenna;  0 1 z_antenna;  0.5 0.5 z_antenna+5];
face_a=[1 2 3 4;   1 2 5 NaN;   2 3 5 NaN;   3 4 5 NaN;  4 1 5 NaN];
antenna = patch('Vertices',vertex_a,'faces',face_a,'Facecolor','black');

lo = load('location_best.mat');%%%%%%%%%%%%%%%%%%%%yj,ps

load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]

for time = 1 : maxTime
    fprintf("time: %d\n", time);
    set(handles.current_3D,'string',num2str(time));
    %��� �̵�
    for num = 1 : num_UAV
        dist_x(num,1).in = [lo.time_best.pos(time,2*num-1)-0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)-0.25;
            lo.time_best.pos(time,2*num-1)-0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)-0.25;];
        dist_y(num,1).in = [lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)+1;
            lo.time_best.pos(time,2*num-1)+1;
            lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)+1;
            lo.time_best.pos(time,2*num-1)+1;];
        dist_x(num,2).in = [lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)+1;
            lo.time_best.pos(time,2*num)+1;
            lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)+1;
            lo.time_best.pos(time,2*num)+1;];
        dist_y(num,2).in = [lo.time_best.pos(time,2*num)-0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)-0.25;
            lo.time_best.pos(time,2*num)-0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)-0.25;];
    end
    for t = 0:0.1:1
        for num = 1 : num_UAV
            vertex_x(num).in(:,1,:) = temp_x(num).in(:,1,:) + (dist_x(num,1).in - temp_x(num).in(:,1,:))*t;%���γ׸��� x�ప update
            vertex_y(num).in(:,1,:) = temp_y(num).in(:,1,:) + (dist_y(num,1).in - temp_y(num).in(:,1,:))*t;%���γ׸��� y�ప update
            vertex_x(num).in(:,2,:) = temp_x(num).in(:,2,:) + (dist_x(num,2).in - temp_x(num).in(:,2,:))*t;%y�ప update
            vertex_y(num).in(:,2,:) = temp_y(num).in(:,2,:) + (dist_y(num,2).in - temp_y(num).in(:,2,:))*t;
            
            set(dronex(num).in,'Vertices',vertex_x(num).in);
            set(droney(num).in,'Vertices',vertex_y(num).in);
            view(3);
            drawnow;
        end
    end
    for num = 1:num_UAV %��п��� ���� �� ������
        pl(num)=stem3(lo.time_best.pos(time,2*num-1),lo.time_best.pos(time,2*num),30.5,'color',UAV_Color(num));
        
        %temp �� �ٲٱ�
        temp_x(num).in = vertex_x(num).in;
        temp_y(num).in = vertex_y(num).in;
    end
    
    % ��� ���ἱ ǥ��
    for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
        one = drone_numbers(time,i);
        for j = i+1 : 6 % �ִ��а��� +1
            if(j==6)
                if(connection_drones(time,one,num_UAV+1)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_antenna],...
                        [lo.time_best.pos(time,2*one) y_antenna],[30.5 z_antenna],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,num_UAV+1)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_antenna],...
                        [lo.time_best.pos(time,2*one) y_antenna],[30.5 z_antenna],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            else
                two = drone_numbers(time,j);
                if(connection_drones(time,one,two)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,two)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            end
        end
    end
    pause(1);
    delete(pl);
    for i = 6-num_UAV : 5
        for j = i+1 : 6 % �ִ��а��� +1
            one = drone_numbers(time,i);
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1. || connection_drones(time,one,two)==2.)
                delete(line_(i,j));
            end
        end
    end
end


% --- Executes on button press in sensor.
function sensor_Callback(hObject, eventdata, handles)
global  sensor_type_text num_sensor ground
cla reset;
axes(handles.threeD);
x = 0:0.5:20;
y = 0:0.5:20;
x_ = 0 : 1 : 20;
y_ = 0 : 1 : 20;
[X,Y]= meshgrid(x,y);
Z = (X-5).*5.*exp(-(X-8).^2-(Y-8).^2)-sqrt((X-2).^2+(Y-2).^2)+10.*2.*exp(-(X-5).^2-(Y-4).^2)...
    + sin(2*X) + sin(2*Y)+10;
ground = surf(x_,y_,Z);

load('MyColormaps','mycmap');
colormap(mycmap);
set(handles.threeD,'xgrid','on','ygrid','on','zgrid','on','xlim',[-1 20],'ylim',[-1 20],'zlim',[-5 40]);
xlabel(handles.threeD,'X�Ÿ�(10m)');
ylabel(handles.threeD,'Y�Ÿ�(10m)');
zlabel(handles.threeD,'Z����(10m)');
title(handles.threeD, '3DTopology & Drone movement');
hold on;
load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp');
[sensor_type, num_sensor] = size(sensor_x_temp);

col = hsv(5);
for i=1:sensor_type
    for j=1: num_sensor(1,i)
        if i==1
            a = plot3(handles.threeD,sensor_x_temp(i, j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i==2
            b = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 3
            c = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 4
            d = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 5
            e = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j), func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        end
    end
end
hold on
rotate3d on



function current_3D_Callback(hObject, eventdata, handles)
global num_UAV UAV_Color flag_i lineColor line_ range_d height r drone_d pl
time = str2double(get(handles.current_3D,'String'));
fprintf("time: %d\n", time);

flag_i = flag_i+1;
if flag_i > 1
   delete(range_d);

   delete(pl);
end

x_a = 1; y_a = 1; z_a = 1;

lo = load('location_best.mat'); % UAV ��ġ ��


lo = load('location_best.mat');%%%%%%%%%%%%%%%%%%%%yj,ps
load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]

%��� �̵�
for i = 1 : num_UAV
    upA(i) = (lo.time_best.pos(time,2*i-1));
    upB(i) = (lo.time_best.pos(time,2*i));
    updatedX = [upA(i) upA(i)+1; upA(i) upA(i)+1];
    updatedY = [upB(i)+1 upB(i); upB(i)+1 upB(i)];
    
    set(drone_d(i).in, 'Xdata', updatedX);
    set(drone_d(i).in, 'Ydata', updatedY);
    drawnow;
end
for num = 1:num_UAV 
    %��п��� ���� �� ������
    pl(num)=stem3(lo.time_best.pos(time,2*num-1),lo.time_best.pos(time,2*num),30.5,'color',UAV_Color(num));
    
    %���� ǥ��
    height_c = height/10;
    r_c = r + r/10 ;
    t_c = 0:r_c/1.2:r_c;
    [X_c,Y_c,Z_c] = cylinder(-t_c+r_c);
    X_c1 = X_c + lo.time_best.pos(time,2*num-1);
    Y_c1 = Y_c + lo.time_best.pos(time,2*num);
    Z_c1 = Z_c*height_c + 1;
    range_d(num) = surf(X_c1,Y_c1,Z_c1,'EdgeColor','none','FaceColor','[0 0 1]')
    alpha(range_d(num),0.5);
    drawnow;
end

% ��� ���ἱ ǥ��
for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
    one = drone_numbers(time,i);
    for j = i+1 : 6 % �ִ��а��� +1
        if(j==6)
            if(connection_drones(time,one,num_UAV+1)==1.)
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_a],...
                    [lo.time_best.pos(time,2*one) y_a],[30.5 z_a],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
            elseif(connection_drones(time,one,num_UAV+1)==2.)
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_a],...
                    [lo.time_best.pos(time,2*one) y_a],[30.5 z_a],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
            end
        else
            two = drone_numbers(time,j);
            if(connection_drones(time,one,two)==1.)
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                    [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
            elseif(connection_drones(time,one,two)==2.)
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                    [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
            end
        end
    end
end
pause(2);
for i = 6-num_UAV : 5
    for j = i+1 : 6
        try
            delete(line_(i,j));
        catch
            i
            j
        end
    end
end

% --- Executes during object creation, after setting all properties.
function current_3D_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in imageBtn.
function imageBtn_Callback(hObject, eventdata, handles)
global maxTime UAV_Color lineColor num_UAV line_ r height drone_d pl range_d flag_i

if flag_i > 1
   delete(range_d);
   for i = 0:5
       for j = 0:5
           try
               delete(get(line_));
           catch
           end
       end
   end
   delete(pl);
   flag_i = 0;
end

lo = load('location_best.mat'); % UAV ��ġ ��

%���׳� ��
x_a = 1; y_a = 1; z_a = 1;
x_antenna = [x_a-0.5 x_a+0.5 ; x_a-0.5 x_a+0.5];
y_antenna = [y_a+0.5 y_a-0.5 ; y_a+0.5 y_a-0.5];
z_antenna = [z_a+2 z_a+2; z_a-1 z_a-1];

%�̹��� ������
a = zeros(num_UAV);
b = zeros(num_UAV);
for i=1:num_UAV
    x_drone(i).in = [a(i) a(i)+1 ; a(i) a(i)+1];
    y_drone(i).in = [b(i)+1 b(i) ; b(i)+1 b(i)];
    set(drone_d(i).in, 'Xdata', x_antenna);
    set(drone_d(i).in, 'Ydata', y_antenna);
end

lo = load('location_best.mat');%%%%%%%%%%%%%%%%%%%%yj,ps
load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]

for time = 1 : maxTime
    fprintf("time: %d\n", time);
    set(handles.current_3D,'string',num2str(time));
    %��� �̵�
    for t = 0:0.1:1
        for i = 1 : num_UAV
            upA(i) = a(i) + (lo.time_best.pos(time,2*i-1)-a(i))*t;
            upB(i) = b(i) + (lo.time_best.pos(time,2*i)-b(i))*t;
            updatedX = [upA(i) upA(i)+1; upA(i) upA(i)+1];
            updatedY = [upB(i)+1 upB(i); upB(i)+1 upB(i)];
            
            set(drone_d(i).in, 'Xdata', updatedX);
            set(drone_d(i).in, 'Ydata', updatedY);
            drawnow;
        end
    end
    for num = 1:num_UAV 
        %��п��� ���� �� ������
        pl(num)=stem3(lo.time_best.pos(time,2*num-1),lo.time_best.pos(time,2*num),height/10,'color',UAV_Color(num));
        
        %���� ǥ��
        height_c = height/10;
        r_c = r + r/10 ;
        t_c = 0:r_c/1.2:r_c;
        [X_c,Y_c,Z_c] = cylinder(-t_c+r_c);
        X_c1 = X_c + lo.time_best.pos(time,2*num-1);
        Y_c1 = Y_c + lo.time_best.pos(time,2*num);
        Z_c1 = Z_c*height_c + 1;
        range_d(num) = surf(X_c1,Y_c1,Z_c1,'EdgeColor','none','FaceColor','[0 0 1]')
        alpha(range_d(num),0.5);
        drawnow;
        
        %temp �� �ٲٱ�
        a(num) = upA(num);
        b(num) = upB(num);
        
    end
    
        

    
    
    % ��� ���ἱ ǥ��
    for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
        one = drone_numbers(time,i);
        for j = i+1 : 6 % �ִ��а��� +1
            if(j==6)
                if(connection_drones(time,one,num_UAV+1)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_a],...
                        [lo.time_best.pos(time,2*one) y_a],[30.5 z_a],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,num_UAV+1)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_a],...
                        [lo.time_best.pos(time,2*one) y_a],[30.5 z_a],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            else
                two = drone_numbers(time,j);
                if(connection_drones(time,one,two)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,two)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            end
        end
    end



    pause(1);
    delete(pl);
    delete(range_d);
    for i = 6-num_UAV : 5
        for j = i+1 : 6 % �ִ��а��� +1
            one = drone_numbers(time,i);
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1. || connection_drones(time,one,two)==2.)
                delete(line_(i,j));
            end
        end
    end
end
delete(drone_d);