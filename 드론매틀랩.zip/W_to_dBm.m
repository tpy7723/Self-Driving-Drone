function [dBm] = W_to_dBm(W)
dBm = 10 * log10(W/10^(-3));
end

