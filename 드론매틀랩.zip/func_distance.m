function [d]=func_distance(a,b)

d = sqrt(a^2+b^2);