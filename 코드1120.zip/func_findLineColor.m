function [] = func_findLineColor(a,b)
%yj


end

