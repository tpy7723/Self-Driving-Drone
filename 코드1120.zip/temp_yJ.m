x = [4,3];
i=1;
a = 0; b = 1;
x_drone(i).in = [a b ; a b];
y_drone(i).in = [b a ; b a];
for t = 0:0.1:1
    Up = x_drone(i).in(1) + (x-x_drone(i).in(1))*t;
    Up
end