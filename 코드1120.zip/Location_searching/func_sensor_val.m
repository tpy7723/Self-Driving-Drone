function [val] = func_sensor_val(v_max, sensing_time, time)

v_min = v_max*0.01;

w = (v_max - v_min)/(exp(5)-1);
b = v_min - w;

v_x = w*exp(time-sensing_time) + b;

if v_x > v_max
    v_x = v_max;
end
val = v_x;

