function [pl1]=func_pathloss(Distance, t_avgSNR)

[num_Node1, num_Node2] = size(Distance);
p = 3;
Gr = p^2;
Gt = 16;
lambda = 1;
N0 = 100;
Pt = 10^(t_avgSNR/10)*100;

N = 20;
cm = 1/2;
km = 1/2;

aN = log10(N*cm)/km;
bN = 1/km;

for order1 = 1:num_Node1
    for order2 = 1:num_Node2
        if Distance(order1, order2) < 0
            avgPSR1(order1, order2) = 1;
        else
            r_avgSNR1(order1, order2) = ((Gt*Gr*lambda^2)/(4*p)^2) * Pt/Distance(order1, order2)^2;
            avgPER1(order1, order2) = 1 - exp(-aN/r_avgSNR1(order1, order2))*gamma(1+bN/r_avgSNR1(order1, order2));
            avgPSR1(order1, order2) = 1 - (avgPER1(order1, order2))^3;
            if avgPSR1(order1, order2) > 1
                avgPSR1(order1, order2) = 1;
            end
        end
    end
end
pl1 = avgPSR1;