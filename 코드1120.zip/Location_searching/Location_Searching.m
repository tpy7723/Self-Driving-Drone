clc
clear all
close all
    
% Topology
x = 0:0.01:20;
y = 0:0.01:20;

topo_r = 3;
N=100;
theta=linspace(0, 2*pi, N);

load('topo_x');
load('topo_y');
load('sensor_x');
load('sensor_y');
load('sensor_snr');
[sensor_type, num_cluster, num_sensor] = size(sensor_x);

for i=1:num_cluster
    topo_xx = topo_r*cos(theta)+topo_x(i);
    topo_yy = topo_r*sin(theta)+topo_y(i);
    hold on
end

% ���� ��ǥ
for i=1:sensor_type
    for j=1:num_cluster
        for k=1:num_sensor
            if i==1
                a = plot(sensor_x(i, j, k), sensor_y(i, j, k), 'k:*');
                hold on
            elseif i==2
                b = plot(sensor_x(i, j, k), sensor_y(i, j, k), 'k:o');
                hold on
            elseif i == 3
                c = plot(sensor_x(i, j, k), sensor_y(i, j, k), 'k:x');
                hold on
            elseif i == 4
                d = plot(sensor_x(i, j, k), sensor_y(i, j, k), 'k:d');
                hold on
            elseif i == 5
                e = plot(sensor_x(i, j, k), sensor_y(i, j, k), 'k:h');
                hold on
            end
        end
    end
end
axis([0 20 0 20]);

% ���� ���� ��
temp_sensor_val(1) = 10;
temp_sensor_val(2) = 15;
temp_sensor_val(3) = 20;

% PSO �Ķ����
swarm_size = 30;
maxIter = 300;
maxTime = 20;
c1 = 1.4;
c2 = 1.4;
maxIter = 300;
k_iter = 0.75*maxIter;

num_UAV = 3; % UAV ����

% �ý��� �Ķ����
cr = 10; % ���� �ݰ�
r = 1; % ���� �ݰ�

for t = 1:sensor_type
   sensor_val(t, 1:num_cluster, 1:num_sensor) = temp_sensor_val(t); 
end
sensing_time(1:swarm_size,  1:maxTime, 1:sensor_type, 1:num_cluster, 1:num_sensor) = 0;

for time = 1:maxTime
    % ��ġ, �ӵ�, best �� ��� �ʱ�ȭ
    for dim=1:2*num_UAV
        swarm(:, 1, dim) = rand(1,swarm_size)*20;
    end

    swarm(:, 2, :) = 0;
    swarm(:, 3, :) = 0;
    swarm(:, 4, 1) = 0;
    
    % PSO �˰�����
    for iter = 1:maxIter
        for i = 1:swarm_size
            for dim = 1:2*num_UAV
                % ��ġ ������Ʈ
                swarm(i, 1, dim) = swarm(i, 1, dim) + swarm(i, 2, dim);
                % ��ġ�� �־��� �������� ������ ����� �� ���
                if swarm(i, 1, dim) < 0 || swarm(i, 1, dim) > 20
                    swarm(i, 1, dim) = swarm(i, 1, dim) - swarm(i, 2, dim);
                end
            end

            % UAV�� ��ġ�� ��ǥ��
            temp = 1;
            for order = 1:num_UAV+1
                for axiss = 1:2
                    if order == num_UAV+1
                        % num_UAV+1�� Base Station
                        UAV(order, axiss) = 0;
                    else
                        UAV(order, axiss) = swarm(i, 1, temp);
                        temp = temp+1;
                    end
                end
            end

            % UAV�� ���ϴ� ������ ���� �� Utility
            UAV_sensor(1:num_UAV, 1:sensor_type) = 0;
            num(1:num_UAV, 1:sensor_type) = 0;
            avg_snr(1:num_UAV, 1:sensor_type) = 0;
            temp_sensing_time(1:sensor_type, 1:num_cluster, 1:num_sensor) = 0;
            
            for j = 1:sensor_type
                for k = 1:num_cluster
                    for l = 1:num_sensor
                        temp(1:num_UAV) = 0;
                        num_overlap = 0;
                        for order = 1:num_UAV
                            if (sensor_x(j, k, l) - UAV(order, 1))^2 + (sensor_y(j, k, l) - UAV(order, 2))^2 <= r^2
                                temp(order) = 1;
                                num_overlap = num_overlap + 1;
                                avg_snr(order, j) = avg_snr(order, j) + sensor_snr(j, k, l);
                                num(order, j) = num(order, j) + 1;

                                temp_sensing_time(j, k, l) = time;
                            end
                        end

                        for order = 1:num_UAV
                            if num_overlap > 0 
                                UAV_sensor(order, j) = UAV_sensor(order, j) + sensor_val(j, k, l)*(temp(order)/num_overlap);
                            end
                        end
                    end
                end
            end

            % �� UAV�� ���� Fitness value
            val(1:num_UAV) = 0;
            for order = 1:num_UAV
                for t = 1:sensor_type
                    if num(order, t) == 0
                        num(order, t) = 1;
                    end
                    % func_pathloss : UAV�� ���� ������ PER
                    % func_fitness : ���� ������ ���� ȿ���� ����
                    val(order) = val(order) + func_pathloss(1,avg_snr(order, t)/num(order, t))*func_fitness(UAV_sensor(order, t), 30);
                end
            end

            % UAV�� �Ÿ� �� ����
            Distance = func_distance2(UAV);

            % UAV�� Base Station�� ����Ǿ� �ִ��� �Ǵ�
            count = func_count(Distance, cr);
            % Base Station�� ����Ǿ� ���� ������ val = 0
            for order = 1:num_UAV
                if count(order) == 0
                    val(order) = 0;
                end
            end

            % UAV-UAV �Ǵ� Base Station�� PER
            temp_pathloss = func_pathloss(Distance, 5);
            penalty = 1;

            % ���ͽ�Ʈ�� �̿��Ͽ� ��Ŷ ���� Ȯ���� �ִ��� ��� Ž��
            temp_dijk = func_dijk(temp_pathloss, penalty);
            val1 = val.*temp_dijk(1, 1:num_UAV);
            fitness_val = sum(val1);

            % Local best 
            % swarm(i, 4, 1)�� local best�� ��
            % swarm(i, 3, :)�� local best�� ��ġ  
            if fitness_val > swarm(i, 4, 1)
                % local best ��ġ ������Ʈ
                for dim = 1:2*num_UAV
                    swarm(i, 3, dim) = swarm(i, 1, dim);
                end
                
                % local best �� ������Ʈ
                swarm(i, 4, 1) = fitness_val;
                
                % local best�� ��ġ�� �ش��ϴ� ����
                for j = 1:sensor_type
                    for k = 1:num_cluster
                        for l = 1:num_sensor
                            sensing_time(i, time, j, k, l) = temp_sensing_time(j, k, l);
                        end
                    end
                end
            end
        end

        % global best
        [temp1, gbest(time)] = max(swarm(1:swarm_size, 4, 1));
         
        % global best�� �ش��ϴ� ��ġ
        for d = 1:2*num_UAV
            pos(time, gbest(time),d) = swarm(gbest(time), 3, d);
        end
%         if time == 1
%             t1(iter, 1, 1) = swarm(gbest(1), 4, 1);
%         end


        % �ӵ� ������Ʈ
        z = rand;
        z = 4*z*(1-z);
        inertia = 0.5*rand + 0.5*z;

        rate = rand(1);
        if iter <= k_iter
            for i = 1:swarm_size
                if i < round(swarm_size*rate)
                    for dim = 1:2*num_UAV
                        swarm(i, 2, dim) = inertia*swarm(i, 2, dim) + c1*rand*(swarm(i, 3, dim)-swarm(i, 2, dim)) + c2*rand*(swarm(gbest(time), 3, dim) - swarm(i, 1, dim));
                    end
                else
                    for dim = 1:2*num_UAV
                        swarm(i, 2, dim) = inertia*swarm(i, 2, dim) + (2*(1-(iter/maxIter)))*(rand*(swarm(i, 3, dim) - swarm(i, 1, dim)) + c2*rand*(swarm(gbest(time), 3, dim) - swarm(i, 1, dim)));
                    end
                end
            end

        else
            for i = 1:swarm_size
                for dim = 1:2*num_UAV
                    swarm(i, 2, dim) = inertia*swarm(i, 2, dim) + c1*rand*(swarm(i, 3, dim)-swarm(i, 2, dim)) + c2*rand*(swarm(gbest(time), 3, dim) - swarm(i, 1, dim));
                end
            end
        end

        if iter == 300
            disp(['Time is ' int2str(time) ' , the best fitness value1 is ' num2str(swarm(gbest(time),4,1))]);
        end
        best(iter) = swarm(gbest(time), 4, 1);
    end

    finish(time) = best(300);
    
    % global best ��ġ�� �ش��ϴ� ������ ���� �� ������Ʈ
    for j = 1:sensor_type
        for k = 1:num_cluster
            for l = 1:num_sensor
                for ti = 1:time
                    if sensing_time(gbest(ti), ti, j, k, l) > 0
                        sensor_val(j, k, l) = func_sensor_val(temp_sensor_val(j), sensing_time(gbest(ti), ti, j, k, l), time);
                        if sensor_val(j, k, l) == temp_sensor_val(j)
                            sensing_time(gbest(ti), ti, j, k, l) = 0;
                        end
                    end
                end
            end
        end
    end
end
axis([0 20 0 20]);

% ������ ��ġ �׸�
xx = r*cos(theta) + pos(1,gbest(1), 1);
yy = r*sin(theta) + pos(1,gbest(1), 2);
plot(xx, yy, 'r', 'LineWidth', 2);
hold on
xx = r*cos(theta) + pos(1,gbest(1), 3);
yy = r*sin(theta) + pos(1,gbest(1), 4);
plot(xx, yy, 'r', 'LineWidth', 2);
hold on
xx = r*cos(theta) + pos(1,gbest(1), 5);
yy = r*sin(theta) + pos(1,gbest(1), 6);
plot(xx, yy, 'r', 'LineWidth', 2);
hold on
xx = r*cos(theta) + pos(1,gbest(1), 7);
yy = r*sin(theta) + pos(1,gbest(1), 8);
plot(xx, yy, 'r', 'LineWidth', 2);
hold on
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% xx = r*cos(theta) + v(2,gbest(2), 1);
% yy = r*sin(theta) + v(2,gbest(2), 2);
% plot(xx, yy, 'b', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(2,gbest(2), 3);
% yy = r*sin(theta) + v(2,gbest(2), 4);
% plot(xx, yy, 'b', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(2,gbest(2), 5);
% yy = r*sin(theta) + v(2,gbest(2), 6);
% plot(xx, yy, 'b', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(2,gbest(2), 7);
% yy = r*sin(theta) + v(2,gbest(2), 8);
% plot(xx, yy, 'b', 'LineWidth', 2);
% hold on
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% xx = r*cos(theta) + v(3,gbest(3), 1);
% yy = r*sin(theta) + v(3,gbest(3), 2);
% plot(xx, yy, 'g', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(3,gbest(3), 3);
% yy = r*sin(theta) + v(3,gbest(3), 4);
% plot(xx, yy, 'g', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(3,gbest(3), 5);
% yy = r*sin(theta) + v(3,gbest(3), 6);
% plot(xx, yy, 'g', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(3,gbest(3), 7);
% yy = r*sin(theta) + v(3,gbest(3), 8);
% plot(xx, yy, 'g', 'LineWidth', 2);
% hold on
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% xx = r*cos(theta) + v(4,gbest(4), 1);
% yy = r*sin(theta) + v(4,gbest(4), 2);
% plot(xx, yy, 'm', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(4,gbest(4), 3);
% yy = r*sin(theta) + v(4,gbest(4), 4);
% plot(xx, yy, 'm', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(4,gbest(4), 5);
% yy = r*sin(theta) + v(4,gbest(4), 6);
% plot(xx, yy, 'm', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(4,gbest(4), 7);
% yy = r*sin(theta) + v(4,gbest(4), 8);
% plot(xx, yy, 'm', 'LineWidth', 2);
% hold on
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% xx = r*cos(theta) + v(5,gbest(5), 1);
% yy = r*sin(theta) + v(5,gbest(5), 2);
% plot(xx, yy, 'k', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(5,gbest(5), 3);
% yy = r*sin(theta) + v(5,gbest(5), 4);
% plot(xx, yy, 'k', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(5,gbest(5), 5);
% yy = r*sin(theta) + v(5,gbest(5), 6);
% plot(xx, yy, 'k', 'LineWidth', 2);
% hold on
% xx = r*cos(theta) + v(5,gbest(5), 7);  
% yy = r*sin(theta) + v(5,gbest(5), 8);
% plot(xx, yy, 'k', 'LineWidth', 2);
% hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% �ð��� ���� utility�� ��ȭ �׷���
figure;
t=1:maxTime;
plot(t, finish);
grid on
title('Utility to change with Time')
xlabel('Time');
ylabel('Utility');