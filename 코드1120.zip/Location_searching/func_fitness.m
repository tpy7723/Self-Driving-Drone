function [fitness]=func_fitness(a, b)

fitness = b*log10(a/40+1);