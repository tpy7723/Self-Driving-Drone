function [d2]=func_distance2(UAV)
[num, temp] = size(UAV);

for order1 = 1:num
    for order2 = 1:num
        if order1 == order2
            Distance(order1, order2) = 0;
        else
            Distance(order1, order2) = func_distance((UAV(order1, 1)-UAV(order2, 1)), (UAV(order1, 2)-UAV(order2, 2)));
            %UAV(order1)�� UAV(order2)�� �Ÿ� ����
        end
    end
end
d2 = Distance;
