function [Z] = func_Zaxis(a,b)
X = a*0.5-0.5;
Y = b*0.5-0.5;
Z = (X-5).*5.*exp(-(X-8).^2-(Y-8).^2)-sqrt((X-2).^2+(Y-2).^2)+10.*2.*exp(-(X-5).^2-(Y-4).^2)...
    + sin(2*X) + sin(2*Y)+10+0.2;
end

