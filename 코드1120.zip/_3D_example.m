space = 5;
top_space = 80;
scn_size = get(0,'ScreenSize');
scn_size
pos1 = [space, 2/3*scn_size(4) + space,...
scn_size(3)/2 - 2*space, scn_size(4)/3 - (top_space + space)];
pos2 = [pos1(1) + scn_size(3)/2, pos1(2),...
pos1(3), pos1(4)];
h1 = figure(1);
peaks;
h2 = figure(2);
membrane;
set(h1, 'Position', pos1)
set(h2, 'Position', pos2)