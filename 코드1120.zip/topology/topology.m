clc
clear all
close all

x = 0:20;
y = 0:20;

num_cluster = 15;
sensor_type = 3;


topo_r = 3;
N=100;
theta=linspace(0, 2*pi, N);

% ���ϴ� ��ġ�� ���� ��ġ
topo_x_temp= [3,3,6,6,4,15,17,17,16,9.5,12,15,17,16,15];
topo_y_temp = [4,6,12,13,14,13,14,4,6,6,5,3,2,3,3];

% �����ϰ� ���� ��ġ
for i = 1:num_cluster
%     if i <= 2
%         topo_x(i) = randi([3, 5]);
%         topo_y(i) = randi([4, 6]);
%     elseif i <= 5
%         topo_x(i) = randi([4, 6]);
%         topo_y(i) = randi([12, 16]);
%     elseif i <= 8
%         topo_x(i) = randi([15, 17]);
%         topo_y(i) = randi([13, 17]);
%     elseif i <= 9
%         topo_x(i) = randi([11, 15]);
%         topo_y(i) = randi([11, 15]);
%     elseif i<= 12
%         topo_x(i) = randi([13, 17]);
%         topo_y(i) = randi([3, 6]);
% 
%     else
%         topo_x(i) = randi([15, 17]);
%         topo_y(i) = randi([2, 5]);
%     end


    topo_xx = topo_r*cos(theta)+topo_x_temp(i);
    topo_yy = topo_r*sin(theta)+topo_y_temp(i);
%     plot(topo_xx, topo_yy , 'k');
    hold on
end

topo_r = 1.5;
num_sensor_max = 70;
sensor_x_temp(1:sensor_type, 1:num_cluster, 1:num_sensor_max) = 100; % �� Ŭ�����Ϳ� �ִ� ���� ���� Ÿ���� x��ǥ
sensor_y_temp(1:sensor_type, 1:num_cluster, 1:num_sensor_max) = 100; % �� Ŭ�����Ϳ� �ִ� ���� ���� Ÿ���� y��ǥ
for i=1:sensor_type
    for j = 1:num_cluster
        num_sensor = randi(40) + 30;
        for k=1:num_sensor
            sensor_x_temp(i, j, k) = randn*sqrt(topo_r) + topo_x_temp(j);
            sensor_y_temp(i, j, k) = randn*sqrt(topo_r) + topo_y_temp(j);
            if i==1
                a = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:*');
                hold on
            elseif i==2
                b = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:o');
                hold on
            elseif i == 3
                c = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:x');
                hold on
            elseif i == 4
                d = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:d');
            elseif i == 5
                e = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:h');
            end
        end
    end  
end


axis([0 20 0 20])
save topo_x_temp.mat topo_x_temp
save topo_y_temp.mat topo_y_temp
save sensor_x_temp.mat sensor_x_temp
save sensor_y_temp.mat sensor_y_temp