clc
clear all
close all

% Topology
x = 0:0.01:20;
y = 0:0.01:20;

topo_r = 3;
N=100;
theta=linspace(0, 2*pi, N);

load('topo_x_temp');
load('topo_y_temp');
load('sensor_x_temp');
load('sensor_y_temp');

[sensor_type, num_cluster, num_sensor] = size(sensor_x_temp);

for i=1:num_cluster
    topo_xx = topo_r*cos(theta)+topo_x_temp(i);
    topo_yy = topo_r*sin(theta)+topo_y_temp(i);
%     plot(topo_xx, topo_yy , 'k');
    hold on
end
sensor_snr(1:sensor_type, 1:num_cluster, 1:num_sensor) = 0;

for i=1:sensor_type
    for j=1:num_cluster
        for k=1:num_sensor           
            if sensor_x_temp(i, j, k) <= 10 && sensor_y_temp(i, j, k) <= 10
                sensor_snr(i, j, k) = randn*2 + 3;
            elseif sensor_x_temp(i, j ,k) <= 10 && (sensor_y_temp(i, j, k) > 10 && sensor_y_temp(i, j, k) <= 20)
                sensor_snr(i, j, k) = randn*2 + 6;
            elseif (sensor_x_temp(i, j ,k) > 10 && sensor_x_temp(i, j, k) <= 20) && sensor_y_temp(i, j, k) <= 10
                sensor_snr(i, j, k) = randn*2 + 4;
            else
                sensor_snr(i, j, k) = randn*2 + 7;
            end
            if i==1
                a = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:*');
                hold on
            elseif i==2
                b = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:o');
                hold on
            elseif i == 3
                c = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:x');
                hold on
            elseif i == 4
                d = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:d');
            elseif i == 5
                e = plot(sensor_x_temp(i, j, k), sensor_y_temp(i, j, k), 'k:h');
            end
        end
    end
end
axis([0 20 0 20]);