function varargout = testGUI_3D(varargin)
% TESTGUI_3D MATLAB code for testGUI_3D.fig
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @testGUI_3D_OpeningFcn, ...
    'gui_OutputFcn',  @testGUI_3D_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before testGUI_3D is made visible.
function testGUI_3D_OpeningFcn(hObject, eventdata, handles, varargin)
global  sensor_type_text num_sensor flag_d flag flag_i
% Choose default command line output for testGUI_3D
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);
cla reset;
flag_i=0;
flag_d = 0;
flag  = 0;
axes(handles.threeD);
x = 0:0.5:20;
y = 0:0.5:20;
[X,Y]= meshgrid(x,y);
Z = (X-5).*5.*exp(-(X-8).^2-(Y-8).^2)-sqrt((X-2).^2+(Y-2).^2)+10.*2.*exp(-(X-5).^2-(Y-4).^2)...
    + sin(2*X) + sin(2*Y)+10;
surf(Z);
set(handles.threeD,'xgrid','on','ygrid','on','zgrid','on','xlim',[-1 20],'ylim',[-1 20],'zlim',[-5 40]);
xlabel(handles.threeD,'X�Ÿ�(100m)');
ylabel(handles.threeD,'Y�Ÿ�(100m)');
zlabel(handles.threeD,'Z����(10m)');
title(handles.threeD, '3DTopology & Drone movement');
hold on;
load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp');
col = hsv(5);
for i=1:sensor_type_text
    for j=1: num_sensor
        if i==1
            a = plot3(handles.threeD,sensor_x_temp(i, j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i==2
            b = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 3
            c = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 4
            d = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 5
            e = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j), func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        end
    end
end
hold on
rotate3d on



% UIWAIT makes testGUI_3D wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = testGUI_3D_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in simulation.
function simulation_Callback(hObject, eventdata, handles)
% hObject    handle to simulation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global maxTime num_UAV drone flag
flag = flag +1;
if flag > 1
    for i = 1 : num_UAV
        delete (drone(i).in);
    end
end

alpha(.6)
UAV_Color = ["[1 0.8 0.8]";"[0.8 0.8 1]";"[0.8 1 0.8]";"[1 1 0.8]";"[0.87 0.55 0.14]"];
lineColor = ["red";"blue";"green";"cyan";"[0.87 0.55 0.14]"];
for i = 1 : num_UAV +1
    x_drone(i) = 0;   %# The x data for the image corners
    y_drone(i) = 0;             %# The y data for the image corners
    z_drone(i) = func_Zaxis(x_drone(i),y_drone(i));   %# The z data for the image corners
    if(i == num_UAV+1) break; end;
    drone(i).in = plot3(handles.threeD,x_drone(i), y_drone(i),z_drone(i),'-o','MarkerSize',15,'MarkerEdgeColor',UAV_Color(i),...
        'MarkerFaceColor',UAV_Color(i));
end
grid on
hold on

antenna = plot3(handles.threeD,x_drone(num_UAV+1), y_drone(num_UAV+1),z_drone(num_UAV+1),'-d','MarkerSize',25,'MarkerEdgeColor','yellow',...
    'MarkerFaceColor',[1 1 0]);

lo = load('location.mat');%%%%%%%%%%%%%%%%%%%%yj,ps
temp_x = x_drone;
temp_y = y_drone;
load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]
for time = 1 : maxTime
    fprintf("time: %d\n", time);
    set(handles.current_3D,'string',num2str(time));
%     fprintf("time: %d\n", time);
%     fprintf("location : %d, %d\n",time_best.pos(time,1),time_best.pos(time,2));
%     fprintf("location : %d, %d\n",time_best.pos(time,3),time_best.pos(time,4));
%     fprintf("location : %d, %d\n",time_best.pos(time,5),time_best.pos(time,6));
    for t = 0:0.1:1
        for i = 1:num_UAV
            x_drone(i) = temp_x(i) + (lo.time_best.pos(time,2*i-1)-temp_x(i))*t;
            y_drone(i) = temp_y(i) + (lo.time_best.pos(time,2*i)-temp_y(i))*t;
            z_drone(i) = func_Zaxis(x_drone(i),y_drone(i))+0.7;
            
            set(drone(i).in, 'Xdata', x_drone(i));
            set(drone(i).in, 'Ydata', y_drone(i));
            set(drone(i).in, 'Zdata', z_drone(i));
        end
        drawnow;
        for i=1:10
            temp = i;
        end
    end
    
    
    for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
        one = drone_numbers(time,i);
        for j = i+1 : 6 % �ִ��а��� +1
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1.)
                line_(i,j)=line([x_drone(one) x_drone(two)],[y_drone(one) y_drone(two)],[z_drone(one),z_drone(two)],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',3,'LineStyle','--');
            elseif(connection_drones(time,one,two)==2.)
                line_(i,j)=line([x_drone(one) x_drone(two)],[y_drone(one) y_drone(two)],[z_drone(one),z_drone(two)],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',3,'LineStyle','-');
            end
        end
    end
    pause(1);
    for i = 6-num_UAV : 5
        for j = i+1 : 6 % �ִ��а��� +1
            one = drone_numbers(time,i);
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1. || connection_drones(time,one,two)==2.)
                delete(line_(i,j));
            end
        end
    end
    temp_x = x_drone;
    temp_y = y_drone;
end


% --- Executes on button press in tempbutton.
function tempbutton_Callback(hObject, eventdata, handles)
global maxTime num_UAV dronex droney flag_d UAV_Color lineColor line_
flag_d = flag_d + 1;
if flag_d > 1
    for i = 1 : num_UAV
        delete(dronex(i).in);
        delete(droney(i).in);
    end
    delete(line_)
end
num_UAV
alpha(.6)
UAV_Color = ["[0.6 1 0.6]";"[1 0.5 0.5]";"[0.6 0.6 1]";"[1 0.8 1]";"[1 1 0.8]"];
lineColor = ["green";"red";"blue";"m";"y"];

for i = 1 : num_UAV +1 %��� �����
    if(i==num_UAV+1)
        x_antenna = 0;
        y_antenna = 0;
        z_antenna = func_Zaxis(x_antenna,y_antenna)+1;   %# The z data for the image corners
        break;
    end
    
    vertex_x(i).in = [0.75 0 30 ; 1.25 0 30 ; 1.25 2 30 ; 0.75 2 30 ; 0.75 0 31; 1.25 0 31; 1.25 2 31;0.75 2 31];
    vertex_y(i).in = [0 1 30 ; 0 1.5 30 ; 2 1.5 30 ; 2 1 30 ; 0 1 31; 0 1.5 31; 2 1.5 31;2 1 31];
    face_x(i).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    face_y(i).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    %z_drone(i) = 30%func_Zaxis_3(vertex_x(i).in,vertex(i).s);   %# The z data for the image corners
    temp_x(i).in = vertex_x(i).in;
    temp_y(i).in = vertex_y(i).in;
    
    dronex(i).in = patch('Vertices',vertex_x(i).in,'faces',face_x(i).in,'Facecolor',UAV_Color(i),'EdgeColor',UAV_Color(i),'FaceAlpha',.6);%x_drone(1), y_drone(1),z_drone(1),img1);
    droney(i).in = patch('Vertices',vertex_y(i).in,'faces',face_y(i).in,'Facecolor',UAV_Color(i),'EdgeColor',UAV_Color(i),'FaceAlpha',.6);%x_drone(1), y_drone(1),z_drone(1),img1);
    view(3);
end
vertex_a=[0 0 z_antenna;  1 0 z_antenna;   1 1 z_antenna;  0 1 z_antenna;  0.5 0.5 z_antenna+5];
face_a=[1 2 3 4;   1 2 5 NaN;   2 3 5 NaN;   3 4 5 NaN;  4 1 5 NaN];
antenna = patch('Vertices',vertex_a,'faces',face_a,'Facecolor','black');

lo = load('location.mat');%%%%%%%%%%%%%%%%%%%%yj,ps

load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]

for time = 1 : maxTime
    fprintf("time: %d\n", time);
    set(handles.current_3D,'string',num2str(time));
    %��� �̵�
    for num = 1 : num_UAV
        dist_x(num,1).in = [lo.time_best.pos(time,2*num-1)-0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)-0.25;
            lo.time_best.pos(time,2*num-1)-0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)+0.25;
            lo.time_best.pos(time,2*num-1)-0.25;];
        dist_y(num,1).in = [lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)+1;
            lo.time_best.pos(time,2*num-1)+1;
            lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)-1;
            lo.time_best.pos(time,2*num-1)+1;
            lo.time_best.pos(time,2*num-1)+1;];
        dist_x(num,2).in = [lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)+1;
            lo.time_best.pos(time,2*num)+1;
            lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)-1;
            lo.time_best.pos(time,2*num)+1;
            lo.time_best.pos(time,2*num)+1;];
        dist_y(num,2).in = [lo.time_best.pos(time,2*num)-0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)-0.25;
            lo.time_best.pos(time,2*num)-0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)+0.25;
            lo.time_best.pos(time,2*num)-0.25;];
    end
    for t = 0:0.1:1
        for num = 1 : num_UAV
            vertex_x(num).in(:,1,:) = temp_x(num).in(:,1,:) + (dist_x(num,1).in - temp_x(num).in(:,1,:))*t;%���γ׸��� x�ప update
            vertex_y(num).in(:,1,:) = temp_y(num).in(:,1,:) + (dist_y(num,1).in - temp_y(num).in(:,1,:))*t;%���γ׸��� y�ప update
            vertex_x(num).in(:,2,:) = temp_x(num).in(:,2,:) + (dist_x(num,2).in - temp_x(num).in(:,2,:))*t;%y�ప update
            vertex_y(num).in(:,2,:) = temp_y(num).in(:,2,:) + (dist_y(num,2).in - temp_y(num).in(:,2,:))*t;
            
            set(dronex(num).in,'Vertices',vertex_x(num).in);
            set(droney(num).in,'Vertices',vertex_y(num).in);
            view(3);
            drawnow;
        end
    end
    for num = 1:num_UAV %��п��� ���� �� ������
        pl(num)=stem3(lo.time_best.pos(time,2*num-1),lo.time_best.pos(time,2*num),30.5,'color',UAV_Color(num));
        
        %temp �� �ٲٱ�
        temp_x(num).in = vertex_x(num).in;
        temp_y(num).in = vertex_y(num).in;
    end
    
    % ��� ���ἱ ǥ��
    for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
        one = drone_numbers(time,i);
        for j = i+1 : 6 % �ִ��а��� +1
            if(j==6)
                if(connection_drones(time,one,num_UAV+1)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_antenna],...
                        [lo.time_best.pos(time,2*one) y_antenna],[30.5 z_antenna],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,num_UAV+1)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_antenna],...
                        [lo.time_best.pos(time,2*one) y_antenna],[30.5 z_antenna],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            else
                two = drone_numbers(time,j);
                if(connection_drones(time,one,two)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,two)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            end
        end
    end
    pause(1);
    delete(pl);
    for i = 6-num_UAV : 5
        for j = i+1 : 6 % �ִ��а��� +1
            one = drone_numbers(time,i);
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1. || connection_drones(time,one,two)==2.)
                delete(line_(i,j));
            end
        end
    end
end


% --- Executes on button press in sensor.
function sensor_Callback(hObject, eventdata, handles)
global  sensor_type_text num_sensor
cla reset;
axes(handles.threeD);
x = 0:0.5:20;
y = 0:0.5:20;
[X,Y]= meshgrid(x,y);
Z = (X-5).*5.*exp(-(X-8).^2-(Y-8).^2)-sqrt((X-2).^2+(Y-2).^2)+10.*2.*exp(-(X-5).^2-(Y-4).^2)...
    + sin(2*X) + sin(2*Y)+10;
surf(Z);
set(handles.threeD,'xgrid','on','ygrid','on','zgrid','on','xlim',[-1 20],'ylim',[-1 20],'zlim',[-5 40]);
xlabel(handles.threeD,'X�Ÿ�(10m)');
ylabel(handles.threeD,'Y�Ÿ�(10m)');
zlabel(handles.threeD,'Z����(10m)');
title(handles.threeD, '3DTopology & Drone movement');
hold on;
load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp');
col = hsv(5);
for i=1:sensor_type_text
    for j=1: num_sensor(1,i)
        if i==1
            a = plot3(handles.threeD,sensor_x_temp(i, j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i==2
            b = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 3
            c = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 4
            d = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j),func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        elseif i == 5
            e = plot3(handles.threeD,sensor_x_temp(i,j), sensor_y_temp(i,j), func_Zaxis(sensor_x_temp(i,j),sensor_y_temp(i,j)),...
                '-s','MarkerEdgeColor','red','MarkerSize',5,'MarkerFaceColor',col(i,:));
            hold on
        end
    end
end
hold on
rotate3d on



function current_3D_Callback(hObject, eventdata, handles)
global dronex droney num_UAV UAV_Color flag_d lineColor line_
time = str2double(get(handles.current_3D,'String'));
fprintf("time: %d\n", time);
lo = load('location.mat');%%%%%%%%%%%%%%%%%%%%yj,ps
load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]

flag_d = flag_d + 1;
if flag_d > 1
    for i = 1 : num_UAV
        delete(dronex(i).in);
        delete(droney(i).in);
    end
    delete(line_)
end

for i = 1 : num_UAV +1 %��� �����
    if(i==num_UAV+1)
        x_antenna = 0;
        y_antenna = 0;
        z_antenna = func_Zaxis(x_antenna,y_antenna)+1;   %# The z data for the image corners
        break;
    end
    
    vertex_x(i).in = [0.75 0 30 ; 1.25 0 30 ; 1.25 2 30 ; 0.75 2 30 ; 0.75 0 31; 1.25 0 31; 1.25 2 31;0.75 2 31];
    vertex_y(i).in = [0 1 30 ; 0 1.5 30 ; 2 1.5 30 ; 2 1 30 ; 0 1 31; 0 1.5 31; 2 1.5 31;2 1 31];
    face_x(i).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    face_y(i).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    %z_drone(i) = 30%func_Zaxis_3(vertex_x(i).in,vertex(i).s);   %# The z data for the image corners
    temp_x(i).in = vertex_x(i).in;
    temp_y(i).in = vertex_y(i).in;
    
    dronex(i).in = patch('Vertices',vertex_x(i).in,'faces',face_x(i).in,'Facecolor',UAV_Color(i),'EdgeColor',UAV_Color(i),'FaceAlpha',.6);%x_drone(1), y_drone(1),z_drone(1),img1);
    droney(i).in = patch('Vertices',vertex_y(i).in,'faces',face_y(i).in,'Facecolor',UAV_Color(i),'EdgeColor',UAV_Color(i),'FaceAlpha',.6);%x_drone(1), y_drone(1),z_drone(1),img1);
    view(3);
end
vertex_a=[0 0 z_antenna;  1 0 z_antenna;   1 1 z_antenna;  0 1 z_antenna;  0.5 0.5 z_antenna+5];
face_a=[1 2 3 4;   1 2 5 NaN;   2 3 5 NaN;   3 4 5 NaN;  4 1 5 NaN];
antenna = patch('Vertices',vertex_a,'faces',face_a,'Facecolor','black');

%��� �̵�
for num = 1 : num_UAV
    vertex_x(num).in = [0.75 0 30 ; 1.25 0 30 ; 1.25 2 30 ; 0.75 2 30 ; 0.75 0 31; 1.25 0 31; 1.25 2 31;0.75 2 31];
    vertex_y(num).in = [0 1 30 ; 0 1.5 30 ; 2 1.5 30 ; 2 1 30 ; 0 1 31; 0 1.5 31; 2 1.5 31;2 1 31];
    face_x(num).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    face_y(num).in = [1 2 3 4;1 2 6 5;2 3 7 6;3 4 8 7;1 4 8 5;5 6 7 8];
    
    vertex_x(num).in(:,1,:) = vertex_x(num).in(:,1,:) + lo.time_best.pos(time,2*num-1) -1;
    vertex_y(num).in(:,1,:) = vertex_y(num).in(:,1,:) + lo.time_best.pos(time,2*num-1) -1;
    vertex_x(num).in(:,2,:) = vertex_x(num).in(:,2,:) + lo.time_best.pos(time,2*num) -1;
    vertex_y(num).in(:,2,:) = vertex_y(num).in(:,2,:) + lo.time_best.pos(time,2*num) -1;
    
    set(dronex(num).in,'Vertices',vertex_x(num).in);
    set(droney(num).in,'Vertices',vertex_y(num).in);
    view(3);
    
    pl(num)=stem3(lo.time_best.pos(time,2*num-1),lo.time_best.pos(time,2*num),30.5,'color',UAV_Color(num));
end

% ��� ���ἱ ǥ��
for num = 6-num_UAV : 5 % �ִ� ��� ���� = 5
    one = drone_numbers(time,num);
    for j = num+1 : 6 % �ִ��а��� +1
        if(j==6)
            if(connection_drones(time,one,num_UAV+1)==1.)
                fprintf("%d--base\n",one);
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_antenna],...
                    [lo.time_best.pos(time,2*one) y_antenna],[30.5 z_antenna],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
            elseif(connection_drones(time,one,num_UAV+1)==2.)
                fprintf("%d-base\n",one);
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_antenna],...
                    [lo.time_best.pos(time,2*one) y_antenna],[30.5 z_antenna],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
            end
        else
            two = drone_numbers(time,j);
            if(connection_drones(time,one,two)==1.)
                fprintf("%d--%d\n",one,two);
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                    [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
            elseif(connection_drones(time,one,two)==2.)
                fprintf("%d-%d\n",one,two);
                line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                    [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                    'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
            end
        end
    end
end
pause(1);
delete(pl);

% --- Executes during object creation, after setting all properties.
function current_3D_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in imageBtn.
function imageBtn_Callback(hObject, eventdata, handles)
global maxTime UAV_img flag_i UAV_Color lineColor num_UAV drone_
flag_i = flag_i + 1;
if flag_i > 1
   delete (drone_);
end
alpha(.6)
num_UAV = 3;
% �̹�����
droneimage(1).in = imread('drone1.jpg');
droneimage(2).in = imread('drone2.jpg');
droneimage(3).in = imread('drone3.jpg');
droneimage(4).in = imread('drone4.jpg');
droneimage(5).in = imread('drone5.jpg');
antenna = imread('antenna.jpg');

lo = load('location.mat'); % UAV ��ġ ��

%�̹��� ������
a = zeros(num_UAV);
b = zeros(num_UAV);
for i=1:num_UAV
    x_drone(i).in = [a(i) a(i)+1 ; a(i) a(i)+1];
    y_drone(i).in = [b(i)+1 b(i) ; b(i)+1 b(i)];
end
z_drone = [33 33; 30 30];
x_a = 1; y_a = 1; z_a = 1;
x_antenna = [x_a-0.5 x_a+0.5 ; x_a-0.5 x_a+0.5];
y_antenna = [y_a+0.5 y_a-0.5 ; y_a+0.5 y_a-0.5];
z_antenna = [z_a+2 z_a+2; z_a-1 z_a-1];

% �׷����� �̹��� ǥ��
antenna = surf(x_antenna,y_antenna,z_antenna,'CData',antenna,'FaceColor','texturemap');
for i=1:num_UAV
    drone_(i).in = surf(x_drone(i).in,y_drone(i).in,z_drone,'CData',droneimage(i).in,'FaceColor','texturemap');
    alpha(drone_(i).in,.6);
end

lo = load('location.mat');%%%%%%%%%%%%%%%%%%%%yj,ps
load('connection_drones.mat','connection_drones');
load('drone_numbers.mat','drone_numbers'); %[last_drone,second_drone_num,base_drone_num]

for time = 1 : maxTime
    fprintf("time: %d\n", time);
    set(handles.current_3D,'string',num2str(time));
    %��� �̵�
    for t = 0:0.1:1
        for i = 1 : num_UAV
            upA(i) = a(i) + (lo.time_best.pos(time,2*i-1)-a(i))*t;
            upB(i) = b(i) + (lo.time_best.pos(time,2*i)-b(i))*t;
            updatedX = [upA(i) upA(i)+1; upA(i) upA(i)+1];
            updatedY = [upB(i)+1 upB(i); upB(i)+1 upB(i)];
            
            set(drone_(i).in, 'Xdata', updatedX);
            set(drone_(i).in, 'Ydata', updatedY);
            drawnow;
        end
    end
    for num = 1:num_UAV %��п��� ���� �� ������
        pl(num)=stem3(lo.time_best.pos(time,2*num-1),lo.time_best.pos(time,2*num),30.5,'color',UAV_Color(num));
        
        %temp �� �ٲٱ�
        a(num) = upA(num);
        b(num) = upB(num);
    end
    
    % ��� ���ἱ ǥ��
    for i = 6-num_UAV : 5 % �ִ� ��� ���� = 5
        one = drone_numbers(time,i);
        for j = i+1 : 6 % �ִ��а��� +1
            if(j==6)
                if(connection_drones(time,one,num_UAV+1)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_a],...
                        [lo.time_best.pos(time,2*one) y_a],[30.5 z_a],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,num_UAV+1)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) x_a],...
                        [lo.time_best.pos(time,2*one) y_a],[30.5 z_a],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            else
                two = drone_numbers(time,j);
                if(connection_drones(time,one,two)==1.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','--');%lineColor(one),'Marker','.','LineStyle','--');
                elseif(connection_drones(time,one,two)==2.)
                    line_(i,j)=line([lo.time_best.pos(time,2*one-1) lo.time_best.pos(time,2*two-1)],...
                        [lo.time_best.pos(time,2*one) lo.time_best.pos(time,2*two)],[30.5 30.5],...
                        'Color',lineColor(one,:),'Marker','.','LineWidth',2,'LineStyle','-');
                end
            end
        end
    end
    pause(1);
    delete(pl);
    for i = 6-num_UAV : 5
        for j = i+1 : 6 % �ִ��а��� +1
            one = drone_numbers(time,i);
            if(j==6) two = num_UAV+1;  %base station
            else two = drone_numbers(time,j); end
            if(connection_drones(time,one,two)==1. || connection_drones(time,one,two)==2.)
                delete(line_(i,j));
            end
        end
    end
end