function [pl1]=func_pathloss(Distance, t_avgSNR)

[num_Node1, num_Node2] = size(Distance);
p = pi;

Gr = 1;
Gt = 1;
lambda = 1/8;
N0 = 10^-12;
Pt = 0.05;

for order1 = 1:num_Node1
    for order2 = 1:num_Node2
        Pr(order1, order2) = (Gr*Gt*lambda^2*Pt)/(4*p*Distance(order1, order2)*100)^2;
    end
end

Pmin = 5*10^-12; 

N = 20;
cm = 1/2;
km = 1/2;

aN = log10(N*cm)/km;
bN = 1/km;

for order1 = 1:num_Node1
    for order2 = 1:num_Node2
        if Distance(order1, order2) < 0
            avgPSR1(order1, order2) = 1;
        else
            r_avgSNR1(order1, order2) = 10*log10(Pr(order1, order2)/N0);
            avgPER1(order1, order2) = 1 - exp(-aN/r_avgSNR1(order1, order2))*gamma(1+bN/r_avgSNR1(order1, order2));
            avgPSR1(order1, order2) = 1 - (avgPER1(order1, order2))^3;
            if avgPSR1(order1, order2) > 1
                avgPSR1(order1, order2) = 1;
            end
            if Pr(order1, order2) < Pmin
                avgPSR1(order1, order2) = 10^-100;
            end
        end
    end
end
pl1 = avgPSR1;