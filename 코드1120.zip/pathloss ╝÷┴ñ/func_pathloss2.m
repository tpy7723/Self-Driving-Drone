function [pl1]=func_pathloss2(Distance, t_avgSNR)

N = 20;
cm = 1/2;
km = 1/2;

aN = log10(N*cm)/km;
bN = 1/km;


if Distance < 0
    avgPSR1 = 1;
else
    r_avgSNR1 = t_avgSNR;
    avgPER1 = 1 - exp(-aN/r_avgSNR1)*gamma(1+bN/r_avgSNR1);
    avgPSR1 = 1 - (avgPER1)^3;
    if avgPSR1 > 1
        avgPSR1 = 1;
    end
end

pl1 = avgPSR1;