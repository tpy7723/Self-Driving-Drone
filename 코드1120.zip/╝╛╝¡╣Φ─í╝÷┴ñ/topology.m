clc
clear all
close all

x = 0:20;
y = 0:20;

% ���� ����
sensor_type = 3;

% �ִ�, �ּ� ��ü ���� ����
total_sensor_min = 300;
total_sensor_max = 700;

%% ���� ����
% % �ִ�, �ּ� ���� ���� �� ���� ����
% num_sensor_min = ceil(total_sensor_min / sensor_type);
% num_sensor_max = ceil(total_sensor_max / sensor_type); % �Ҽ����� ��� �ø�
% 
% sensor_x_temp(1:sensor_type, 1:num_sensor_max) = 100; % ������ x��ǥ
% sensor_y_temp(1:sensor_type, 1:num_sensor_max) = 100; % ������ y��ǥ

% for i=1:sensor_type
%     num_sensor = randi([num_sensor_min, num_sensor_max]); % ���� ���� �� ���� ����
%     for j=1:num_sensor
%         sensor_x_temp(i, j) = rand*20;
%         sensor_y_temp(i, j) = rand*20; % ��ü �ʿ� �����ϰ� ��ġ
%         if i==1
%             a = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:*');
%             hold on
%         elseif i==2
%             b = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:o');
%             hold on
%         elseif i == 3
%             c = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:x');
%             hold on
%         elseif i == 4
%             d = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:d');
%         elseif i == 5
%             e = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:h');
%         end
% 
%         if sensor_x_temp(i, j) <= 10 && sensor_y_temp(i, j) <= 10
%             sensor_snr(i, j) = randn*2 + 3;
%         elseif sensor_x_temp(i, j) <= 10 && (sensor_y_temp(i, j) > 10 && sensor_y_temp(i, j) <= 20)
%             sensor_snr(i, j) = randn*2 + 6;
%         elseif (sensor_x_temp(i, j) > 10 && sensor_x_temp(i, j) <= 20) && sensor_y_temp(i, j) <= 10
%             sensor_snr(i, j) = randn*2 + 4;
%         else
%             sensor_snr(i, j) = randn*2 + 7;
%         end
%     end
% end

%% ����(Ŭ������)
num_cluster = 10; % Ŭ������ ����
topo_r = 1.5; % % for i=1:sensor_type

num_sensor_min = ceil(total_sensor_min / sensor_type);
num_sensor_max = ceil(total_sensor_max / sensor_type);

% Ŭ������ 
for i=1:num_cluster
    topo_x(i) = randi([2 18]);
    topo_y(i) = randi([2 18]);
end

sensor_x_temp(1:sensor_type, 1:num_sensor_max) = 100; 
sensor_y_temp(1:sensor_type, 1:num_sensor_max) = 100;
for i=1:sensor_type
    num_sensor = randi([num_sensor_min, num_sensor_max]); % ���� ���� �� ���� ����
    tt(i) = num_sensor;
    for j=1:num_sensor
        temp_1 = randi([1, 10]);
        sensor_x_temp(i, j) = randn*sqrt(topo_r) + topo_x(temp_1);
        sensor_y_temp(i, j) = randn*sqrt(topo_r) + topo_y(temp_1);
        if i==1
            a = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:*');
            hold on
        elseif i==2
            b = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:o');
            hold on
        elseif i == 3
            c = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:x');
            hold on
        elseif i == 4
            d = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:d');
            hold on
        elseif i == 5
            e = plot(sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:h');
            hold on
        end

        if sensor_x_temp(i, j) <= 10 && sensor_y_temp(i, j) <= 10
            sensor_snr(i, j) = randn*2 + 3;
        elseif sensor_x_temp(i, j) <= 10 && (sensor_y_temp(i, j) > 10 && sensor_y_temp(i, j) <= 20)
            sensor_snr(i, j) = randn*2 + 6;
        elseif (sensor_x_temp(i, j) > 10 && sensor_x_temp(i, j) <= 20) && sensor_y_temp(i, j) <= 10
            sensor_snr(i, j) = randn*2 + 4;
        else
            sensor_snr(i, j) = randn*2 + 7;
        end
    end
end

axis([0 20 0 20])
save sensor_x_temp.mat sensor_x_temp
save sensor_y_temp.mat sensor_y_temp
save sensor_snr.mat sensor_snr