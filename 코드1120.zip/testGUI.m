function varargout = testGUI(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @testGUI_OpeningFcn, ...
    'gui_OutputFcn',  @testGUI_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end


function testGUI_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cla(handles.axes1); % Do a complete and total reset of the axes.
cla(handles.axes3); % Do a complete and total reset of the axes.

global maxIter num_sensor swarm_size num_UAV maxTime sensor_type_text topo_r num_cluster c1 ...
    c2 total_sensor_max total_sensor_min sensor_value UAV_Gr UAV_Gt sen_Gt sen_lamda sen_Pt cr r slash height UAV_distance sen_distance
t= 1:19;
plot(handles.axes1,t,0);
set(handles.axes1, 'xgrid','on','ygrid','on','xlim',[0 20],'ylim',[0 500]);
title(handles.axes1, 'Utility to Time');
xlabel(handles.axes1,'Ƚ��');
ylabel(handles.axes1,'��ƿ��Ƽ');

plot(handles.axes3,t,0);
set(handles.axes3, 'xgrid','on','ygrid','on','xlim',[0 20],'ylim',[0 20]);
title(handles.axes3, 'Topology & Drone movement');
xlabel(handles.axes3,'�Ÿ�(100m)');
ylabel(handles.axes3,'�Ÿ�(100m)');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eval ('guage');  %������ ǥ�� ��� �ּ�ó���Ұ�!
select_distance(hObject, eventdata, handles);
select_distance2(hObject, eventdata, handles);

function varargout = testGUI_OutputFcn(hObject, eventdata, handles)

varargout{1} = handles.output;

% f_open = fopen("value.txt",'w');
% fprintf(f_open,'%s%d%s%d%s%d%s%d%s%d%s%d%s%d%s%d',"{ 'maxIter':", maxIter,", 'num_cluster' : ",num_cluster ...
%     ,", 'num_sensor' :",num_sensor,", 'swarm_size': ",swarm_size,", 'cr':",cr,", 'sen_distance':",sen_distance,", 'map_size': ",...
%     map_size,", 'num_UAV':",num_UAV," }");
% fclose(f_open);
function initialize_Callback(hObject, eventdata, handles)
global maxIter swarm_size cr r num_UAV maxTime sensor_type_text Gr Gt min_a max_a 

cla(handles.axes1);
var = [maxIter swarm_size cr r num_UAV maxTime  sensor_type_text Gr Gt ];
save var_mat var;
load('finish.mat','finish');
t=1:length(finish);
max_a = max(finish);
min_a = min(finish);
if min_a < 0
    min_a=0;
end

datacursormode on;
plot(handles.axes1,t,finish);
set(handles.axes1, 'xgrid','on','ygrid','on','xlim',[0 maxTime],'ylim',[min_a-50 max_a+50]);
title(handles.axes1, 'Utility to Time');
xlabel(handles.axes1,'Ƚ��');
ylabel(handles.axes1,'��ƿ��Ƽ');

function pushbutton2_Callback(hObject, eventdata, handles,event_obj) %������ġ
global  num_sensor sensor_type_text num_cluster topo_r total_sensor_min total_sensor_max
% %%%%% testGUI_3D�� �ٷ�� ���� �ڵ�
% h_testGUI_3D = testGUI_3D.fig;
% handles.h_testGUI_3D = guihandles(h_testGUI_3D);
% guidata(hObject,handles);
% %%%%%
axes(handles.axes3); % Make averSpec the current axes.
cla(handles.axes1); % Do a complete and total reset of the axes.
cla(handles.axes3); % Do a complete and total reset of the axes.

func_topology(sensor_type_text,total_sensor_min,total_sensor_max,num_cluster,topo_r);

num_sensor_min = ceil(total_sensor_min / sensor_type_text);
num_sensor_max = ceil(total_sensor_max / sensor_type_text);

load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp');
[sensor_type, num_sensor] = size(sensor_x_temp);
sensor_type
num_sensor
for i=1:sensor_type
    for j=1:num_sensor
        if i==1
            a = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:*');
            hold on
        elseif i==2
            b = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:o');
            hold on
        elseif i == 3
            c = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:x');
            hold on
        elseif i == 4
            d = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:d');
            hold on
        elseif i == 5
            e = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:h');
            hold on
        end
    end
end

datacursormode on;
set(handles.axes3, 'xgrid','on','ygrid','on','xlim',[0 20],'ylim',[0 20]);
title(handles.axes3, 'Topology & Drone movement');
xlabel(handles.axes3,'�Ÿ�(100m)');
ylabel(handles.axes3,'�Ÿ�(100m)');
eval testGUI_3D;




function execute_Callback(hObject, eventdata, handles) % ���� ��ư
global maxIter num_sensor swarm_size cr r num_UAV maxTime sensor_type_text Gr Gtsensor_value
axes(handles.axes1);
axes(handles.axes3);
cla(handles.axes1); % Do a complete and total reset of the axes.
cla(handles.axes3); % Do a complete and total reset of the axes.

sensor_value = get(handles.sensor_value,'String');
temp_sensor_val = zeros(1,sensor_type_text);
for j = 1:sensor_type_text
    [token_, sensor_value] = strtok(sensor_value);
    temp_sensor_val(1,j)=str2double(token_);
end

save temp_sensor_val temp_sensor_val;
% func_Location_Searching();
location_searching_func(hObject, eventdata, handles);

function seeTime_Callback(hObject, eventdata, handles) %�ùķ��̼� ���� ��ư
global maxTime
% sensorBtn_Callback(hObject, eventdata, handles);
move_drone_func(hObject, eventdata, handles,1,maxTime,1);

function current_Callback(hObject, eventdata, handles) %���� ��ƿ��Ƽ / ��ġ ��ư

global input_time
move_drone_func(hObject, eventdata, handles,input_time,input_time,2);

function num_cluster_Callback(hObject, eventdata, handles)
global num_cluster
num_cluster = str2double(get(handles.num_cluster,'String'));

function num_cluster_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global num_cluster
num_cluster = 10;

function total_sensor_max_Callback(hObject, eventdata, handles)
global total_sensor_max
total_sensor_max = str2double(get(handles.total_sensor_max,'String'))

function total_sensor_max_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global total_sensor_max
total_sensor_max = 700;

function total_sensor_min_Callback(hObject, eventdata, handles)
global total_sensor_min
total_sensor_min = str2double(get(handles.total_sensor_min,'String'));

function total_sensor_min_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'));
    set(hObject,'BackgroundColor','white');
end
global total_sensor_min
total_sensor_min = 300;

function topo_r_Callback(hObject, eventdata, handles)
global topo_r
topo_r = str2double(get(handles.topo_r,'String'));

function topo_r_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global topo_r
topo_r=1.5;

function input_time_Callback(hObject, eventdata, handles)
global input_time
input_time = str2double(get(handles.input_time,'String'));

function input_time_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global input_time;
input_time = 1;

function maxIter_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global maxIter;
maxIter = 300;

function maxIter_Callback(hObject, eventdata, handles)
global maxIter
maxIter = str2double(get(handles.maxIter,'String'))

function cr_Callback(hObject, eventdata, handles)
global cr
cr = str2double(get(handles.cr,'String'));

function cr_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global cr
cr = 10;

function num_UAV_Callback(hObject, eventdata, handles)
global num_UAV
num_UAV = str2double(get(handles.num_UAV,'String'))

function num_UAV_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global num_UAV;
num_UAV = 3;

function sen_distance_Callback(hObject, eventdata, handles)

function sen_distance_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global r slash height
r = sqrt(slash^2 - height^2);
set(handles.c2,'string',num2str(r));

function swarm_size_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global swarm_size
swarm_size = 30;

function swarm_size_Callback(hObject, eventdata, handles)
global swarm_size
swarm_size = str2double(get(handles.swarm_size,'String'))

function maxTime_Callback(hObject, eventdata, handles)
global maxTime
maxTime = str2double(get(handles.maxTime,'String'))

function maxTime_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global maxTime
maxTime = 20;

function sensor_type_text_Callback(hObject, eventdata, handles)
global sensor_type_text
sensor_type_text = str2double(get(handles.sensor_type_text,'String'))

function sensor_type_text_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global sensor_type_text
sensor_type_text = 3;

function UAV_Gr_Callback(hObject, eventdata, handles)
global UAV_Gr
UAV_Gr = str2double(get(handles.UAV_Gr,'String'))
select_distance(hObject, eventdata, handles);
select_distance2(hObject, eventdata, handles);

function UAV_Gr_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global UAV_Gr
UAV_Gr = 1;

function UAV_Gt_Callback(hObject, eventdata, handles)
global UAV_Gt
UAV_Gt = str2double(get(handles.UAV_Gt,'String'))
select_distance(hObject, eventdata, handles);

function UAV_Gt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global UAV_Gt
UAV_Gt = 1;

function sensor_value_Callback(hObject, eventdata, handles)
global sensor_value
sensor_value = get(handles.sensor_value,'String')

function sensor_value_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global sensor_value
sensor_value = '10 15 20';



function move_drone_func(~, ~, handles, start_time, stop_time, flag)
global maxTime num_sensor cr drone_1 drone_2 drone_3 num_UAV sensor_type_text
axes(handles.axes1);
axes(handles.axes3);
cla(handles.axes1); % Do a complete and total reset of the axes.
cla(handles.axes3); % Do a complete and total reset of the axes.

load('finish','finish'); % ��ƿ��Ƽ ���� ���
t=1:maxTime;
datacursormode on;
plot(handles.axes1,t,finish);
set(handles.axes1, 'xgrid','on','ygrid','on','xlim',[0 maxTime],'ylim',[min(finish)-50 max(finish)+50]);
title(handles.axes1, 'Utility to Time');
xlabel(handles.axes1,'Ƚ��');
ylabel(handles.axes1,'��ƿ��Ƽ');
hold(handles.axes1,'on');

% ���� ��ǥ �ҷ�����
load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp');

%�ε��� �ʱ�ȭ
base_index=1;
second_index=1;
third_index=1;
fourth_index=1;
fiveth_index=1;
axes(handles.axes3);
sensor_type_text
for i=1:sensor_type_text
    for j=1:num_sensor
        if i==1
            a = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:*');
            hold on
        elseif i==2
            b = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:o');
            hold on
        elseif i == 3
            c = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:x');
            hold on
        elseif i == 4
            d = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:d');
            hold on
        elseif i == 5
            e = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:h');
            hold on
        end
    end
end
hold on

datacursormode on;
set(handles.axes3, 'xgrid','on','ygrid','on','xlim',[0 20],'ylim',[0 20]);
title(handles.axes3, 'Topology & Drone movement');
xlabel(handles.axes3,'�Ÿ�(100m)');
ylabel(handles.axes3,'�Ÿ�(100m)');

% �̹�����
droneimage(1).in = imread('drone1.jpg');
droneimage(2).in = imread('drone2.jpg');
droneimage(3).in = imread('drone3.jpg');
droneimage(4).in = imread('drone4.jpg');
droneimage(5).in = imread('drone5.jpg');
antenna = imread('antenna.jpg');

% �� UAV�� ����
droneimage(1).color = 'green';
droneimage(2).color = 'red';
droneimage(3).color = 'blue';
droneimage(4).color = 'magenta';
droneimage(5).color = [0.87 0.55 0.14];
time_best.pos(maxTime,1:10) = 0;
time_best = load('location.mat'); % UAV ��ġ ��

%�̹��� ������
for i=1:num_UAV
    x_drone(i).in = [0 1];
    y_drone(i).in = [1 0];
end
x_antenna = [0 1];
y_antenna = [1 0];

grid on
hold on

%�׷����� �̹��� ǥ��
for i=1:num_UAV
    drone_(i).in = image(x_drone(i).in,y_drone(i).in,droneimage(i).in);
    alpha(drone_(i).in,.7) % �����ϰ� �ٲ���
end
antenna_1 = image(x_antenna,y_antenna,antenna);

hold off
axis([0 20 0 20]);

%�̵��� �̹����� ����
for i=1:num_UAV
    temp_x(i).in= x_drone(i).in;
    temp_y(i).in= y_drone(i).in;
end

for time = start_time : stop_time
    fprintf("time: %d\n", time);
    
    %���� �ʱ�ȭ
    for i=1:11
        line_(i) = 0;
    end
    
    %Ÿ�ӿ� ���� ��ƿ��Ƽ �� ǥ��
    S=['  Time= ' num2str(time)] ;
    M=['  Utility= ' num2str(finish(time))];
    a(1)=plot(handles.axes1,time,finish(time),'o','MarkerFaceColor',[1 .6 .6]);
    a(2)=text(handles.axes1,time,finish(time), {S,M} ,'HorizontalAlignment','left','Color','red','FontSize',9);
    a(3)=line(handles.axes1,[time time],[0 finish(time)],'Color','r','Marker','.','LineStyle','--');
    a(4)=line(handles.axes1,[0 time],[finish(time) finish(time)],'Color','r','Marker','.','LineStyle','--');
    
    if num_UAV ==1
        UAV(1).in = [time_best.pos(time,1) time_best.pos(time,2)];
        
        [B,I] = sort([p_distance([0 0],UAV(1).in)])
        time_best.pos(time,:) = [UAV(I(1)).in];    
        
    elseif num_UAV ==2
        UAV(1).in = [time_best.pos(time,1) time_best.pos(time,2)];
        UAV(2).in = [time_best.pos(time,3) time_best.pos(time,4)];
        
        [B,I] = sort([p_distance([0 0],UAV(1).in) p_distance([0 0],UAV(2).in)])
        time_best.pos(time,:) = [UAV(I(1)).in UAV(I(2)).in];
    
    elseif num_UAV ==3
        time_best.pos
        UAV(1).in = [time_best.pos(time,1) time_best.pos(time,2)];
        UAV(2).in = [time_best.pos(time,3) time_best.pos(time,4)];
        UAV(3).in = [time_best.pos(time,5) time_best.pos(time,6)];
        
        [B,I] = sort([p_distance([0 0],UAV(1).in) p_distance([0 0],UAV(2).in) p_distance([0 0],UAV(3).in)])
        time_best.pos(time,:) = [UAV(I(1)).in UAV(I(2)).in UAV(I(3)).in];
        
    elseif num_UAV ==4
        UAV(1).in = [time_best.pos(time,1) time_best.pos(time,2)];
        UAV(2).in = [time_best.pos(time,3) time_best.pos(time,4)];
        UAV(3).in = [time_best.pos(time,5) time_best.pos(time,6)];
        UAV(4).in = [time_best.pos(time,7) time_best.pos(time,8)];
        
        [B,I] = sort([p_distance([0 0],UAV(1).in) p_distance([0 0],UAV(2).in) p_distance([0 0],UAV(3).in) p_distance([0 0],UAV(4).in)])
        time_best.pos(time,:) = [UAV(I(1)).in UAV(I(2)).in UAV(I(3)).in UAV(I(4)).in];
  
    elseif num_UAV ==5
        UAV(1).in = [time_best.pos(time,1) time_best.pos(time,2)];
        UAV(2).in = [time_best.pos(time,3) time_best.pos(time,4)];
        UAV(3).in = [time_best.pos(time,5) time_best.pos(time,6)];
        UAV(4).in = [time_best.pos(time,7) time_best.pos(time,8)];
        UAV(5).in = [time_best.pos(time,9) time_best.pos(time,10)];
        
        [B,I] = sort([p_distance([0 0],UAV(1).in) p_distance([0 0],UAV(2).in) p_distance([0 0],UAV(3).in) p_distance([0 0],UAV(4).in) p_distance([0 0],UAV(5).in)])
        time_best.pos(time,:) = [UAV(I(1)).in UAV(I(2)).in UAV(I(3)).in UAV(I(4)).in UAV(I(5)).in ];
       
    end
    
    
    for t = 0:0.1:1
        for i = 1:num_UAV
            %�̵��� UAV��ǥ
            updatedX(i).in = temp_x(i).in + (time_best.pos(time,2*i-1)-temp_x(i).in(1)-0.6)*t;
            updatedY(i).in = temp_y(i).in + (time_best.pos(time,2*i)-temp_y(i).in(2)-0.6)*t;
            
            %�ش� UAV�̹����� �̵��� UAV��ǥ�� ������
            set(drone_(i).in, 'Xdata', updatedX(i).in);
            set(drone_(i).in, 'Ydata', updatedY(i).in);
            drawnow; %���������� �׸�
        end
        
    end
    
    %�� ��� �� �������� x y ��ǥ (6���� ������ [0 0])
    alldrone_xy = zeros(6,2) + 100;
    alldrone_xy(6,:) = [0 0];
    
    test(1).in = [time_best.pos(time,1) time_best.pos(time,2)]; %��
    test(2).in = [time_best.pos(time,3) time_best.pos(time,4)]; %��
    test(3).in = [time_best.pos(time,5) time_best.pos(time,6)]; %��
%     test(1).in
%     test(2).in
%     test(3).in
%     min([p_distance([0 0],test(1).in) p_distance([0 0],test(2).in) p_distance([0 0],test(3).in)])
    
    %1���� x��ǥ 2���� y��ǥ ���� ��� ��� �� �������� ��ǥ alldrone_xy
    for i=1:num_UAV
        alldrone_xy(i,1) = updatedX(i).in(1)+0.5;
        alldrone_xy(i,2) = updatedY(i).in(2)+0.5;
    end
    
    % ������ �� ��е���� �Ÿ�(6��� 6���� ������ ����)
    UAV_distance = func_distance2(alldrone_xy);
    tempnum=100000; %������ ū ��
    
    %ù ��° ���
    for i=1:6
        if tempnum>UAV_distance(6,i) & UAV_distance(6,i)>0 & num_UAV >= 1
            tempnum = UAV_distance(6,i);
            base_drone = alldrone_xy(i,:);
            base_index = i;
        end
    end
    
    %���̽��� ù ��° ��� ����
    if UAV_distance(6,base_index) < 0.8*cr % ����ݰ��� 80���� ���� �����̸� ��
        line_(1)=line([1 alldrone_xy(base_index,1)],[1 alldrone_xy(base_index,2)],'Color',droneimage(base_index).color ,'Marker','.','LineStyle','-');
        connection_drones(time,base_index,num_UAV+1)=2; %base starion�� UAV1 ������ strong connection=2 ����
        connection_drones(time,num_UAV+1,base_index)=2;
    elseif UAV_distance(6,base_index) <= cr % ����ݰ��� 80���� ���� �̻��̸� ����
        line_(1)=line([1 alldrone_xy(base_index,1)],[1 alldrone_xy(base_index,2)],'Color',droneimage(base_index).color ,'Marker','.','LineStyle','--');
        connection_drones(time,base_index,num_UAV+1)=1; %base starion�� UAV1 ������ weak connection=1 ����
        connection_drones(time,num_UAV+1,base_index)=1;
    end
    
    % ���̽� ��а� ����� ����� �Ÿ�
    basedrone_drone = zeros(1,5)+1000;
    for i = 1:num_UAV
        basedrone_drone(i) = UAV_distance(base_index,i);
    end
    
    %�� ��° ���
    tempnum=100000;
    for i=1:5
        if tempnum>basedrone_drone(i) & basedrone_drone(i)>0 & num_UAV >= 2
            tempnum = basedrone_drone(i);
            second_drone = alldrone_xy(i,:);
            second_index = i;
        end
    end
    
    %���̽���а� ������ ��� �ձ�
    if basedrone_drone(second_index) < 0.8*cr & num_UAV >= 1
        line_(2)=line([base_drone(1) alldrone_xy(second_index,1)],[base_drone(2) alldrone_xy(second_index,2)],'Color',droneimage(second_index).color ,'Marker','.','LineStyle','-');
        connection_drones(time,base_index,second_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,second_index,base_index)=2;
    elseif basedrone_drone(second_index) <= cr & num_UAV >= 1
        line_(2)=line([base_drone(1) alldrone_xy(second_index,1)],[base_drone(2) alldrone_xy(second_index,2)],'Color',droneimage(second_index).color ,'Marker','.','LineStyle','--');
        connection_drones(time,base_index,second_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,second_index,base_index)=1;
    end
    
    % ������ ��а� ����� ����� �Ÿ�
    seconddrone_drone = zeros(1,5)+1000;
    for i = 1:num_UAV
        seconddrone_drone(i) = UAV_distance(second_index,i);
    end
    
    %�� ��° ���
    tempnum=100000;
    for i=1:5
        if tempnum>seconddrone_drone(i) & seconddrone_drone(i)>0 & num_UAV >= 3
            if (alldrone_xy(i,:) == second_drone | alldrone_xy(i,:) == base_drone)
                continue;
            else
                tempnum = seconddrone_drone(i);
                third_drone = alldrone_xy(i,:);
                third_index = i; % third drone
            end
        end
    end
    %�ι�°��а� ����° ��� �ձ�
    if seconddrone_drone(third_index) < 0.8*cr & num_UAV >= 3
        line_(3)=line([second_drone(1) alldrone_xy(third_index,1)],[second_drone(2) alldrone_xy(third_index,2)],'Color',droneimage(third_index).color ,'Marker','.','LineStyle','-');
        connection_drones(time,second_index,third_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,third_index,second_index)=2;
    elseif seconddrone_drone(third_index) <= cr & num_UAV >= 3
        line_(3)=line([second_drone(1) alldrone_xy(third_index,1)],[second_drone(2) alldrone_xy(third_index,2)],'Color',droneimage(third_index).color ,'Marker','.','LineStyle','--');
        connection_drones(time,second_index,third_index)=1; %base drone�� UAV1 ������ strong connection=1 ����
        connection_drones(time,third_index,second_index)=1;
    end
    
    % third ��а� ����� ����� �Ÿ�
    thirddrone_drone = zeros(1,5)+1000;
    for i = 1:num_UAV
        thirddrone_drone(i) = UAV_distance(third_index,i);
    end
    
    tempnum=100000;
    % �׹�° ���
    for i=1:5
        if tempnum>thirddrone_drone(i) & thirddrone_drone(i)>0 & num_UAV >= 4
            if (alldrone_xy(i,:) == base_drone | alldrone_xy(i,:) == second_drone | alldrone_xy(i,:) == third_drone)
                continue;
            else
                tempnum = thirddrone_drone(i);
                fourth_drone = alldrone_xy(i,:);
                fourth_index = i; % fourth drone
            end
        end
    end
    
    %����° ��а� �׹�° ��� �ձ�
    if thirddrone_drone(fourth_index) < 0.8*cr & num_UAV >= 4
        line_(4)=line([third_drone(1) alldrone_xy(fourth_index,1)],[third_drone(2) alldrone_xy(fourth_index,2)],'Color',droneimage(fourth_index).color ,'Marker','.','LineStyle','-');
        connection_drones(time,third_index,fourth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fourth_index,third_index)=2;
    elseif thirddrone_drone(fourth_index) <= cr & num_UAV >= 4
        line_(4)=line([third_drone(1) alldrone_xy(fourth_index,1)],[third_drone(2) alldrone_xy(fourth_index,2)],'Color',droneimage(fourth_index).color ,'Marker','.','LineStyle','--');
        connection_drones(time,third_index,fourth_index)=1; %base drone�� UAV1 ������ strong connection=1 ����
        connection_drones(time,fourth_index,third_index)=1;
    end
    
    % fourth ��а� ����� ����� �Ÿ�
    fourthdrone_drone = zeros(1,5)+1000;
    for i = 1:num_UAV
        fourthdrone_drone(i) = UAV_distance(fourth_index,i);
    end
    
    %�ټ���° ���
    tempnum=100000;
    for i=1:5
        if tempnum>fourthdrone_drone(i) & fourthdrone_drone(i)>0 & num_UAV >= 5
            if (alldrone_xy(i,:) == base_drone | alldrone_xy(i,:) == second_drone | alldrone_xy(i,:) == third_drone | alldrone_xy(i,:) == fourth_drone)
                continue;
            else
                tempnum = fourthdrone_drone(i);
                fiveth_drone = alldrone_xy(i,:);
                fiveth_index = i; % fiveth drone
            end
        end
    end
    
    %�׹�° ��а� �ټ���° ��� �ձ�
    if fourthdrone_drone(fiveth_index) < 0.8*cr & num_UAV >= 5
        line_(5)=line([fourth_drone(1) alldrone_xy(fiveth_index,1)],[fourth_drone(2) alldrone_xy(fiveth_index,2)],'Color',droneimage(fiveth_index).color ,'Marker','.','LineStyle','-');
        connection_drones(time,fourth_index,fiveth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,fourth_index)=2;
    elseif fourthdrone_drone(fiveth_index) <= cr & num_UAV >= 5
        line_(5)=line([fourth_drone(1) alldrone_xy(fiveth_index,1)],[fourth_drone(2) alldrone_xy(fiveth_index,2)],'Color',droneimage(fiveth_index).color ,'Marker','.','LineStyle','--');
        connection_drones(time,fourth_index,fiveth_index)=1; %base drone�� UAV1 ������ strong connection=1 ����
        connection_drones(time,fiveth_index,fourth_index)=1;
    end
    
    % �ؿ������ʹ� 1~5 ��� ��� �հ� ���� ���� ����� ��� �ձ� ����
    
    % ���̽���а� third ��� �ձ�
    if basedrone_drone(third_index) < 0.8*cr & num_UAV >= 3
        line_(6)=line([base_drone(1) alldrone_xy(third_index,1)],[base_drone(2) alldrone_xy(third_index,2)],'Color','black' ,'Marker','.','LineStyle','-');
        connection_drones(time,base_index,third_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,third_index,base_index)=2;
    elseif basedrone_drone(third_index) <= cr & num_UAV >= 3
        line_(6)=line([base_drone(1) alldrone_xy(third_index,1)],[base_drone(2) alldrone_xy(third_index,2)],'Color','black' ,'Marker','.','LineStyle','--');
        connection_drones(time,base_index,third_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,third_index,base_index)=1;
    end
    
    % ���̽���а� fourth ��� �ձ�
    if basedrone_drone(fourth_index) < 0.8*cr & num_UAV >= 4
        line_(7)=line([base_drone(1) alldrone_xy(fourth_index,1)],[base_drone(2) alldrone_xy(fourth_index,2)],'Color','black' ,'Marker','.','LineStyle','-');
        connection_drones(time,base_index,fourth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fourth_index,base_index)=2;
    elseif basedrone_drone(fourth_index) <= cr & num_UAV >= 4
        line_(7)=line([base_drone(1) alldrone_xy(fourth_index,1)],[base_drone(2) alldrone_xy(fourth_index,2)],'Color','black' ,'Marker','.','LineStyle','--');
        connection_drones(time,base_index,fourth_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fourth_index,base_index)=1;
    end
    
    % ���̽���а� fiveth ��� �ձ�
    if basedrone_drone(fiveth_index) < 0.8*cr & num_UAV >= 5
        line_(8)=line([base_drone(1) alldrone_xy(fiveth_index,1)],[base_drone(2) alldrone_xy(fiveth_index,2)],'Color','black' ,'Marker','.','LineStyle','-');
        connection_drones(time,base_index,fiveth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,base_index)=2;
    elseif basedrone_drone(fiveth_index) <= cr & num_UAV >= 5
        line_(8)=line([base_drone(1) alldrone_xy(fiveth_index,1)],[base_drone(2) alldrone_xy(fiveth_index,2)],'Color','black' ,'Marker','.','LineStyle','--');
        connection_drones(time,base_index,fiveth_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,base_index)=1;
    end
    
    % �������а� fourth ��� �ձ�
    if seconddrone_drone(fourth_index) < 0.8*cr & num_UAV >= 4
        line_(9)=line([second_drone(1) alldrone_xy(fourth_index,1)],[second_drone(2) alldrone_xy(fourth_index,2)],'Color','black' ,'Marker','.','LineStyle','-');
        connection_drones(time,second_index,fourth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fourth_index,second_index)=2;
    elseif seconddrone_drone(fourth_index) <= cr & num_UAV >= 4
        line_(9)=line([second_drone(1) alldrone_xy(fourth_index,1)],[second_drone(2) alldrone_xy(fourth_index,2)],'Color','black' ,'Marker','.','LineStyle','--');
        connection_drones(time,second_index,fourth_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fourth_index,second_index)=1;
    end
    
    % �������а� fiveth ��� �ձ�
    if seconddrone_drone(fiveth_index) < 0.8*cr & num_UAV >= 5
        line_(10)=line([second_drone(1) alldrone_xy(fiveth_index,1)],[second_drone(2) alldrone_xy(fiveth_index,2)],'Color','black' ,'Marker','.','LineStyle','-');
        connection_drones(time,second_index,fiveth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,second_index)=2;
    elseif seconddrone_drone(fiveth_index) <= cr & num_UAV >= 5
        line_(10)=line([second_drone(1) alldrone_xy(fiveth_index,1)],[second_drone(2) alldrone_xy(fiveth_index,2)],'Color','black' ,'Marker','.','LineStyle','--');
        connection_drones(time,second_index,fiveth_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,second_index)=1;
    end
    
    % third��а� fiveth ��� �ձ�
    if thirddrone_drone(fiveth_index) < 0.8*cr & num_UAV >= 5
        line_(11)=line([third_drone(1) alldrone_xy(fiveth_index,1)],[third_drone(2) alldrone_xy(fiveth_index,2)],'Color','black' ,'Marker','.','LineStyle','-');
        connection_drones(time,third_index,fiveth_index)=2; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,third_index)=2;
    elseif thirddrone_drone(fiveth_index) <= cr & num_UAV >= 5
        line_(11)=line([third_drone(1) alldrone_xy(fiveth_index,1)],[third_drone(2) alldrone_xy(fiveth_index,2)],'Color','black' ,'Marker','.','LineStyle','--');
        connection_drones(time,third_index,fiveth_index)=1; %base drone�� UAV1 ������ strong connection=2 ����
        connection_drones(time,fiveth_index,third_index)=1;
    end
    
    %��ġ ������Ʈ
    for i=1:num_UAV
        temp_x(i).in = updatedX(i).in;
        temp_y(i).in = updatedY(i).in;
    end
    pause(1); % �����ֱ� ���� ��� ����
    if flag==1 % �ùķ��̼� ���� ��ư�� ��
        if time ~= maxTime
            for i=1:11
                if line_(i)~=0
                    delete(line_(i));
                end
                if i<5
                    delete(a(i));
                end
            end
        end
    end
    drone_numbers(time,:) = [fiveth_index fourth_index third_index second_index base_index];
end
save location time_best;


if flag==1 % �ùķ��̼Ǻ��� ��ư�� ��
    save connection_drones connection_drones;
    save drone_numbers drone_numbers;
end

if flag==2 % ���� ��ƿ��Ƽ /��ġ ��ư�� ��
    cla(handles.axes1);
    load('finish','finish')
    t=1:20;
    datacursormode on;
    plot(handles.axes1,t,finish);
    set(handles.axes1, 'xgrid','on','ygrid','on','xlim',[0 maxTime],'ylim',[min(finish)-50 max(finish)+50]);
    title(handles.axes1, 'Utility to Time');
    xlabel(handles.axes1,'Ƚ��');
    ylabel(handles.axes1,'��ƿ��Ƽ');
    hold(handles.axes1,'on');
    S=['  Time= ' num2str(time)] ;
    M=['  Utility= ' num2str(finish(time))];
    plot(handles.axes1,time,finish(time),'o','MarkerFaceColor',[1 .6 .6]);
    text(handles.axes1,time,finish(time), {S,M} ,'HorizontalAlignment','left','Color','red','FontSize',9);
    line(handles.axes1,[time time],[0 finish(time)],'Color','r','Marker','.','LineStyle','--');
    line(handles.axes1,[0 time],[finish(time) finish(time)],'Color','r','Marker','.','LineStyle','--');
end


% --- Executes on button press in sensorBtn.
function sensorBtn_Callback(hObject, eventdata, handles) 
global num_sensor 
load('sensor_x_temp.mat','sensor_x_temp');
load('sensor_y_temp.mat','sensor_y_temp'); 
load('temp_sensor_val.mat','temp_sensor_val');

[sensor_type, num_sensor] = size(sensor_x_temp);

for i=1:sensor_type
    for j=1:num_sensor
        if i==1
            a = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:*');
            hold on
        elseif i==2
            b = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:o');
            hold on
        elseif i == 3
            c = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:x');
            hold on
        elseif i == 4
            d = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:d');
            hold on
        elseif i == 5
            e = plot(handles.axes3,sensor_x_temp(i, j), sensor_y_temp(i, j), 'k:h');
            hold on
        end
    end
end
datacursormode on;
set(handles.axes3, 'xgrid','on','ygrid','on','xlim',[0 20],'ylim',[0 20]);
title(handles.axes3, 'Topology & Drone movement');
xlabel(handles.axes3,'�Ÿ�(100m)');
ylabel(handles.axes3,'�Ÿ�(100m)');



function UAV_distance_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function UAV_distance_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function slash_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function slash_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sen_lamda_Callback(hObject, eventdata, handles)
global sen_lamda
sen_lamda = str2double(get(handles.sen_lamda,'String'))
select_distance2(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function sen_lamda_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global sen_lamda
sen_lamda = 1/8; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sen_Pt_Callback(hObject, eventdata, handles)
global sen_Pt
sen_Pt = str2double(get(handles.sen_Pt,'String'))
select_distance2(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function sen_Pt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global sen_Pt
sen_Pt = 0.005;




function sen_Gt_Callback(hObject, eventdata, handles)
global sen_Gt
sen_Gt = str2double(get(handles.sen_Gt,'String'))
select_distance2(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function sen_Gt_CreateFcn(hObject, eventdata, handles)
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global sen_Gt
sen_Gt = 1;


function height_Callback(hObject, eventdata, handles)
global height
height = str2double(get(handles.height,'String'))


% --- Executes during object creation, after setting all properties.
function height_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global height
height = 300


function UAV_Pt_Callback(hObject, eventdata, handles)
global UAV_Pt
UAV_Pt = str2double(get(handles.UAV_Pt,'String'))
select_distance(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function UAV_Pt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global UAV_Pt
UAV_Pt = 0.05


function UAV_Pr_Callback(hObject, eventdata, handles)
global UAV_Pr
UAV_Pr = eval((get(handles.UAV_Pr,'String')))
select_distance(hObject, eventdata, handles);
select_distance2(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function UAV_Pr_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global UAV_Pr
UAV_Pr = 5*10^-12


function UAV_lamda_Callback(hObject, eventdata, handles)
global UAV_lamda

UAV_lamda = eval((get(handles.UAV_lamda,'String')))
select_distance(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function UAV_lamda_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global UAV_lamda
UAV_lamda = 1/8;

function location_searching_func(~, ~, handles)
global maxIter  swarm_size cr r num_UAV maxTime sensor_type_text UAV_Gr UAV_Gt c1 c2 UAV_Pt UAV_lamda
load('temp_sensor_val','temp_sensor_val');%%%%%%%%%%%%%%%%%%%%yj,ps
load('sensor_x_temp');
load('sensor_y_temp');
load('sensor_snr');

k_iter = 0.75*maxIter;

each_UAV_best = zeros(maxTime,num_UAV);  %%%%%%%%%%%%%%%%%%%yj


[sensor_type, num_sensor] = size(sensor_x_temp);
sensor_x = sensor_x_temp;
sensor_y = sensor_y_temp;
sensor_type
for t = 1:sensor_type
   sensor_val(t, 1:num_sensor) = temp_sensor_val(t); 
end
sensing_time(1:swarm_size,  1:maxTime, 1:sensor_type, 1:num_sensor) = 0;

for time = 1:maxTime
    % ��ġ, �ӵ�, best �� ��� �ʱ�ȭ
    for dim=1:2*num_UAV
        swarm(:, 1, dim) = rand(1,swarm_size)*20;
    end

    swarm(:, 2, :) = 0;
    swarm(:, 3, :) = 0;
    swarm(:, 4, 1) = 0;
    local_best_util=zeros(swarm_size,num_UAV);
    
    % PSO �˰�����
    for iter = 1:maxIter
        for i = 1:swarm_size
            for dim = 1:2*num_UAV
                % ��ġ ������Ʈ
                swarm(i, 1, dim) = swarm(i, 1, dim) + swarm(i, 2, dim);
                
                % ��ġ�� �־��� �������� ������ ����� �� ���
                if swarm(i, 1, dim) < 0 || swarm(i, 1, dim) > 20
                    swarm(i, 1, dim) = swarm(i, 1, dim) - swarm(i, 2, dim);
                end
            end

            % UAV�� ��ġ�� ��ǥ��
            temp = 1;
            for order = 1:num_UAV+1
                for axiss = 1:2
                    if order == num_UAV+1
                        % num_UAV+1�� Base Station
                        UAV(order, axiss) = 0;
                    else
                        UAV(order, axiss) = swarm(i, 1, temp);
                        temp = temp+1;
                    end
                end
            end

            % UAV�� ���ϴ� ������ ���� �� Utility
            UAV_sensor(1:num_UAV, 1:sensor_type) = 0;
            num(1:num_UAV, 1:sensor_type) = 0;
            avg_snr(1:num_UAV, 1:sensor_type) = 0;
            temp_sensing_time(1:sensor_type, 1:num_sensor) = 0;
            
            for j = 1:sensor_type
                for l = 1:num_sensor
                    temp(1:num_UAV) = 0;
                    num_overlap = 0;
                    for order = 1:num_UAV
                        if (sensor_x(j, l) - UAV(order, 1))^2 + (sensor_y(j, l) - UAV(order, 2))^2 <= r^2
                            temp(order) = 1;
                            num_overlap = num_overlap + 1;
                            avg_snr(order, j) = avg_snr(order, j) + sensor_snr(j, l);
                            num(order, j) = num(order, j) + 1;

                            temp_sensing_time(j, l) = time;
                        end
                    end

                    for order = 1:num_UAV
                        if num_overlap > 0 
                            UAV_sensor(order, j) = UAV_sensor(order, j) + sensor_val(j, l)*(temp(order)/num_overlap);
                        end
                    end
                end
            end

            % �� UAV�� ���� Fitness value
            val(1:num_UAV) = 0;
            for order = 1:num_UAV
                for t = 1:sensor_type
                    if num(order, t) == 0
                        num(order, t) = 1;
                    end
                    % func_pathloss : UAV�� ���� ������ PER
                    % func_fitness : ���� ������ ���� ȿ���� ����
                        val(order) = val(order) + func_pathloss2(1,avg_snr(order, t)/num(order, t))*func_fitness(UAV_sensor(order, t), 30);
                end
            end

            % UAV�� �Ÿ� �� ����
            Distance = func_distance2(UAV);

            % UAV�� Base Station�� ����Ǿ� �ִ��� �Ǵ�
            count = func_count(Distance, cr);
            % Base Station�� ����Ǿ� ���� ������ val = 0
            for order = 1:num_UAV
                if count(order) == 0
                    val(order) = 0;
                end
            end

            % UAV-UAV �Ǵ� Base Station�� PER
            temp_pathloss = func_pathloss(Distance, 5,UAV_Gr,UAV_Gt,UAV_Pt,UAV_lamda);
            penalty = 1;
            
            % ���ͽ�Ʈ�� �̿��Ͽ� ��Ŷ ���� Ȯ���� �ִ��� ��� Ž��
            temp_dijk = func_dijk(temp_pathloss, penalty);
            val1 = val.*temp_dijk(1, 1:num_UAV); %pathloss���� ������ utility
            fitness_val = sum(val1);

            % Local best 
            % swarm(i, 4, 1)�� local best�� ��
            % swarm(i, 3, :)�� local best�� ��ġ  
            if fitness_val > swarm(i, 4, 1)
                % local best ��ġ ������Ʈ
                for dim = 1:2*num_UAV
                    swarm(i, 3, dim) = swarm(i, 1, dim);
                    
                end
                local_best_util(i,1:num_UAV) = val1;%%%%%%%%%%%%%%%%%%%%%%%%%%%%by yj iter���� local best�϶� �� UAV�� utility
                % local best �� ������Ʈ
                swarm(i, 4, 1) = fitness_val;
                
                
                % local best�� ��ġ�� �ش��ϴ� ����
                for j = 1:sensor_type
                    for l = 1:num_sensor
                        sensing_time(i, time, j, l) = temp_sensing_time(j, l);
                    end
                end
            end
        end
        
        % global best
        [temp1, gbest(time)] = max(swarm(1:swarm_size, 4, 1));
        
        
        % global best�� �ش��ϴ� ��ġ
        for d = 1:2*num_UAV
            pos(time,d) = swarm(gbest(time), 3, d);
        end
        each_UAV_best(time,1:num_UAV) = local_best_util(gbest(time),1:num_UAV); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% yj
        %         if time == 1
        %             t1(iter, 1, 1) = swarm(gbest(1), 4, 1);
        %         end
        

        % �ӵ� ������Ʈ
        z = rand;
        z = 4*z*(1-z);
        inertia = 0.5*rand + 0.5*z;

        rate = rand(1);
        if iter <= k_iter
            for i = 1:swarm_size
                if i < round(swarm_size*rate)
                    for dim = 1:2*num_UAV
                        swarm(i, 2, dim) = inertia*swarm(i, 2, dim) + c1*rand*(swarm(i, 3, dim)-swarm(i, 2, dim)) + c2*rand*(swarm(gbest(time), 3, dim) - swarm(i, 1, dim));
                    end
                else
                    for dim = 1:2*num_UAV
                        swarm(i, 2, dim) = inertia*swarm(i, 2, dim) + (2*(1-(iter/maxIter)))*(rand*(swarm(i, 3, dim) - swarm(i, 1, dim)) + c2*rand*(swarm(gbest(time), 3, dim) - swarm(i, 1, dim)));
                    end
                end
            end

        else
            for i = 1:swarm_size
                for dim = 1:2*num_UAV
                    swarm(i, 2, dim) = inertia*swarm(i, 2, dim) + c1*rand*(swarm(i, 3, dim)-swarm(i, 2, dim)) + c2*rand*(swarm(gbest(time), 3, dim) - swarm(i, 1, dim));
                end
            end
        end

        if iter == maxIter
            disp(['Time is ' int2str(time) ' , the best fitness value1 is ' num2str(swarm(gbest(time),4,1))]);
        end
        best(iter) = swarm(gbest(time), 4, 1);
    end
    
    finish(time) = best(maxIter);
    save finish finish ;
    save location pos -v7.3;
    save each_UAV_best each_UAV_best;
    
    % global best ��ġ�� �ش��ϴ� ������ ���� �� ������Ʈ
    for j = 1:sensor_type
        for l = 1:num_sensor
            for ti = 1:time
                if sensing_time(gbest(ti), ti, j, l) > 0
                    sensor_val(j, l) = func_sensor_val(temp_sensor_val(j), sensing_time(gbest(ti), ti, j, l), time);
                    if sensor_val(j, l) == temp_sensor_val(j)
                        sensing_time(gbest(ti), ti, j, l) = 0;
                    end
                end
            end
        end
    end
    
    global min_a max_a
%     cla(handles.axes1);
    t=1:length(finish);
    if time == 1
        continue;
    end
    max_a = max(finish);
    min_a = min(finish);
    if min_a < 0
        min_a=0;
    end
    
    plot(handles.axes1,t,finish,'b');
    set(handles.axes1, 'xgrid','on','ygrid','on','xlim',[0 maxTime],'ylim',[min_a-50 max_a+50]);
    title(handles.axes1, 'Utility to Time');
    xlabel(handles.axes1,'Ƚ��');
    ylabel(handles.axes1,'��ƿ��Ƽ');
    datacursormode on;
    pause(0.01);
end


function select_distance(~, ~, handles) % UAV - UAV �Ÿ����
global UAV_Gr UAV_Gt UAV_lamda UAV_Pt UAV_Pr cr UAV_distance
UAV_distance= sqrt(UAV_Gr*UAV_Gt*UAV_lamda^2*UAV_Pt/(UAV_Pr*(4*pi)^2));
cr = UAV_distance/100;
set(handles.UAV_distance,'string',num2str(UAV_distance));

function select_distance2(~, ~, handles) % sensor - UAV �Ÿ����
global UAV_Gr sen_Gt sen_lamda sen_Pt UAV_Pr slash r height sen_distance
slash= sqrt(UAV_Gr*sen_Gt*sen_lamda^2*sen_Pt/(UAV_Pr*(4*pi)^2));
set(handles.slash,'string',num2str(slash));
sen_distance = sqrt(slash^2 - height^2);
r = sen_distance/100;
set(handles.sen_distance,'string',num2str(sen_distance));

function c1_Callback(hObject, eventdata, handles)
global c1
c1 = str2double(get(handles.c1,'String'))

% --- Executes during object creation, after setting all properties.
function c1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global c1
c1 = 1.4;

function c2_Callback(hObject, eventdata, handles)
global c2
c2 = str2double(get(handles.c2,'String'))

function c2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global c2
c2 = 1.4;
