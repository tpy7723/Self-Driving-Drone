l = 5;
r = 0.1;
 
x_plane = [-10 -10 10 10];
y_plane = [-0.6 -0.5 -0.5 -0.6];
x_cart = [-1 -1 1 1];
y_cart = [-0.5 0.5 0.5 -0.5];
x_pole = [-r -r r r];
y_pole = [-l 0 0 -l];
 
plane = fill(x_plane, y_plane, 'k');
grid on
hold on
cart = fill(x_cart, y_cart, 'g','EraseMode','normal');
pole = fill(x_pole, y_pole, 'b','EraseMode','normal');
hold off
axis([-10 10 -8 4]);
 
t = 0:0.01:20*pi/180;
 
for t = 0:0.01:20*pi/180
    updatedX_cart = x_cart + t;
    temp_x = [l*cos(3/2*pi+t-atan(r/l)) r*cos(pi+t) r*cos(t) l*cos(3/2*pi+t+atan(r/l))];
    temp_y = [l*sin(3/2*pi+t-atan(r/l)) r*sin(pi+t) r*sin(t) l*sin(3/2*pi+t+atan(r/l))];
    updatedX_pole = t + temp_x;
    updatedY_pole = temp_y;
    set(cart, 'Xdata', updatedX_cart);
    set(pole, 'Xdata', updatedX_pole,'Ydata', updatedY_pole);
    drawnow;
    
    for i=1:500000000
        temp = i;
    end
end