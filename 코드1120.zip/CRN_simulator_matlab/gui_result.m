function varargout = gui_optimal_time(varargin)
% gui_optimal_time M-file for gui_optimal_time.fig
%      gui_optimal_time, by itself, creates a new gui_optimal_time or raises the existing
%      singleton*.
%
%      H = gui_optimal_time returns the handle to a new gui_optimal_time or the handle to
%      the existing singleton*.
%
%      gui_optimal_time('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in gui_optimal_time.M with the given input arguments.
%
%      gui_optimal_time('Property','Value',...) creates a new gui_optimal_time or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_optimal_time_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_optimal_time_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_optimal_time

% Last Modified by GUIDE v2.5 05-Dec-2011 18:46:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_optimal_time_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_optimal_time_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_optimal_time is made visible.
function gui_optimal_time_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_optimal_time (see VARARGIN)

% Choose default command line output for gui_optimal_time
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%========== file open ===================%
data =importdata('data.txt');
user_type=data(1);            %radio
noise_type=data(2);           %radio
algorithm=data(3);            %radio
sampling_freq=data(4);        %edit
primary_active=data(5);       %edit
target=data(6);               %edit
primary_network=data(7);      %edit
second_network=data(8);       %edit
frame=data(9);                %edit
detection_time=data(10);       %edit
simulate_no=data(11);          %popup
alpha = data(12);       %edit
beta = data(13);        %edit
%========== file open ===================%
FrameDuration=frame;  
SensingTime=[0.001:0.0001:0.005];   
frame_s = sampling_freq*10^6;
targetPd=target;
ActiveProbability=primary_active; %P(H1)  
InActiveProbability=(1-ActiveProbability); %P(H0)  
SNRp_db=primary_network;  SNRs_db=second_network; 
SNRp=10^(SNRp_db/10);  SNRs=10^(SNRs_db/10); 
C0= log2(1+SNRs); C1=log2(1+(SNRs/(1+SNRp))); 
N=frame_s*SensingTime; % N=Fs*t

SimN=simulate_no;
YP_test = zeros(1,length(SensingTime));
YS_test = zeros(1,length(SensingTime));
TP_test = zeros(length(SensingTime),SimN);
TS_test = zeros(length(SensingTime),SimN);
    
for k=1:SimN
 for i=1:length(SensingTime); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% BPSK & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     n = round(N(i));
     ip = rand(1,n)>0.5; % generating 0,1 with equal probability     
     mods = 2*ip-1; % BPSK modulation 0 -> -1; 1 -> 1 
     s = mods;
     u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n)); % white gaussian noise, 0dB variance 
     Eb_N0_dB = -15; 
     y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
     y_s=u; % < H0 >
      
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%% CSCG & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      n = round(N(i));
%      s = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n));
%      u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n)); % white gaussian noise, 0dB variance  
%      y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
%      y_s=u; % < H0 > 
%     
%      %%%%%%%%%%%%%%%%%%%%%%%%%%%% Real & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      n = round(N(i));
%      s = randn(1,n); 
%      u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n)); % white gaussian noise, 0dB variance  
%      y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
%      y_s=u; % < H0 >
%      
%      
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%% QPSK & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%     nr_data_bits = round(N(i));
%     b_data = (randn(1, nr_data_bits) > .5);%random 0's and 1's
%     b = (b_data);
%     
%     qpsk=zeros(1,length(b)/2); %definition of the QPSK symbols using Gray coding.
%     for n=1:length(b)/2
%         p=b(2*n);
%         imp=b(2*n-1);
%         if (imp==0)&&(p==0)
%             qpsk(n)=exp(j*pi/4);%45 degrees
%         end
%         
%         if (imp==1)&&(p==0)
%             qpsk(n)=exp(j*3*pi/4);%135 degrees
%         end
%         
%         if (imp==1)&&(p==1)
%             qpsk(n)=exp(j*5*pi/4);%225 degrees
%         end
%         
%         if (imp==0)&&(p==1)
%             qpsk(n)=exp(j*7*pi/4);%315 degrees
%         end
%         
%     end
%     
%     s=qpsk;
%     u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n));
%     Eb_N0_dB = -15; 
%     y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
%     y_s=u; % < H0 >
%     
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    YP_test(i)=sum(abs(y).^2)/N(i); % SensingTime�� T(y) - < H1 > 
    YS_test(i)=sum(abs(y_s).^2)/N(i); % SensingTime�� T(y) - < H0 >
    
 end
 
  TP_test(:,k) = YP_test(1,:).'; % 36 by SimN matrix , SensingTime�� t(y)�� SimNȸ ��� - < H1 >
  TS_test(:,k) = YS_test(1,:).'; % 36 by SimN matrix , SensingTime�� t(y)�� SimNȸ ��� - < H0 >

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%  T(y)  %%%%%%%%%%%%%%%%%%%%%%%%5
tt=0:0.001:2-0.001;
pdf_p=zeros(length(SensingTime),2000); % T(y)�� pdf - < H1 > 
for k=1:length(SensingTime)
    for jj=1:2000
        for j=1:SimN
            if((TP_test(k,j)>=0+jj*0.001)&&(TP_test(k,j)<0+jj*0.001+0.001))
                pdf_p(k,jj)=pdf_p(k,jj)+1;
            end
        end
    end
end

for i=1:length(SensingTime)
    pdf_p(i,:) = pdf_p(i,:)/SimN;
end


pdf_s=zeros(length(SensingTime),2000); % T(y)�� pdf - < H0 > 
for k=1:length(SensingTime)
    for jj=1:2000
        for j=1:SimN
            if((TS_test(k,j)>=0+jj*0.001)&&(TS_test(k,j)<0+jj*0.001+0.001))
                pdf_s(k,jj)=pdf_s(k,jj)+1;
            end
        end
    end
end

for i=1:length(SensingTime)
    pdf_s(i,:) = pdf_s(i,:)/SimN;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%% Simulated : Pf, Pd, R %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

threshold=[1:0.001:1.06]; % threshold ���� 
p_threshold=threshold.*1000; % threshold index
p_threshold=round(p_threshold);
d_threshold=zeros(1,length(SensingTime)); % detection threshold

% SensingTime�� Pd
Pd=zeros(length(threshold),length(SensingTime)); 
for i=1:length(SensingTime)
    for j=1:length(threshold)
        for d=p_threshold(j):length(tt)
            Pd(j,i)=Pd(j,i)+pdf_p(i,d);            
        end
    end
end

% Pd=0.9(Target Pd)�� �����ϴ� SensingTime�� threshold
for i=1:length(threshold)  
    for j=1:length(SensingTime)
        if targetPd-Pd(i,j)<0.001
            d_threshold(1,j)=threshold(1,i);    %d_threshold(i,j)
        end
    end
end
% Pd=0.9�� SensingTime�� Pf
d_threshold=round(1000*d_threshold);
Pf=zeros(1,length(SensingTime)); 
for i=1:length(SensingTime)
    for d=d_threshold(i):length(tt)
        Pf(1,i)=Pf(1,i)+pdf_s(i,d);
    end
end
     
R0=zeros(1,length(SensingTime));  
R0_PH0=zeros(1,length(SensingTime));       % R0_PH0 : R var
R1_PH1=zeros(1,length(SensingTime));
R1=zeros(1,length(SensingTime));
R=zeros(1,length(SensingTime));            % R : Throughput
N_R=zeros(1,length(SensingTime));          % N_R : Normalized Throughput
for f=1:length(SensingTime)
    R0(1,f)=((FrameDuration-SensingTime(1,f))./FrameDuration).*(1-Pf(1,f))*C0;
    R0_PH0(1,f)=InActiveProbability.*R0(1,f);         
    R1(1,f)=((FrameDuration-SensingTime(1,f))./FrameDuration).*(1-(targetPd))* C1;
    R1_PH1(1,f)=ActiveProbability.*R1(1,f);
    R(1,f)=R1_PH1(1,f)+R0_PH0(1,f); 
    N_R(1,f)=R(1,f)./4.3; 
    N0_R0(1,f)=R0(1,f)./4.3;
end

% Optimal�� SensingTime ã��
MAX_R=0;
OPTIMALTIME=0;
for i=1:length(SensingTime)
    if R(i)>MAX_R
        MAX_R=R(i);
        O=i;
        OPTIMALTIME=SensingTime(i); % OPTIMAL�� SENSING TIME 
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%% Pulse Plot- TI=0.1�� �� Optimal Sensing Time %%%%%%%%%%%%%%%%%%
index_TI=FrameDuration*10^4;
index_Ts=OPTIMALTIME*10^4;
index_total=index_TI*10;
total=zeros(1,index_total); % y�� 

for w=1:10
    for s=(index_TI)*(w-1)+1 : (index_TI)*(w-1)+1+index_Ts
        total(s)=1;    
    end
end

pulsex=10^(-4):10^(-4):(index_total)*10^(-4); % x�� ���� 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Theory : Pd, Pf, r %%%%%%%%%%%%%%%%%%%%%%%%%%%%

E= var(u) * ( qfuncinv(targetPd) * sqrt((2*SNRp+1)./N) + SNRp + 1 );
PF= qfunc( sqrt(N).*( (E./var(u)) - SNRp -1) + sqrt(N).* SNRp);
r0=((FrameDuration-SensingTime)/FrameDuration) .* (1-PF)* C0;
r0_ph0=(InActiveProbability * r0); % r var
r1=((FrameDuration-SensingTime)/FrameDuration) .* (1-targetPd)* C1;
r1_ph1=(ActiveProbability * r1);
r=r0_ph0 + r1_ph1;   % r : Throughput
n_r=r./4.3; % n_r : Normalized Throughput
% n0_r0=r0_ph0./6; 

% Optimal�� SensingTime ã��
max_r=0;
optimaltime=0;
for i=1:length(SensingTime)
    if r(i)>max_r
        max_r=r(i);
        o=i;
        optimaltime=SensingTime(i);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
axes(handles.axes2)
cla;        % �׷��������
plot(SensingTime,r,'r',SensingTime,R,'b'); hold on;
plot(SensingTime(o),r(o),'s','MarkerEdgeColor','k',...
                              'MarkerFaceColor','r',...
                              'MarkerSize',5); hold on;
plot(SensingTime(O),R(O),'o','MarkerEdgeColor','k',...
                             'MarkerFaceColor','b',...
                             'MarkerSize',6); hold on;
                        
grid on;
hleg1 = legend('Theory','Simulate'); hold on;
set(hleg1,'Location','SouthEast'); hold on;
xlabel('sensing time (sec) '); 
ylabel('throughput (bits/Hz/Sec)','FontSize',2);
% h1 = stem(SensingTime(o),r(o),'fill','--');
% set(get(h1,'BaseLine'),'LineStyle',':','Color','red'); 
% set(h1,'MarkerFaceColor','red','MarkerEdgeColor','k','Marker','square'); hold on;
% 
% h2 = stem(SensingTime(O),R(O),'fill','--'); hold on;
% set(get(h2,'BaseLine'),'LineStyle',':'); hold on;
% set(h2,'MarkerFaceColor','blue','MarkerEdgeColor','k','Marker','o'); hold on;
xlabel('sensing time (sec) '); 
ylabel('throughput (bits/Hz/Sec)');

axes(handles.axes1)
cla;        % �׷��������
plot(SensingTime,r0_ph0,'m',SensingTime,R0_PH0,'k'); hold on;
plot(SensingTime(o),r0_ph0(o),'s','MarkerEdgeColor','k',...
                              'MarkerFaceColor','m',...
                              'MarkerSize',5); hold on;
plot(SensingTime(O),R0_PH0(O),'o','MarkerEdgeColor','k',...
                             'MarkerFaceColor','k',...
                             'MarkerSize',6); hold on;
grid on;
hleg2 = legend('Theory','Simulate');
set(hleg2,'Location','SouthEast')
xlabel('sensing time (sec) '); 
ylabel('throughput (bits/Hz/sec)');

axes(handles.axes3)
cla;        % �׷��������
plot(SensingTime,r,'r',SensingTime,R,'b'); hold on;
plot(SensingTime(o),r(o),'s','MarkerEdgeColor','k',...
                              'MarkerFaceColor','r',...
                              'MarkerSize',5); hold on;%
plot(SensingTime(O),R(O),'o','MarkerEdgeColor','k',...
                             'MarkerFaceColor','b',...
                             'MarkerSize',6); hold on;%
plot(SensingTime,r0_ph0,'m',SensingTime,R0_PH0,'k'); hold on;
plot(SensingTime(o),r0_ph0(o),'s','MarkerEdgeColor','k',...
                              'MarkerFaceColor','m',...
                              'MarkerSize',5); hold on;
plot(SensingTime(O),R0_PH0(O),'o','MarkerEdgeColor','k',...
                             'MarkerFaceColor','k',...
                             'MarkerSize',6); hold on;
grid on;
xlabel('sensing time (sec) '); 
ylabel('throughput (bits/Hz/sec)');

axes(handles.axes4)
cla;        % �׷��������
plot(SensingTime,n_r,'r',SensingTime,N_R,'b'); hold on;
plot(SensingTime(o),n_r(o),'s','MarkerEdgeColor','k',...
                              'MarkerFaceColor','r',...
                              'MarkerSize',5); hold on;%
plot(SensingTime(O),N_R(O),'o','MarkerEdgeColor','k',...
                             'MarkerFaceColor','b',...
                             'MarkerSize',6); hold on;%
grid on;
%  plot(SensingTime,n0_r0,'m',SensingTime,N0_R0,'k');
%  plot(SensingTime(o),n0_r0(o),'s','MarkerEdgeColor','k',...
%                               'MarkerFaceColor','m',...
%                               'MarkerSize',5); hold on;
% plot(SensingTime(O),N0_R0(O),'o','MarkerEdgeColor','k',...
%                              'MarkerFaceColor','k',...
%                              'MarkerSize',6); hold on;
% title('Normalized Achievable Throughput for the Secondary Network');
xlabel('sensing time (sec) '); 
ylabel('throughput (bits/Hz/sec)');

axes(handles.axes5)
cla;
stairs(pulsex,total)
axis([0 0.6 0 1.2]);
S=['TI=' num2str(FrameDuration)]; text(0.025, 0.9, S);
T=['Ts*=' num2str(OPTIMALTIME)]; text(0.025, 0.65, T);
% UIWAIT makes gui_optimal_time wait for user response (see UIRESUME)
% uiwait(handles.figure1);

axes(handles.axes6)
Aim=imread('cross.jpg','jpg');
imshow(Aim);
axes(handles.axes7)
imshow(Aim);
axes(handles.axes8)
imshow(Aim);
axes(handles.axes_title)
Aim2=imread('title_time.jpg','jpg');
imshow(Aim2);

if user_type==1;
    primary = 'real gaussian';
elseif user_type==2;
    primary = 'CSCG';
elseif user_type==3;
    primary = 'BPSK';
elseif user_type==4;
    primary = 'QPSK';
end
set(handles.text_primary,'string',primary);

if noise_type==1;
    noise = 'real gaussian';
elseif noise_type==2;
    noise = 'CSCG';
end
set(handles.text_noise,'string',num2str(noise));

if algorithm==1;
    algo = 'energy detection';
elseif algorithm==2;
    algo = 'matched filter';
elseif algorithm==3;
    algo = 'CFD';
end
set(handles.text_algorithm,'string',num2str(algo));
set(handles.text_simulated,'string',num2str(simulate_no));
set(handles.text_freq,'string',num2str(sampling_freq));
set(handles.text_pd,'string',num2str(target));
set(handles.text_target_SNR,'string',num2str(primary_network));
set(handles.text_2nd_SNR,'string',num2str(second_network));
set(handles.text_ph1,'string',num2str(primary_active));
set(handles.text_ph0,'string',num2str(InActiveProbability));
set(handles.text_interval,'string',num2str(frame));
set(handles.text_simulated,'string',num2str(OPTIMALTIME));
set(handles.text_theory,'string',num2str(optimaltime));
% --- Outputs from this function are returned to the command line.
function varargout = gui_optimal_time_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton_close.
function pushbutton_close_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
