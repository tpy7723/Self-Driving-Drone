function varargout = gui_optimal_final(varargin)
% GUI_OPTIMAL_FINAL M-file for gui_optimal_final.fig
%      GUI_OPTIMAL_FINAL, by itself, creates a new GUI_OPTIMAL_FINAL or raises the existing
%      singleton*.
%
%      H = GUI_OPTIMAL_FINAL returns the handle to a new GUI_OPTIMAL_FINAL or the handle to
%      the existing singleton*.
%
%      GUI_OPTIMAL_FINAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_OPTIMAL_FINAL.M with the given input arguments.
%
%      GUI_OPTIMAL_FINAL('Property','Value',...) creates a new GUI_OPTIMAL_FINAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_optimal_final_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_optimal_final_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_optimal_final

% Last Modified by GUIDE v2.5 04-Dec-2011 17:24:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_optimal_final_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_optimal_final_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_optimal_final is made visible.
function gui_optimal_final_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_optimal_final (see VARARGIN)

% Choose default command line output for gui_optimal_final
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%========== file open ===================%
data =importdata('data.txt');
user_type=data(1);            %radio
noise_type=data(2);           %radio
algorithm=data(3);            %radio
sampling_freq=data(4);        %edit
primary_active=data(5);       %edit PH1
target=data(6);               %edit
primary_network=data(7);      %edit Target SNR 
second_network=data(8);       %edit
frame=data(9);                %edit
detection_time=data(10);      %edit
simulate_no=data(11);         %popup
alpha = data(12);             %edit
beta = data(13);              %edit
tbdp =  data(14);             %edit
tit =  data(15);              %edit
ir =  data(16);               %edit
%========== file open ===================%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OPTIMAL - Ts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
v_dB=primary_network; % main ���� SNRs
v=10^(v_dB/10);
C0= log2(1+v); C1=log2(1+(v/(1+v)));
fs=sampling_freq*10^6; % sampling frequency

pd=[0.9:0.01:0.99]; 
pf=[0.01:0.01:0.5]; 
[P_D P_F]=meshgrid(pd,pf);

N_min=zeros(length(pf),length(pd));
Optimal_Ts=zeros(length(pf),length(pd));
for f=1:length(pf)
    for j=1:length(pd)
        N_min(f,j)=(1/v^2).*(qfuncinv(pf(f))-qfuncinv(pd(j)).*(2*v+1)^1/2).^2;
        Optimal_Ts(f,j)=N_min(f,j)/fs;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OPTIMAL - TI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PH1 = primary_active; % main���� primary active
PH0 = 1-PH1; 
a = alpha; % alpha
b = beta; % beta
d = 0.005;
TTIT = (1/5)*(1/a);

% Ts= pd,pf�� ���� Ts*
Optimal_TI=zeros(length(pf),length(pd));

for f=1:length(pf)
    for j=1:length(pd)
        
        TI=[Optimal_Ts(f,j):d:TTIT].'; % pd, pf => Optimal_Ts => pd, pf, Ts���� �־��� �� Optimal_TI�� ã�� TI�� ����
        
        
        num=zeros(length(TI),1);
        for L=1:length(TI)    
            num(L,1)=floor(TTIT/TI(L));
        end
        
        Pd=zeros(max(num)+1,1); %%%%%%%%%%%%%%%% Pd
        for i=0:max(num)    
            Pd(i+1,1)=1-(1-pd(j))^(i);
        end
        
        
       Pd2=zeros(max(num)+2,1); %%%%%%%%%%%%%%%% Pd2
       for i=0:max(num)+1
           Pd2(i+1,1)=1-(1-pd(j))^(i);
       end
       
       PDO_IMD=zeros(length(TI),max(num)); %%%%%%%%%%%%%%%% PDO_IMD
       for L=1:length(TI)
           for i=0:num(L,1)
               if i==num(L,1)
                   PDO_IMD(L,i+1)=exp((-a)*(i)*TI(L,1));
               else
                   PDO_IMD(L,i+1)=(exp((-a)*(i)*TI(L,1))-exp((-a)*(i+1)*TI(L,1)));
               end
           end
       end
       
       PD_IMD=zeros(length(TI),1); %%%%%%%%%%%%%%%% PD_IMD
       for L=1:length(TI)
           PD_IMD(L,1) = sum(PDO_IMD(L,:).*Pd(:,1).');
       end
       
       ts=zeros(1,length(TI));
       for L=1:length(TI)
           ts(1,L)=((num(L,1)+1)*(TI(L,1)))-TTIT;
       end
       
       PDO_CID1=zeros(max(num)+1,length(TI)); %%%%%%%%%%%%%%%% PDO_CID
       for L=1:length(TI)
           for i=0:num(L,1)
               if i == 0            
                   PDO_CID1(i+1,L)=((a-b)*(1-exp(-b*ts(L))) - b*exp(-a*TI(L))*(exp((a-b)*ts(L))-1))/((a-b)*(1-exp(-b*TI(L))));
               elseif (i == num(L,1))
                   PDO_CID1(i+1,L)=b*exp(-a*(i)*TI(L))*(exp((a-b)*ts(L))-1)/((a-b)*(1-exp(-b*TI(L))));
               else
                   PDO_CID1(i+1,L)=b*exp(-a*(i)*TI(L))*(1-exp(-a*TI(L)))*(exp((a-b)*ts(L))-1)/((a-b)*(1-exp(-b*TI(L))));
               end
           end
       end
       
       PDO_CID2=zeros(max(num)+2,length(TI));
       for L=1:length(TI)    
           for i=0:num(L,1)+1        
               if i == 0
                   PDO_CID2(i+1,L)=((a-b)*(exp(-b*ts(L))-exp(-b*TI(L))) - b*exp(-a*TI(L))*(exp((a-b)*TI(L))-exp((a-b)*ts(L))))/((a-b)*(1-exp(-b*TI(L))));        
               elseif (i == num(L,1)+1)            
                   PDO_CID2(i+1,L)=b*exp(-a*(i)*TI(L))*(exp((a-b)*TI(L))-exp((a-b)*ts(L)))/((a-b)*(1-exp(-b*TI(L))));        
               else
                   PDO_CID2(i+1,L)=b*exp(-a*(i)*TI(L))*(1-exp(-a*TI(L)))*(exp((a-b)*TI(L))-exp((a-b)*ts(L)))/((a-b)*(1-exp(-b*TI(L))));
               end
           end
       end
       
       PD_CID=zeros(1,length(TI)); %%%%%%%%%%%%%%%% PD_IMD
       for L=1:length(TI)
           PD_CID(1,L) = sum(PDO_CID1(:,L).*Pd(:,1))+sum(PDO_CID2(:,L).*Pd2(:,1));    
       end
       
       PD=zeros(1,length(TI)); %%%%%%%%%%%%%%%%% �־��� pd,pf => TI�� ���� PD
       for L=1:length(TI)
           PD(1,L)=(PH1*(1-pd(j))*PD_IMD(L,1).'+PH0*(1-pf(f))*PD_CID(1,L))/(PH1*(1-pd(j))+PH0*(1-pf(f)));
       end
       
       IDLE00=zeros(1,length(TI)); % (TI-TS)
       IDLE01=zeros(1,length(TI));
       BUSY00=zeros(1,length(TI));
       IDLE01=zeros(1,length(TI));
       IDLE00_TI=zeros(1,length(TI));
       IDLE01_TI=zeros(1,length(TI));
       BUSY00_TI=zeros(1,length(TI));
       BUSY01_TI=zeros(1,length(TI));
       
       R_TI=zeros(1,length(TI)); %%%%%%%%%% �־��� pd,pf => TI�� ���� R (Throughput)
       I=zeros(1,length(TI)); %%%%%%%%%%%%% �־��� pd,pf => TI�� ���� I
       for L=1:length(TI) 
           IDLE00=(TI(L)-Optimal_Ts(f,j)) - PH1*( (TI(L)-Optimal_Ts(f,j)) + (exp(-(a+b)*(TI(L)-Optimal_Ts(f,j)))-1)*(a+b)^(-1) );    
           IDLE01=PH0 * ( (TI(L)-Optimal_Ts(f,j)) + (exp(-(a+b)*(TI(L)-Optimal_Ts(f,j)))-1) * (a+b)^(-1) );
           BUSY00=(TI(L)-Optimal_Ts(f,j))-IDLE00;       
           BUSY01=(TI(L)-Optimal_Ts(f,j))-IDLE01;       
           IDLE00_TI=TI(L) - PH1*( TI(L) + (exp(-(a+b)*TI(L))-1)*(a+b)^(-1) );               
           BUSY00_TI=TI(L)-IDLE00_TI;       
           IDLE01_TI=PH0*(TI(L) +(exp(-(a+b)*TI(L))-1) * (a+b)^(-1));       
           BUSY01_TI=TI(L)-IDLE01_TI;   
           R_TI(L)=(1/TI(L))*( (PH0*1-pf(f))*IDLE00 + PH1*(1-pd(j))*IDLE01);
           I(L)=( PH0*(1-pf(f))*BUSY00 + PH1*(1-pd(j))*BUSY01 ) / ( PH0*BUSY00_TI + PH1*BUSY01_TI );
       end
       
       for L=1:length(TI) % PD > 0.9 �� ��� index = e_PD
           if (PD(L)-0.9)>0.0005
               e_PD=L;
           end 
       end
       
       for L=1:length(TI) % I > 0.1 �� ��� index= e_I
           if (0.1-I(L))>0.0005
               e_I=L;
           end
       end
       
       if e_PD<e_I % e_PD �� e_I �� �� ������ = e_min 
           e_min=e_PD;
       else
           e_min=e_I;
       end
       
       max_R=0; % 1~ e_min ���� �߿��� R�� �ִ밡 �Ǵ� Lã�� => TI(L)=Optimal_TI(f,j)
       for L=1:e_min
           if max_R<R_TI(L)
               max_R=R_TI(L);
               m_index=L;
               Optimal_TI(f,j)=TI(L);
           end
       end
       
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OPTIMAL - R %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Ts=Ts* , TI=TI*
Optimal_R=zeros(length(pf),length(pd));
MAX_R=0;
for f=1:length(pf)
    for j=1:length(pd)
        IDLE00=(Optimal_TI(f,j)-Optimal_Ts(f,j)) - PH1*( (Optimal_TI(f,j)-Optimal_Ts(f,j)) + (exp(-(a+b)*(Optimal_TI(f,j)-Optimal_Ts(f,j)))-1)*(a+b)^(-1) );
        IDLE01=PH0 * ( (Optimal_TI(f,j)-Optimal_Ts(f,j)) + ( exp( -(a+b)* (Optimal_TI(f,j)-Optimal_Ts(f,j)) )-1) * (a+b)^(-1) );
        Optimal_R(f,j)=(1/Optimal_TI(f,j))*( (PH0*1-pf(f))*IDLE00 + PH1*(1-pd(j))*IDLE01 ) +0.2;
        
        if MAX_R<Optimal_R(f,j) % maxR at ( pd*, pf* , TI* , Ts* ) 
            MAX_R=Optimal_R(f,j); 
            OPTIMAL_PF=pf(f); % 0.01
            OPTIMAL_PD=pd(j); % 0.93
            OPTIMAL_TI=Optimal_TI(f,j); % 0.1716 %%%%%%% OPTIMAL�� SENSING INTERVAL %%%%%%%
            OPTIMAL_TS=Optimal_Ts(f,j); % 0.0016 %%%%%%% OPTIMAL�� SENSING TIME %%%%%%%%%%
            OPTIMAL_R=Optimal_R(f,j); % 0.7766
        end
        
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% pulse %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
index_TI=round(OPTIMAL_TI*10^4);
index_Ts=round(OPTIMAL_TS*10^4);
index_total=round(index_TI*10);
total=zeros(1,index_total);
for w=1:10
    for s=(index_TI)*(w-1)+1 : (index_TI)*(w-1)+1+index_Ts
        total(s)=1;    
    end
end
pulsex=10^(-4):10^(-4):(index_total)*10^(-4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

axes(handles.axes1)
mesh(P_F,P_D,Optimal_Ts)
axis([0 0.5 0.9 1 0 0.0025])

axes(handles.axes2)
mesh(P_F,P_D,Optimal_TI)
axis([0 0.5 0.9 1 0 0.25])

axes(handles.axes3)
mesh(P_F,P_D,Optimal_R)
axis([0 0.5 0.9 1 0 1])

axes(handles.axes4)
stairs(pulsex,total)
axis([0 0.6 0 1.1]);

set(handles.text_sensinginterval,'string',num2str(OPTIMAL_TI));
set(handles.text_pd,'string',num2str(OPTIMAL_PD));
set(handles.text_pf,'string',num2str(OPTIMAL_PF));
set(handles.text_sensingtime,'string',num2str(OPTIMAL_TS));
set(handles.text_throughput,'string',num2str(OPTIMAL_R));

% Ÿ��Ʋ�׸�
axes(handles.axes_title)
Aim=imread('title_optimal.jpg','jpg');
imshow(Aim);
% I=['TI*=' num2str(OPTIMAL_TI)]; text(0.025, 1, I);
% S=['Ts*=' num2str(OPTIMAL_TS)]; text(0.025, 0.85, S);
% D=['pd*=' num2str(OPTIMAL_PD)]; text(0.025, 0.7, D);
% F=['pf*=' num2str(OPTIMAL_PF)]; text(0.025, 0.55, F);


% UIWAIT makes gui_optimal_final wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_optimal_final_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_close.
function pushbutton_close_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
