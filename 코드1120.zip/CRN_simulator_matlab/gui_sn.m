function varargout = gui_signal_noise(varargin)
% gui_signal_noise M-file for gui_signal_noise.fig
%      gui_signal_noise, by itself, creates a new gui_signal_noise or raises the existing
%      singleton*.
%
%      H = gui_signal_noise returns the handle to a new gui_signal_noise or the handle to
%      the existing singleton*.
%
%      gui_signal_noise('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in gui_signal_noise.M with the given input arguments.
%
%      gui_signal_noise('Property','Value',...) creates a new gui_signal_noise or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_signal_noise_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_signal_noise_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_signal_noise

% Last Modified by GUIDE v2.5 03-Dec-2011 22:01:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_signal_noise_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_signal_noise_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_signal_noise is made visible.
function gui_signal_noise_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_signal_noise (see VARARGIN)
clc;
% Choose default command line output for gui_signal_noise
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
    
    axes(handles.axes_title)
    Aim2=imread('title_signal.jpg','jpg');
    imshow(Aim2);
% UIWAIT makes gui_signal_noise wait for user response (see UIRESUME)
% uiwait(handles.figure1);
data =importdata('data.txt');
user_type=data(1);      %radio
noise_type=data(2);     %radio
algorithm=data(3);      %radio
sampling_freq=data(4);  %edit
primary_active=data(5); %edit
target=data(6);         %edit
primary_network=data(7);%edit
second_network=data(8); %edit
frame=data(9);          %edit
detection_time=(10);    %edit
simulate_no=data(11);   %popup
alpha = data(12);       %edit
beta = data(13);        %edit

FrameDuration=frame;  
SensingTime=0.001:0.0001:0.0045;   
frame_s = sampling_freq*10^6;
targetPd=target;
ActiveProbability=primary_active;  
InActiveProbability=(1-ActiveProbability);
SNRp_db=primary_network;  SNRs_db=second_network;  
SNRp=10^(SNRp_db/10);  SNRs=10^(SNRs_db/10); 
C0= log2(1+SNRs); C1=log2(1+(SNRs/(1+SNRp))); 
N=frame_s*SensingTime; % N= 6

SimN=simulate_no;
YP_test = zeros(1,length(SensingTime));
YS_test = zeros(1,length(SensingTime));
TP_test = zeros(length(SensingTime),SimN);
TS_test = zeros(length(SensingTime),SimN);

t=1:27000;

on_int=zeros(1,1000);
off_int=zeros(1,1000);
count=0;
pattern=zeros(1,10000);

for k=0:25
    on=-(1.0/(alpha*10)).*log(1-rand());
    on_convert=on*10^3;
    on_int(k+1)=ceil(on_convert);
   
    off=-(1.0/(beta*10)).*log(1-rand());
    off_convert=off*10^3;
    off_int(k+1)=ceil(off_convert);
    
    for i=count:count+off_int(k+1);
        mask(i+1)=0;
    end
    for j=count+off_int(k+1):count+off_int(k+1)+on_int(k+1)
        mask(j)=1;
    end
    count=count+on_int(k+1)+off_int(k+1);
end
          
for k=1:10000
    pattern(k)=mask(k);
end

for k=1:SimN
 for i=1:length(SensingTime); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% BPSK & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    n = round(N(i));
    ip = rand(1,n)>0.5; % generating 0,1 with equal probability     
    mods = 2*ip-1; % BPSK modulation 0 -> -1; 1 -> 1 
    s = mods;
    u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n)); % white gaussian noise, 0dB variance 
    Eb_N0_dB = SNRp_db; 
    y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
    y_s=u; % < H0 >
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% carrier %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ĳ���� ��  
    pp=0:0.01:100.99;
    t1=1:0.01:100.99;
    
    ori_carr=zeros(1,10000);
    for iiii=1:10000
        ori_carr(iiii)=cos(2*pi*pp(iiii));
    end
    
    % psk ������ ��ȣ
    p=0:0.01:0.99;
    carr=zeros(1,10000);
    rrr=zeros(1,10000);
    for iii=0:99
        for ii=1:100
            rrr(ii+iii*100)=cos(2*pi*p(ii));
        end
    end
    
    for pp=0:99
        if mods(pp+1)==1
            for ppp=1+pp*100:pp*100+100
                carr(1,ppp)=rrr(1,ppp);
            end
        else
            for ppp=1+pp*100:pp*100+100
                    carr(1,ppp)=-rrr(1,ppp);
            end
        end
    end

    %  pattern * psk modulated signal
    kimjae=zeros(1,10000);
    for k=1:10000
        kimjae(k)=pattern(k).*carr(k);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % �������� pdf
    tt=-5:0.1:5;
    ccc=zeros(1,100);
    for i=0:99
        for j=1:SimN
            if((u(j)>=-5+i*0.1)&&(u(j)<-5+i*0.1+0.1))
                ccc(i+1)=ccc(i+1)+1;
            end
        end
    end
    for i=1:100
        xxx(i+1)=ccc(i);
    end
    pdf_u=xxx/SimN;
 end
end

for l= 1:80
    % ������
    axes(handles.axes_u)
    stem(t,u);
    axis([l l+20 -2 2]);

    % �ֻ������ ��ȣ
    axes(handles.axes_s)
    stairs(t,s); grid;
    axis([l l+20 -1.8 1.8]);
    
    % ĳ���� ��   
    axes(handles.axes_carrier)
    plot(t1,ori_carr); grid;
    axis([l l+20 -1.5 1.5]);
    
    % psk ������ ��ȣ
    axes(handles.axes_carrier_signal)
    plot(t1, carr); grid;
    axis([l l+20 -1.5 1.5]);
    
    % Primary ON/OFF pattern
    axes(handles.axes_mask)
    stairs(1:length(pattern),pattern);
    axis([l*100 l*100+2000 0 2]);
    
    % pattern * psk modulated signal
    axes(handles.axes_masked)
    plot(1:length(kimjae),kimjae);
    axis([l*100 l*100+2000 -2 2]);
end

    % u(n) pdf
    axes(handles.axes_pdf_u)
    plot(tt, pdf_u);
    axis([-4 4 0 0.1]); grid;
    
    
% --- Outputs from this function are returned to the command line.
function varargout = gui_signal_noise_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_close.
function pushbutton_close_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close;
