function varargout = temp_gui_sensing(varargin)
% TEMP_GUI_SENSING M-file for temp_gui_sensing.fig
%      TEMP_GUI_SENSING, by itself, creates a new TEMP_GUI_SENSING or raises the existing
%      singleton*.
%
%      H = TEMP_GUI_SENSING returns the handle to a new TEMP_GUI_SENSING or the handle to
%      the existing singleton*.
%
%      TEMP_GUI_SENSING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEMP_GUI_SENSING.M with the given input arguments.
%
%      TEMP_GUI_SENSING('Property','Value',...) creates a new TEMP_GUI_SENSING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before temp_gui_sensing_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to temp_gui_sensing_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help temp_gui_sensing

% Last Modified by GUIDE v2.5 27-Nov-2011 18:56:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @temp_gui_sensing_OpeningFcn, ...
                   'gui_OutputFcn',  @temp_gui_sensing_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before temp_gui_sensing is made visible.
function temp_gui_sensing_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to temp_gui_sensing (see VARARGIN)
clc;
global user_type;            %radio
global noise_type;           %radio
global algorithm;            %radio
global sampling_freq;        %edit
global primary_active;       %edit
global target;               %edit
global primary_network;      %edit
global second_network;       %edit
global frame;                %edit
global detection_time;       %edit
global alpha;       %edit
global beta;        %edit
global simulate_no;          %popup
global SensingTime;
global pdf_p;
global pdf_s;
global D;
global Pd;
global tt;
global d_threshold;
% Choose default command line output for temp_gui_sensing
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
% UIWAIT makes temp_gui_sensing wait for user response (see UIRESUME)
% uiwait(handles.figure1);
data =importdata('data.txt');
user_type=data(1);            %radio
noise_type=data(2);           %radio
algorithm=data(3);            %radio
sampling_freq=data(4);        %edit
primary_active=data(5);       %edit
target=data(6);               %edit
primary_network=data(7);      %edit
second_network=data(8);       %edit
frame=data(9);                %edit
detection_time=data(10);       %edit
simulate_no=data(11);          %popup
alpha = data(12);       %edit
beta = data(13);        %edit
tbdp =  data(14);       %edit
tit =  data(15);        %edit
ir =  data(16);         %edit

FrameDuration=frame;  
SensingTime=[0.001:0.0001:0.005];   
frame_s = sampling_freq*10^6;
targetPd=target;
ActiveProbability=primary_active; %P(H1)  
InActiveProbability=(1-ActiveProbability); %P(H0)  
SNRp_db=primary_network;  SNRs_db=second_network; 
SNRp=10^(SNRp_db/10);  SNRs=10^(SNRs_db/10); 
C0= log2(1+SNRs); C1=log2(1+(SNRs/(1+SNRp))); 
N=frame_s*SensingTime; % N=Fs*t
sensing_time=0.001;

SimN=simulate_no;
YP_test = zeros(1,length(SensingTime));
YS_test = zeros(1,length(SensingTime));
TP_test = zeros(length(SensingTime),SimN);
TS_test = zeros(length(SensingTime),SimN);
    
for k=1:SimN
 for i=1:length(SensingTime); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% BPSK & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     n = round(N(i));
     ip = rand(1,n)>0.5; % generating 0,1 with equal probability     
     mods = 2*ip-1; % BPSK modulation 0 -> -1; 1 -> 1 
     s = mods;
     u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n)); % white gaussian noise, 0dB variance 
     Eb_N0_dB = -15; 
     y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
     y_s=u; % < H0 >
 
    YP_test(i)=sum(abs(y).^2)/N(i); % SensingTime�� T(y) - < H1 >
    YS_test(i)=sum(abs(y_s).^2)/N(i); % SensingTime�� T(y) - < H0 >
    
 end
 
  TP_test(:,k) = YP_test(1,:).'; % 36 by SimN matrix , SensingTime�� t(y)�� SimNȸ ��� - < H1 >
  TS_test(:,k) = YS_test(1,:).'; % 36 by SimN matrix , SensingTime�� t(y)�� SimNȸ ��� - < H0 >

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%  T(y)  %%%%%%%%%%%%%%%%%%%%%%%%5
tt=0:0.001:2-0.001;
pdf_p=zeros(length(SensingTime),2000); % T(y)�� pdf - < H1 > 
for k=1:length(SensingTime)
    for jj=1:2000
        for j=1:SimN
            if((TP_test(k,j)>=0+jj*0.001)&&(TP_test(k,j)<0+jj*0.001+0.001))
                pdf_p(k,jj)=pdf_p(k,jj)+1;
            end
        end
    end
end

for i=1:length(SensingTime)
    pdf_p(i,:) = pdf_p(i,:)/SimN;
end


pdf_s=zeros(length(SensingTime),2000); % T(y)�� pdf - < H0 > 
for k=1:length(SensingTime)
    for jj=1:2000
        for j=1:SimN
            if((TS_test(k,j)>=0+jj*0.001)&&(TS_test(k,j)<0+jj*0.001+0.001))
                pdf_s(k,jj)=pdf_s(k,jj)+1;
            end
        end
    end
end

for i=1:length(SensingTime)
    pdf_s(i,:) = pdf_s(i,:)/SimN;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
average_YP_test = sum(YP_test)/length(SensingTime);
average_YS_test = sum(YS_test)/length(SensingTime);
set(handles.edit_t_h1,'string',num2str(average_YP_test));
set(handles.edit_t_h0,'string',num2str(average_YS_test));

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Simulated : Pf, Pd, R %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

threshold=[1:0.001:1.1]; % threshold ���� 
p_threshold=threshold.*1000; % threshold index
p_threshold=round(p_threshold);
d_threshold=zeros(1,length(SensingTime)); % detection threshold

% SensingTime�� Pd
Pd=zeros(length(threshold),length(SensingTime)); 
for i=1:length(SensingTime)
    for j=1:length(threshold)
        for d=p_threshold(j):length(tt)
            Pd(j,i)=Pd(j,i)+pdf_p(i,d);         %Pd(i,j)
        end
    end
end

D=zeros(1,length(SensingTime));
% Pd=0.9(Target Pd)�� �����ϴ� SensingTime�� threshold
for i=1:length(threshold)  
    for j=1:length(SensingTime)
        if targetPd-Pd(i,j)<0.001
            d_threshold(1,j)=threshold(1,i);    %d_threshold(i,j)
            D(1,j)=i;
        end
    end
end

% Pd=0.9�� SensingTime�� Pf
t_threshold=round(1000*d_threshold);
Pf=zeros(1,length(SensingTime));
for i=1:length(SensingTime)
    for d=t_threshold(i):length(tt)
        Pf(1,i)=Pf(1,i)+pdf_s(i,d);             %Pf(i,j)
    end
end


% edit_sensing_time
% sensing_time_str = get(handles.edit_sensing_time,'string');
% sensing_time = str2num(sensing_time_str);
set(handles.edit_sensing_time,'string',num2str(sensing_time));
no_sensing_time = sensing_time*10000-9;
% axes_h0
axes(handles.axes_h0)
plot(tt,pdf_s(no_sensing_time,:));
axis([0.9 1.1 0 0.1]);
% axes_h1 
axes(handles.axes_h1)
plot(tt,pdf_p(no_sensing_time,:));
axis([0.9 1.1 0 0.1]);

set(handles.edit_threshold,'string',num2str(d_threshold(1,no_sensing_time)));
set(handles.edit_re_threshold,'string',num2str(d_threshold(1,no_sensing_time)));

set(handles.edit_ex_pd,'string',num2str(Pd(D(1,no_sensing_time),no_sensing_time)));
set(handles.edit_ex_pf,'string',num2str(Pf(1,no_sensing_time)));
set(handles.edit_re_pf,'string',num2str(Pf(1,no_sensing_time)));
%------------ Pd, Pf ���ϱ�---------%
%============================= Example ===================================%
axes(handles.axes_example)
cla;        % �׷��������
plot(tt,pdf_p(no_sensing_time,:),'b'); 
hold on; plot(tt, pdf_s(no_sensing_time,:), 'r');
stem(d_threshold(1,no_sensing_time),1,'g');
axis([0.9 1.1 0 0.1]);
grid on;
xlabel('Variable');
ylabel('Probability'); legend('H1','H0');
%============================= Example ===================================%

%============================= Required =================================%

axes(handles.axes_required)
cla;        % �׷��������
plot(tt,pdf_p(no_sensing_time,:),'b'); 
hold on; plot(tt, pdf_s(no_sensing_time,:), 'r');
stem(d_threshold(1,no_sensing_time),1,'g');
axis([0.9 1.1 0 0.1]);
grid on;
xlabel('Variable');
ylabel('Probability'); legend('H1','H0');
%============================= Required =================================%
    axes(handles.axes_title)
    Aim2=imread('title_sensing.jpg','jpg');
    imshow(Aim2);

% --- Outputs from this function are returned to the command line.
function varargout = temp_gui_sensing_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%====================== PUSH_BUTTON ===============================%

% --- Executes on button press in pushbutton_up.
function pushbutton_up_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_up (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global D;
global SensingTime;

threshold_str =get(handles.edit_threshold,'string');   % threshold��
threshold = str2num(threshold_str);
if threshold == 1.1
    threshold = 1.1;
else
    threshold = threshold + 0.001;
    if D == length(SensingTime)
        D = length(SensingTime);
    else
        D = D+1;
    end
end
    set(handles.edit_threshold,'string',num2str(threshold));

% --- Executes on button press in pushbutton_down.
function pushbutton_down_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_down (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global D;
global SensingTime;

threshold_str =get(handles.edit_threshold,'string');   % threshold��
threshold = str2num(threshold_str);
if threshold == 0.9
    threshold = 0.9;
else
    threshold = threshold - 0.001;
    if D == 1
        D = 1;
    else
        D = D-1;
    end
end
set(handles.edit_threshold,'string',num2str(threshold));

% --- Executes on button press in pushbutton_ex_reset.
function pushbutton_ex_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_ex_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global user_type;            %radio
global noise_type;           %radio
global algorithm;            %radio
global sampling_freq;        %edit
global primary_active;       %edit
global target;               %edit
global primary_network;      %edit
global second_network;       %edit
global frame;                %edit
global detection_time;       %edit
global alpha;       %edit
global beta;        %edit
global simulate_no;          %popup
global SensingTime;
global pdf_p;
global pdf_s;
global Pd;
global D;
global tt;
%============================= Example ===============================%

%------------ Pd, Pf ���ϱ�---------%
threshold_str =get(handles.edit_threshold,'string');   % threshold��
threshold = str2num(threshold_str);
p_threshold=threshold.*1000; % threshold index
p_threshold=round(p_threshold);
d_threshold=zeros(1,length(SensingTime)); % detection threshold

Pf=zeros(1,length(SensingTime)); % SensingTime�� Pf
for i=1:length(SensingTime)
    for d=p_threshold:length(tt)
        Pf(1,i)=Pf(1,i)+pdf_s(i,d);
    end
end

% edit_sensing_time
sensing_time_str = get(handles.edit_sensing_time,'string');
sensing_time = str2num(sensing_time_str);
no_sensing_time = sensing_time*10000-9;

set(handles.edit_ex_pd,'string',num2str(Pd(D(1,no_sensing_time),no_sensing_time)));
set(handles.edit_ex_pf,'string',num2str(Pf(1,no_sensing_time)));
%------------ Pd, Pf ���ϱ�---------%
axes(handles.axes_example)
cla;        % �׷��������
plot(tt,pdf_p(no_sensing_time,:),'b'); 
hold on; plot(tt, pdf_s(no_sensing_time,:), 'r');
stem(threshold,1,'g');
axis([0.9 1.1 0 0.1]);
grid on;
xlabel('Variable');
ylabel('Probability'); legend('H1','H0');


% --- Executes on button press in pushbutton_re_reset.
function pushbutton_re_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_re_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global user_type;            %radio
global noise_type;           %radio
global algorithm;            %radio
global sampling_freq;        %edit
global primary_active;       %edit
global target;               %edit
global primary_network;      %edit
global second_network;       %edit
global frame;                %edit
global detection_time;       %edit
global simulate_no;          %popup
global SensingTime;
global pdf_p;
global pdf_s;
global Pd;
global D;
global tt;

s_str = get(handles.edit_sensing_time,'string');
s = str2num(s_str);
error = 0;
%�����޼���
if ( s < 0.0010 | s > 0.0045)
    errordlg('Please insert value from 0.001 to 0.0045','Input error');
    error = 1;
end


if error == 0
FrameDuration=frame;  
SensingTime=[0.001:0.0001:0.005];   
frame_s = sampling_freq*10^6;
targetPd=target;
ActiveProbability=primary_active; %P(H1)  
InActiveProbability=(1-ActiveProbability); %P(H0)  
SNRp_db=primary_network;  SNRs_db=second_network; 
SNRp=10^(SNRp_db/10);  SNRs=10^(SNRs_db/10); 
C0= log2(1+SNRs); C1=log2(1+(SNRs/(1+SNRp))); 
N=frame_s*SensingTime; % N=Fs*t

SimN=simulate_no;
YP_test = zeros(1,length(SensingTime));
YS_test = zeros(1,length(SensingTime));
TP_test = zeros(length(SensingTime),SimN);
TS_test = zeros(length(SensingTime),SimN);
    
for k=1:SimN
 for i=1:length(SensingTime); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% BPSK & CSCG %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     n = round(N(i));
     ip = rand(1,n)>0.5; % generating 0,1 with equal probability     
     mods = 2*ip-1; % BPSK modulation 0 -> -1; 1 -> 1 
     s = mods;
     u = 1/sqrt(2)*(randn(1,n) + sqrt(-1)*randn(1,n)); % white gaussian noise, 0dB variance 
     Eb_N0_dB = -15; 
     y = s*10^(Eb_N0_dB/20) + u; % < H1 >, SNR => -15dB 
     y_s=u; % < H0 >
 
    YP_test(i)=sum(abs(y).^2)/N(i); % SensingTime�� T(y) - < H1 >
    YS_test(i)=sum(abs(y_s).^2)/N(i); % SensingTime�� T(y) - < H0 >
    
 end
 
  TP_test(:,k) = YP_test(1,:).'; % 36 by SimN matrix , SensingTime�� t(y)�� SimNȸ ��� - < H1 >
  TS_test(:,k) = YS_test(1,:).'; % 36 by SimN matrix , SensingTime�� t(y)�� SimNȸ ��� - < H0 >

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%  T(y)  %%%%%%%%%%%%%%%%%%%%%%%%5
tt=0:0.001:2-0.001;
pdf_p=zeros(length(SensingTime),2000); % T(y)�� pdf - < H1 > 
for k=1:length(SensingTime)
    for jj=1:2000
        for j=1:SimN
            if((TP_test(k,j)>=0+jj*0.001)&&(TP_test(k,j)<0+jj*0.001+0.001))
                pdf_p(k,jj)=pdf_p(k,jj)+1;
            end
        end
    end
end

for i=1:length(SensingTime)
    pdf_p(i,:) = pdf_p(i,:)/SimN;
end


pdf_s=zeros(length(SensingTime),2000); % T(y)�� pdf - < H0 > 
for k=1:length(SensingTime)
    for jj=1:2000
        for j=1:SimN
            if((TS_test(k,j)>=0+jj*0.001)&&(TS_test(k,j)<0+jj*0.001+0.001))
                pdf_s(k,jj)=pdf_s(k,jj)+1;
            end
        end
    end
end

for i=1:length(SensingTime)
    pdf_s(i,:) = pdf_s(i,:)/SimN;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
average_YP_test = sum(YP_test)/length(SensingTime);
average_YS_test = sum(YS_test)/length(SensingTime);
set(handles.edit_t_h1,'string',num2str(average_YP_test));
set(handles.edit_t_h0,'string',num2str(average_YS_test));

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Simulated : Pf, Pd, R %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

threshold=[1:0.001:1.1]; % threshold ���� 
p_threshold=threshold.*1000; % threshold index
p_threshold=round(p_threshold);
d_threshold=zeros(1,length(SensingTime)); % detection threshold

% SensingTime�� Pd
Pd=zeros(length(threshold),length(SensingTime)); 
for i=1:length(SensingTime)
    for j=1:length(threshold)
        for d=p_threshold(j):length(tt)
            Pd(j,i)=Pd(j,i)+pdf_p(i,d);         %Pd(i,j)
        end
    end
end

D=zeros(1,length(SensingTime));
% Pd=0.9(Target Pd)�� �����ϴ� SensingTime�� threshold
for i=1:length(threshold)  
    for j=1:length(SensingTime)
        if targetPd-Pd(i,j)<0.001
            d_threshold(1,j)=threshold(1,i);    %d_threshold(i,j)
            D(1,j)=i;
        end
    end
end

% Pd=0.9�� SensingTime�� Pf
t_threshold=round(1000*d_threshold);
Pf=zeros(1,length(SensingTime));
for i=1:length(SensingTime)
    for d=t_threshold(i):length(tt)
        Pf(1,i)=Pf(1,i)+pdf_s(i,d);             %Pf(i,j)
    end
end


% edit_sensing_time
sensing_time_str = get(handles.edit_sensing_time,'string');
sensing_time = str2num(sensing_time_str);
no_sensing_time = sensing_time*10000-9;

% axes_h0
axes(handles.axes_h0)
plot(tt,pdf_s(no_sensing_time,:));
axis([0.9 1.1 0 0.1]);

% axes_h1 
axes(handles.axes_h1)
plot(tt,pdf_p(no_sensing_time,:));
axis([0.9 1.1 0 0.1]);

set(handles.edit_threshold,'string',num2str(d_threshold(1,no_sensing_time)));
set(handles.edit_re_threshold,'string',num2str(d_threshold(1,no_sensing_time)));

set(handles.edit_ex_pd,'string',num2str(Pd(D(1,no_sensing_time),no_sensing_time)));
set(handles.edit_ex_pf,'string',num2str(Pf(1,no_sensing_time)));
set(handles.edit_re_pf,'string',num2str(Pf(1,no_sensing_time)));
%------------ Pd, Pf ���ϱ�---------%
%============================= Example ===================================%
axes(handles.axes_example)
cla;        % �׷��������
plot(tt,pdf_p(no_sensing_time,:),'b'); 
hold on; plot(tt, pdf_s(no_sensing_time,:), 'r');
stem(d_threshold(1,no_sensing_time),1,'g');
axis([0.9 1.1 0 0.1]);
grid on;
xlabel('Variable');
ylabel('Probability'); legend('H1','H0');
%============================= Example ===================================%

%============================= Required =================================%

axes(handles.axes_required)
cla;        % �׷��������
plot(tt,pdf_p(no_sensing_time,:),'b'); 
hold on; plot(tt, pdf_s(no_sensing_time,:), 'r');
stem(d_threshold(1,no_sensing_time),1,'g');
axis([0.9 1.1 0 0.1]);
grid on;
xlabel('Variable');
ylabel('Probability'); legend('H1','H0');
%============================= Required =================================%

end %error �϶� if end


% --- Executes on button press in pushbutton_close.
function pushbutton_close_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
%====================== PUSH_BUTTON ===============================%
%====================== EDIT_TEXT ===============================%
function edit_ex_pd_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ex_pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ex_pd as text
%        str2double(get(hObject,'String')) returns contents of edit_ex_pd as a double


% --- Executes during object creation, after setting all properties.
function edit_ex_pd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ex_pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ex_pf_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ex_pf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ex_pf as text
%        str2double(get(hObject,'String')) returns contents of edit_ex_pf as a double


% --- Executes during object creation, after setting all properties.
function edit_ex_pf_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ex_pf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_t_h0_Callback(hObject, eventdata, handles)
% hObject    handle to edit_t_h0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_t_h0 as text
%        str2double(get(hObject,'String')) returns contents of edit_t_h0 as a double


% --- Executes during object creation, after setting all properties.
function edit_t_h0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_t_h0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_t_h1_Callback(hObject, eventdata, handles)
% hObject    handle to edit_t_h1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_t_h1 as text
%        str2double(get(hObject,'String')) returns contents of edit_t_h1 as a double


% --- Executes during object creation, after setting all properties.
function edit_t_h1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_t_h1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_re_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to edit_re_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_re_threshold as text
%        str2double(get(hObject,'String')) returns contents of edit_re_threshold as a double


% --- Executes during object creation, after setting all properties.
function edit_re_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_re_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_re_pd_Callback(hObject, eventdata, handles)
% hObject    handle to edit_re_pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_re_pd as text
%        str2double(get(hObject,'String')) returns contents of edit_re_pd as a double


% --- Executes during object creation, after setting all properties.
function edit_re_pd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_re_pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_re_pf_Callback(hObject, eventdata, handles)
% hObject    handle to edit_re_pf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_re_pf as text
%        str2double(get(hObject,'String')) returns contents of edit_re_pf as a double


% --- Executes during object creation, after setting all properties.
function edit_re_pf_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_re_pf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to edit_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_threshold as text
%        str2double(get(hObject,'String')) returns contents of edit_threshold as a double


% --- Executes during object creation, after setting all properties.
function edit_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_sensing_time_Callback(hObject, eventdata, handles)
% hObject    handle to edit_sensing_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_sensing_time as text
%        str2double(get(hObject,'String')) returns contents of edit_sensing_time as a double


% --- Executes during object creation, after setting all properties.
function edit_sensing_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_sensing_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%====================== EDIT_TEXT ===============================%
