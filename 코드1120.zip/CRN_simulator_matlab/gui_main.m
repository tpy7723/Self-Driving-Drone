function varargout = gui_main(varargin)
% GUI_MAIN M-file for gui_main.fig
%      GUI_MAIN, by itself, creates a new GUI_MAIN or raises the existing
%      singleton*.
%
%      H = GUI_MAIN returns the handle to a new GUI_MAIN or the handle to
%      the existing singleton*.
%
%      GUI_MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_MAIN.M with the given input arguments.
%
%      GUI_MAIN('Property','Value',...) creates a new GUI_MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_main

% Last Modified by GUIDE v2.5 03-Dec-2011 17:29:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_main_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_main is made visible.
function gui_main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_main (see VARARGIN)

% Choose default command line output for gui_main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui_main wait for user response (see UIRESUME)
% uiwait(handles.figure1);
user_type=0;            %radio
noise_type=0;           %radio
algorithm=0;            %radio
sampling_freq=0;        %edit
primary_active=0;       %edit P(H1)
target=0;               %edit Target Pd
primary_network=0;      %edit Target SNR
second_network=0;       %edit SNR for 2nd
frame=0;                %edit sensing intervals
detection_time=0;       %edit
alpha=0;                %edit
beta=0;                 %edit
simulate_no=0;          %popup
tbdp=0;                 %edit
tit=0;                  %edit
ir=0;                   %edit

sampling_freq_str = get(handles.edit_sampling,'string');
sampling_freq = str2num(sampling_freq_str);
primary_active_str = get(handles.edit_primary_active,'string');
primary_active = str2num(primary_active_str);
target_str = get(handles.edit_target,'string');
target = str2num(target_str);
primary_network_str = get(handles.edit_primary_network,'string');
primary_network = str2num(primary_network_str);
second_network_str = get(handles.edit_second_network,'string');
second_network = str2num(second_network_str);
frame_str = get(handles.edit_frame,'string');
frame = str2num(frame_str);
detection_time_str = get(handles.edit_tbdp,'string');
detection_time = str2num(detection_time_str);
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);
tbdp_str = get(handles.edit_tbdp,'string');
tbdp = str2num(tbdp_str);
tit_str = get(handles.edit_tit,'string');
tit = str2num(tit_str);
ir_str = get(handles.edit_ir,'string');
ir = str2num(ir_str);
%-----------------radio----------------------%
if get(handles.radiobutton_real,'Value')
    user_type=1;
elseif get(handles.radiobutton_cscg,'Value')
    user_type=2;
elseif get(handles.radiobutton_bpsk,'Value')
    user_type=3;
elseif get(handles.radiobutton_qpsk,'Value')
    user_type=4;
end
if get(handles.radiobutton_nreal,'Value')
    noise_type=1;
elseif get(handles.radiobutton_ncscg,'Value')
    noise_type=2;
end
if get(handles.radiobutton_energy,'Value')
    algorithm=1;
elseif get(handles.radiobutton_matched,'Value')
    algorithm=2;
elseif get(handles.radiobutton_cyclo,'Value')
    algorithm=3;
end
%-----------------radio----------------------%
%-----------------popup----------------------%
contents = (get(handles.popupmenu_simulate,'String'));
Cont = contents{get(handles.popupmenu_simulate,'Value')};
if strcmp(Cont, '100')
    simulate_no = 100;
elseif strcmp(Cont, '300')
    simulate_no = 300;
elseif strcmp(Cont, '500')
    simulate_no = 500;
elseif strcmp(Cont, '1000')
    simulate_no = 1000;
elseif strcmp(Cont, '2000')
    simulate_no = 2000;
end

%-----------------popup----------------------%
       
a = 1:16;
a = [user_type noise_type algorithm sampling_freq primary_active target....
    primary_network second_network frame detection_time simulate_no....
    alpha beta tbdp tit ir];
file_h = fopen('data.txt','w');
fprintf(file_h,'%d\n',a);
fclose(file_h);

axes(handles.axes_test)
Aim=imread('test.jpg','jpg');
imshow(Aim);
axes(handles.axes_title)
Aim2=imread('title_main.jpg','jpg');
imshow(Aim2);


% --- Outputs from this function are returned to the command line.
function varargout = gui_main_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%====================== PUSH_BUTTON ===============================%
% --- Executes on button press in pushbutton_calculate.
function pushbutton_calculate_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_calculate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);

primary_active = beta/(alpha+beta);
inactive = 1 - primary_active;
TIT = (1/10)*(1/alpha);
set(handles.edit_primary_active,'string',num2str(primary_active));
set(handles.edit_ph0,'string',num2str(inactive));
set(handles.edit_tit,'string',num2str(TIT));

% --- Executes on button press in pushbutton_signal.
function pushbutton_signal_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_signal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%close all;
user_type=0;            %radio
noise_type=0;           %radio
algorithm=0;            %radio
sampling_freq=0;        %edit
primary_active=0;       %edit P(H1)
target=0;               %edit Target Pd
primary_network=0;      %edit Target SNR
second_network=0;       %edit SNR for 2nd
frame=0;                %edit sensing intervals
detection_time=0;       %edit
alpha=0;                %edit
beta=0;                 %edit
simulate_no=0;          %popup
tbdp=0;                 %edit
tit=0;                  %edit
ir=0;                   %edit

sampling_freq_str = get(handles.edit_sampling,'string');
sampling_freq = str2num(sampling_freq_str);
primary_active_str = get(handles.edit_primary_active,'string');
primary_active = str2num(primary_active_str);
target_str = get(handles.edit_target,'string');
target = str2num(target_str);
primary_network_str = get(handles.edit_primary_network,'string');
primary_network = str2num(primary_network_str);
second_network_str = get(handles.edit_second_network,'string');
second_network = str2num(second_network_str);
frame_str = get(handles.edit_frame,'string');
frame = str2num(frame_str);
detection_time_str = get(handles.edit_tbdp,'string');
detection_time = str2num(detection_time_str);
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);
tbdp_str = get(handles.edit_tbdp,'string');
tbdp = str2num(tbdp_str);
tit_str = get(handles.edit_tit,'string');
tit = str2num(tit_str);
ir_str = get(handles.edit_ir,'string');
ir = str2num(ir_str);
%-----------------radio----------------------%
if get(handles.radiobutton_real,'Value')
    user_type=1;
elseif get(handles.radiobutton_cscg,'Value')
    user_type=2;
elseif get(handles.radiobutton_bpsk,'Value')
    user_type=3;
elseif get(handles.radiobutton_qpsk,'Value')
    user_type=4;
end
if get(handles.radiobutton_nreal,'Value')
    noise_type=1;
elseif get(handles.radiobutton_ncscg,'Value')
    noise_type=2;
end
if get(handles.radiobutton_energy,'Value')
    algorithm=1;
elseif get(handles.radiobutton_matched,'Value')
    algorithm=2;
elseif get(handles.radiobutton_cyclo,'Value')
    algorithm=3;
end
%-----------------radio----------------------%
%-----------------popup----------------------%
contents = (get(handles.popupmenu_simulate,'String'));
Cont = contents{get(handles.popupmenu_simulate,'Value')};
if strcmp(Cont, '100')
    simulate_no = 100;
elseif strcmp(Cont, '300')
    simulate_no = 300;
elseif strcmp(Cont, '500')
    simulate_no = 500;
elseif strcmp(Cont, '1000')
    simulate_no = 1000;
elseif strcmp(Cont, '2000')
    simulate_no = 2000;
end

%-----------------popup----------------------%
       
a = 1:16;
a = [user_type noise_type algorithm sampling_freq primary_active target....
    primary_network second_network frame detection_time simulate_no....
    alpha beta tbdp tit ir];
file_h = fopen('data.txt','w');
fprintf(file_h,'%d\n',a);
fclose(file_h);

run gui_sn

% --- Executes on button press in pushbutton_sensing.
function pushbutton_sensing_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_sensing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%close all;
user_type=0;            %radio
noise_type=0;           %radio
algorithm=0;            %radio
sampling_freq=0;        %edit
primary_active=0;       %edit P(H1)
target=0;               %edit Target Pd
primary_network=0;      %edit Target SNR
second_network=0;       %edit SNR for 2nd
frame=0;                %edit sensing intervals
detection_time=0;       %edit
alpha=0;                %edit
beta=0;                 %edit
simulate_no=0;          %popup
tbdp=0;                 %edit
tit=0;                  %edit
ir=0;                   %edit

sampling_freq_str = get(handles.edit_sampling,'string');
sampling_freq = str2num(sampling_freq_str);
primary_active_str = get(handles.edit_primary_active,'string');
primary_active = str2num(primary_active_str);
target_str = get(handles.edit_target,'string');
target = str2num(target_str);
primary_network_str = get(handles.edit_primary_network,'string');
primary_network = str2num(primary_network_str);
second_network_str = get(handles.edit_second_network,'string');
second_network = str2num(second_network_str);
frame_str = get(handles.edit_frame,'string');
frame = str2num(frame_str);
detection_time_str = get(handles.edit_tbdp,'string');
detection_time = str2num(detection_time_str);
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);
tbdp_str = get(handles.edit_tbdp,'string');
tbdp = str2num(tbdp_str);
tit_str = get(handles.edit_tit,'string');
tit = str2num(tit_str);
ir_str = get(handles.edit_ir,'string');
ir = str2num(ir_str);
%-----------------radio----------------------%
if get(handles.radiobutton_real,'Value')
    user_type=1;
elseif get(handles.radiobutton_cscg,'Value')
    user_type=2;
elseif get(handles.radiobutton_bpsk,'Value')
    user_type=3;
elseif get(handles.radiobutton_qpsk,'Value')
    user_type=4;
end
if get(handles.radiobutton_nreal,'Value')
    noise_type=1;
elseif get(handles.radiobutton_ncscg,'Value')
    noise_type=2;
end
if get(handles.radiobutton_energy,'Value')
    algorithm=1;
elseif get(handles.radiobutton_matched,'Value')
    algorithm=2;
elseif get(handles.radiobutton_cyclo,'Value')
    algorithm=3;
end
%-----------------radio----------------------%
%-----------------popup----------------------%
contents = (get(handles.popupmenu_simulate,'String'));
Cont = contents{get(handles.popupmenu_simulate,'Value')};
if strcmp(Cont, '100')
    simulate_no = 100;
elseif strcmp(Cont, '300')
    simulate_no = 300;
elseif strcmp(Cont, '500')
    simulate_no = 500;
elseif strcmp(Cont, '1000')
    simulate_no = 1000;
elseif strcmp(Cont, '2000')
    simulate_no = 2000;
end

%-----------------popup----------------------%
       
a = 1:16;
a = [user_type noise_type algorithm sampling_freq primary_active target....
    primary_network second_network frame detection_time simulate_no....
    alpha beta tbdp tit ir];
file_h = fopen('data.txt','w');
fprintf(file_h,'%d\n',a);
fclose(file_h);
run gui_sensing;

% --- Executes on button press in pushbutton_result_sensing.
function pushbutton_result_sensing_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_result_sensing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
user_type=0;            %radio
noise_type=0;           %radio
algorithm=0;            %radio
sampling_freq=0;        %edit
primary_active=0;       %edit P(H1)
target=0;               %edit Target Pd
primary_network=0;      %edit Target SNR
second_network=0;       %edit SNR for 2nd
frame=0;                %edit sensing intervals
detection_time=0;       %edit
alpha=0;                %edit
beta=0;                 %edit
simulate_no=0;          %popup
tbdp=0;                 %edit
tit=0;                  %edit
ir=0;                   %edit

sampling_freq_str = get(handles.edit_sampling,'string');
sampling_freq = str2num(sampling_freq_str);
primary_active_str = get(handles.edit_primary_active,'string');
primary_active = str2num(primary_active_str);
target_str = get(handles.edit_target,'string');
target = str2num(target_str);
primary_network_str = get(handles.edit_primary_network,'string');
primary_network = str2num(primary_network_str);
second_network_str = get(handles.edit_second_network,'string');
second_network = str2num(second_network_str);
frame_str = get(handles.edit_frame,'string');
frame = str2num(frame_str);
detection_time_str = get(handles.edit_tbdp,'string');
detection_time = str2num(detection_time_str);
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);
tbdp_str = get(handles.edit_tbdp,'string');
tbdp = str2num(tbdp_str);
tit_str = get(handles.edit_tit,'string');
tit = str2num(tit_str);
ir_str = get(handles.edit_ir,'string');
ir = str2num(ir_str);
%-----------------radio----------------------%
if get(handles.radiobutton_real,'Value')
    user_type=1;
elseif get(handles.radiobutton_cscg,'Value')
    user_type=2;
elseif get(handles.radiobutton_bpsk,'Value')
    user_type=3;
elseif get(handles.radiobutton_qpsk,'Value')
    user_type=4;
end
if get(handles.radiobutton_nreal,'Value')
    noise_type=1;
elseif get(handles.radiobutton_ncscg,'Value')
    noise_type=2;
end
if get(handles.radiobutton_energy,'Value')
    algorithm=1;
elseif get(handles.radiobutton_matched,'Value')
    algorithm=2;
elseif get(handles.radiobutton_cyclo,'Value')
    algorithm=3;
end
%-----------------radio----------------------%
%-----------------popup----------------------%
contents = (get(handles.popupmenu_simulate,'String'));
Cont = contents{get(handles.popupmenu_simulate,'Value')};
if strcmp(Cont, '100')
    simulate_no = 100;
elseif strcmp(Cont, '300')
    simulate_no = 300;
elseif strcmp(Cont, '500')
    simulate_no = 500;
elseif strcmp(Cont, '1000')
    simulate_no = 1000;
elseif strcmp(Cont, '2000')
    simulate_no = 2000;
end

%-----------------popup----------------------%
       
a = 1:16;
a = [user_type noise_type algorithm sampling_freq primary_active target....
    primary_network second_network frame detection_time simulate_no....
    alpha beta tbdp tit ir];
file_h = fopen('data.txt','w');
fprintf(file_h,'%d\n',a);
fclose(file_h);

run gui_result

% --- Executes on button press in pushbutton_result_interval.
function pushbutton_result_interval_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_result_interval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
user_type=0;            %radio
noise_type=0;           %radio
algorithm=0;            %radio
sampling_freq=0;        %edit
primary_active=0;       %edit P(H1)
target=0;               %edit Target Pd
primary_network=0;      %edit Target SNR
second_network=0;       %edit SNR for 2nd
frame=0;                %edit sensing intervals
detection_time=0;       %edit
alpha=0;                %edit
beta=0;                 %edit
simulate_no=0;          %popup
tbdp=0;                 %edit
tit=0;                  %edit
ir=0;                   %edit

sampling_freq_str = get(handles.edit_sampling,'string');
sampling_freq = str2num(sampling_freq_str);
primary_active_str = get(handles.edit_primary_active,'string');
primary_active = str2num(primary_active_str);
target_str = get(handles.edit_target,'string');
target = str2num(target_str);
primary_network_str = get(handles.edit_primary_network,'string');
primary_network = str2num(primary_network_str);
second_network_str = get(handles.edit_second_network,'string');
second_network = str2num(second_network_str);
frame_str = get(handles.edit_frame,'string');
frame = str2num(frame_str);
detection_time_str = get(handles.edit_tbdp,'string');
detection_time = str2num(detection_time_str);
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);
tbdp_str = get(handles.edit_tbdp,'string');
tbdp = str2num(tbdp_str);
tit_str = get(handles.edit_tit,'string');
tit = str2num(tit_str);
ir_str = get(handles.edit_ir,'string');
ir = str2num(ir_str);
%-----------------radio----------------------%
if get(handles.radiobutton_real,'Value')
    user_type=1;
elseif get(handles.radiobutton_cscg,'Value')
    user_type=2;
elseif get(handles.radiobutton_bpsk,'Value')
    user_type=3;
elseif get(handles.radiobutton_qpsk,'Value')
    user_type=4;
end
if get(handles.radiobutton_nreal,'Value')
    noise_type=1;
elseif get(handles.radiobutton_ncscg,'Value')
    noise_type=2;
end
if get(handles.radiobutton_energy,'Value')
    algorithm=1;
elseif get(handles.radiobutton_matched,'Value')
    algorithm=2;
elseif get(handles.radiobutton_cyclo,'Value')
    algorithm=3;
end
%-----------------radio----------------------%
%-----------------popup----------------------%
contents = (get(handles.popupmenu_simulate,'String'));
Cont = contents{get(handles.popupmenu_simulate,'Value')};
if strcmp(Cont, '100')
    simulate_no = 100;
elseif strcmp(Cont, '300')
    simulate_no = 300;
elseif strcmp(Cont, '500')
    simulate_no = 500;
elseif strcmp(Cont, '1000')
    simulate_no = 1000;
elseif strcmp(Cont, '2000')
    simulate_no = 2000;
end

%-----------------popup----------------------%
       
a = 1:16;
a = [user_type noise_type algorithm sampling_freq primary_active target....
    primary_network second_network frame detection_time simulate_no....
    alpha beta tbdp tit ir]
file_h = fopen('data.txt','w');
fprintf(file_h,'%d\n',a);
fclose(file_h);

run gui_intervaldecision;

% --- Executes on button press in pushbutton_optimal.
function pushbutton_optimal_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_optimal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
user_type=0;            %radio
noise_type=0;           %radio
algorithm=0;            %radio
sampling_freq=0;        %edit
primary_active=0;       %edit P(H1)
target=0;               %edit Target Pd
primary_network=0;      %edit Target SNR
second_network=0;       %edit SNR for 2nd
frame=0;                %edit sensing intervals
detection_time=0;       %edit
alpha=0;                %edit
beta=0;                 %edit
simulate_no=0;          %popup
tbdp=0;                 %edit
tit=0;                  %edit
ir=0;                   %edit

sampling_freq_str = get(handles.edit_sampling,'string');
sampling_freq = str2num(sampling_freq_str);
primary_active_str = get(handles.edit_primary_active,'string');
primary_active = str2num(primary_active_str);
target_str = get(handles.edit_target,'string');
target = str2num(target_str);
primary_network_str = get(handles.edit_primary_network,'string');
primary_network = str2num(primary_network_str);
second_network_str = get(handles.edit_second_network,'string');
second_network = str2num(second_network_str);
frame_str = get(handles.edit_frame,'string');
frame = str2num(frame_str);
detection_time_str = get(handles.edit_tbdp,'string');
detection_time = str2num(detection_time_str);
alpha_str = get(handles.edit_alpha,'string');
alpha = str2num(alpha_str);
beta_str = get(handles.edit_beta,'string');
beta = str2num(beta_str);
tbdp_str = get(handles.edit_tbdp,'string');
tbdp = str2num(tbdp_str);
tit_str = get(handles.edit_tit,'string');
tit = str2num(tit_str);
ir_str = get(handles.edit_ir,'string');
ir = str2num(ir_str);
%-----------------radio----------------------%
if get(handles.radiobutton_real,'Value')
    user_type=1;
elseif get(handles.radiobutton_cscg,'Value')
    user_type=2;
elseif get(handles.radiobutton_bpsk,'Value')
    user_type=3;
elseif get(handles.radiobutton_qpsk,'Value')
    user_type=4;
end
if get(handles.radiobutton_nreal,'Value')
    noise_type=1;
elseif get(handles.radiobutton_ncscg,'Value')
    noise_type=2;
end
if get(handles.radiobutton_energy,'Value')
    algorithm=1;
elseif get(handles.radiobutton_matched,'Value')
    algorithm=2;
elseif get(handles.radiobutton_cyclo,'Value')
    algorithm=3;
end
%-----------------radio----------------------%
%-----------------popup----------------------%
contents = (get(handles.popupmenu_simulate,'String'));
Cont = contents{get(handles.popupmenu_simulate,'Value')};
if strcmp(Cont, '100')
    simulate_no = 100;
elseif strcmp(Cont, '300')
    simulate_no = 300;
elseif strcmp(Cont, '500')
    simulate_no = 500;
elseif strcmp(Cont, '1000')
    simulate_no = 1000;
elseif strcmp(Cont, '2000')
    simulate_no = 2000;
end

%-----------------popup----------------------%
       
a = 1:16;
a = [user_type noise_type algorithm sampling_freq primary_active target....
    primary_network second_network frame detection_time simulate_no....
    alpha beta tbdp tit ir];
file_h = fopen('data.txt','w');
fprintf(file_h,'%d\n',a);
fclose(file_h);

run gui_optimal_final;

% --- Executes on button press in pushbutton_reset.
function pushbutton_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sampling_freq = 6;
set(handles.edit_sampling,'string',num2str(sampling_freq));
primary_active = 0.4;
set(handles.edit_primary_active,'string',num2str(primary_active));
target = 0.9;
set(handles.edit_target,'string',num2str(target));
primary_network = -15;
set(handles.edit_primary_network,'string',num2str(primary_network));
second_network = 20;
set(handles.edit_second_network,'string',num2str(second_network));
frame = 0.1;
set(handles.edit_frame,'string',num2str(frame));
detection_time = 0.01;
set(handles.edit_tbdp,'string',num2str(detection_time));
alpha = 0.3;
set(handles.edit_alpha,'string',num2str(alpha));
beta = 0.2;
set(handles.edit_beta,'string',num2str(beta));
ph0 = 0.6;
set(handles.edit_ph0,'string',num2str(ph0));
tbdp = 0.9;
set(handles.edit_tbdp,'string',num2str(tbdp));
tit = 0.3;
set(handles.edit_tit,'string',num2str(tit));
ir = 0.1;
set(handles.edit_ir,'string',num2str(ir));


%====================== PUSH_BUTTON ===============================%

%====================== EDIT_TEXT ===============================%
function edit_second_network_Callback(hObject, eventdata, handles)
% hObject    handle to edit_second_network (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_second_network as text
%        str2double(get(hObject,'String')) returns contents of edit_second_network as a double


% --- Executes during object creation, after setting all properties.
function edit_second_network_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_second_network (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_primary_network_Callback(hObject, eventdata, handles)
% hObject    handle to edit_primary_network (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_primary_network as text
%        str2double(get(hObject,'String')) returns contents of edit_primary_network as a double


% --- Executes during object creation, after setting all properties.
function edit_primary_network_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_primary_network (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_frame_Callback(hObject, eventdata, handles)
% hObject    handle to edit_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_frame as text
%        str2double(get(hObject,'String')) returns contents of edit_frame as a double


% --- Executes during object creation, after setting all properties.
function edit_frame_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit_sampling_Callback(hObject, eventdata, handles)
% hObject    handle to edit_sampling (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_sampling as text
%        str2double(get(hObject,'String')) returns contents of edit_sampling as a double


% --- Executes during object creation, after setting all properties.
function edit_sampling_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_sampling (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_primary_active_Callback(hObject, eventdata, handles)
% hObject    handle to edit_primary_active (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_primary_active as text
%        str2double(get(hObject,'String')) returns contents of edit_primary_active as a double


% --- Executes during object creation, after setting all properties.
function edit_primary_active_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_primary_active (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_target_Callback(hObject, eventdata, handles)
% hObject    handle to edit_target (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_target as text
%        str2double(get(hObject,'String')) returns contents of edit_target as a double


% --- Executes during object creation, after setting all properties.
function edit_target_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_target (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_required_probability_Callback(hObject, eventdata, handles)
% hObject    handle to edit_required_probability (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_required_probability as text
%        str2double(get(hObject,'String')) returns contents of edit_required_probability as a double


% --- Executes during object creation, after setting all properties.
function edit_required_probability_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_required_probability (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_tbdp_Callback(hObject, eventdata, handles)
% hObject    handle to edit_tbdp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_tbdp as text
%        str2double(get(hObject,'String')) returns contents of edit_tbdp as a double


% --- Executes during object creation, after setting all properties.
function edit_tbdp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_tbdp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_alpha_Callback(hObject, eventdata, handles)
% hObject    handle to edit_alpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_alpha as text
%        str2double(get(hObject,'String')) returns contents of edit_alpha as a double


% --- Executes during object creation, after setting all properties.
function edit_alpha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_alpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_beta_Callback(hObject, eventdata, handles)
% hObject    handle to edit_beta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_beta as text
%        str2double(get(hObject,'String')) returns contents of edit_beta as a double


% --- Executes during object creation, after setting all properties.
function edit_beta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_beta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_ph0_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ph0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ph0 as text
%        str2double(get(hObject,'String')) returns contents of edit_ph0 as a double


% --- Executes during object creation, after setting all properties.
function edit_ph0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ph0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_tit_Callback(hObject, eventdata, handles)
% hObject    handle to edit_tit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_tit as text
%        str2double(get(hObject,'String')) returns contents of edit_tit as a double


% --- Executes during object creation, after setting all properties.
function edit_tit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_tit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ir_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ir as text
%        str2double(get(hObject,'String')) returns contents of edit_ir as a double


% --- Executes during object creation, after setting all properties.
function edit_ir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%====================== EDIT_TEXT ===============================%

%====================== RADIO_BUTTON ===============================%
% --- Executes on button press in radiobutton_bpsk.
function radiobutton_bpsk_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_bpsk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_bpsk


% --- Executes on button press in radiobutton_real.
function radiobutton_real_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_real (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_real


% --- Executes on button press in radiobutton_cscg.
function radiobutton_cscg_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_cscg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_cscg


% --- Executes on button press in radiobutton_nreal.
function radiobutton_nreal_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_nreal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_nreal


% --- Executes on button press in radiobutton_ncscg.
function radiobutton_ncscg_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_ncscg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_ncscg


% --- Executes on button press in radiobutton_energy.
function radiobutton_energy_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_energy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_energy


% --- Executes on button press in radiobutton_matched.
function radiobutton_matched_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_matched (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_matched


% --- Executes on button press in radiobutton_cyclo.
function radiobutton_cyclo_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_cyclo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_cyclo


% --- Executes on button press in radiobutton_qpsk.
function radiobutton_qpsk_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton_qpsk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton_qpsk
%====================== RADIO_BUTTON ===============================%

%====================== POPUP_MENU ===============================%
% --- Executes on selection change in popupmenu_energy.
function popupmenu_energy_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_energy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_energy contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_energy


% --- Executes during object creation, after setting all properties.
function popupmenu_energy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_energy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_simulate.
function popupmenu_simulate_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_simulate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_simulate contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_simulate


% --- Executes during object creation, after setting all properties.
function popupmenu_simulate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_simulate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_sensing.
function popupmenu_sensing_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_sensing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_sensing contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_sensing


% --- Executes during object creation, after setting all properties.
function popupmenu_sensing_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_sensing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%====================== POPUP_MENU ===============================%


% --------------------------------------------------------------------
function help_Callback(hObject, eventdata, handles)
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
