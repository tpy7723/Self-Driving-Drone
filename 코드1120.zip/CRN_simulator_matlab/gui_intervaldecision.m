function varargout = gui_intervaldecision(varargin)
% gui_intervaldecision M-file for gui_intervaldecision.fig
%      gui_intervaldecision, by itself, creates a new gui_intervaldecision or raises the existing
%      singleton*.
%
%      H = gui_intervaldecision returns the handle to a new gui_intervaldecision or the handle to
%      the existing singleton*.
%
%      gui_intervaldecision('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in gui_intervaldecision.M with the given input arguments.
%
%      gui_intervaldecision('Property','Value',...) creates a new gui_intervaldecision or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_intervaldecision_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_intervaldecision_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_intervaldecision

% Last Modified by GUIDE v2.5 04-Dec-2011 17:05:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_intervaldecision_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_intervaldecision_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_intervaldecision is made visible.
function gui_intervaldecision_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_intervaldecision (see VARARGIN)
clc;

% Choose default command line output for gui_intervaldecision
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
%========== file open ===================%
data =importdata('data.txt');
user_type=data(1);            %radio
noise_type=data(2);           %radio
algorithm=data(3);            %radio
sampling_freq=data(4);        %edit
primary_active=data(5);       %edit PH1
target=data(6);               %edit
primary_network=data(7);      %edit Target SNR 
second_network=data(8);       %edit
frame=data(9);                %edit
detection_time=data(10);       %edit
simulate_no=data(11);          %popup
alpha = data(12);       %edit
beta = data(13);        %edit
tbdp =  data(14);       %edit
tit =  data(15);        %edit
ir =  data(16);         %edit
%========== file open ===================%
pd_str = get(handles.edit_pd,'string'); % ó���� 0.9��, 4��° â������ �Է� �� reset �� �� �ֵ��� 
pd = str2num(pd_str);
pf_str = get(handles.edit_pf,'string'); % ó���� 0.1��, 4��° â������ �Է� �� reset �� �� �ֵ��� 
pf = str2num(pf_str);
PH1 = primary_active; % Main â���� �Է�
PH0 = 1-PH1;
a = alpha; % alpha Main â���� �Է� , 4��°â������ �Է� �� reset �� �� �ֵ���  
set(handles.edit_alpha,'string',num2str(a));
b = beta; % beta Main â���� �Է� , 4��°â������ �Է� �� reset �� �� �ֵ���  
set(handles.edit_beta,'string',num2str(b));
TTIT = (1/10)*(1/a); % Mainâ���� �⺻�� 0.3 , 4��° â���� alpha �ٲ㼭 reset �ϸ� ���ǵ��� 
d = 0.0001; % ��� interval����
TBDP = tbdp; % Main â���� �⺻�� 0.9 
set(handles.edit_tbdp,'string',num2str(TBDP));
IR = ir; % Main â���� �⺻�� 0.1
set(handles.edit_ir,'string',num2str(IR));

%================== sensing time ��� =====================%
v_dB = primary_network; % Mainâ���� Target SNR �� �Է¹޴� ���� �������� 
v=10^(v_dB/10);
C0= log2(1+v); C1=log2(1+(v/(1+v)));
fs=sampling_freq*10^6; % Mainâ���� sampling freq �� �Է¹޴� ���� ������ 

N_min=zeros(length(pf),length(pd));
Optimal_Ts=zeros(length(pf),length(pd));
N_min=(1/v^2).*(qfuncinv(pf)-qfuncinv(pd).*(2*v+1)^1/2).^2;
Ts=N_min/fs; % sensing time
set(handles.text_sensingtime,'string',num2str(Ts*1000));
%==========================================================%


TI=[Ts:d:TTIT].';

num=zeros(length(TI),1);
for L=1:length(TI)
    num(L,1)=floor(TTIT/TI(L));
end

Pd=zeros(max(num)+1,1); %%%%%%%%%%%%%%%% Pd
for i=0:max(num)
    Pd(i+1,1)=1-(1-pd)^(i);
end

Pd2=zeros(max(num)+2,1); %%%%%%%%%%%%%%%% Pd2
for i=0:max(num)+1
    Pd2(i+1,1)=1-(1-pd)^(i);
end

PDO_IMD=zeros(length(TI),max(num)); %%%%%%%%%%%%%%%% PDO_IMD
for L=1:length(TI)
    for i=0:num(L,1)
        if i==num(L,1)
            PDO_IMD(L,i+1)=exp((-a)*(i)*TI(L,1));
        else
            PDO_IMD(L,i+1)=(exp((-a)*(i)*TI(L,1))-exp((-a)*(i+1)*TI(L,1)));
        end
    end   
end

PD_IMD=zeros(length(TI),1); %%%%%%%%%%%%%%%% PD_IMD
for L=1:length(TI)
    PD_IMD(L,1) = sum(PDO_IMD(L,:).*Pd(:,1).');    
end

ts=zeros(1,length(TI));
for L=1:length(TI)
    ts(1,L)=((num(L,1)+1)*(TI(L,1)))-TTIT;
end

PDO_CID1=zeros(max(num)+1,length(TI)); %%%%%%%%%%%%%%%% PDO_CID

for L=1:length(TI)
    for i=0:num(L,1)
        if i == 0
            PDO_CID1(i+1,L)=((a-b)*(1-exp(-b*ts(L))) - b*exp(-a*TI(L))*(exp((a-b)*ts(L))-1))/((a-b)*(1-exp(-b*TI(L))));
            
        elseif (i == num(L,1))
            PDO_CID1(i+1,L)=b*exp(-a*(i)*TI(L))*(exp((a-b)*ts(L))-1)/((a-b)*(1-exp(-b*TI(L))));
            
        else
            PDO_CID1(i+1,L)=b*exp(-a*(i)*TI(L))*(1-exp(-a*TI(L)))*(exp((a-b)*ts(L))-1)/((a-b)*(1-exp(-b*TI(L))));
            
        end
        
    end
end

PDO_CID2=zeros(max(num)+2,length(TI));

for L=1:length(TI)
    for i=0:num(L,1)+1
        if i == 0
            PDO_CID2(i+1,L)=((a-b)*(exp(-b*ts(L))-exp(-b*TI(L))) - b*exp(-a*TI(L))*(exp((a-b)*TI(L))-exp((a-b)*ts(L))))/((a-b)*(1-exp(-b*TI(L))));
            
        elseif (i == num(L,1)+1)
            PDO_CID2(i+1,L)=b*exp(-a*(i)*TI(L))*(exp((a-b)*TI(L))-exp((a-b)*ts(L)))/((a-b)*(1-exp(-b*TI(L))));
        else
            PDO_CID2(i+1,L)=b*exp(-a*(i)*TI(L))*(1-exp(-a*TI(L)))*(exp((a-b)*TI(L))-exp((a-b)*ts(L)))/((a-b)*(1-exp(-b*TI(L))));
            
        end
        
    end
end

PD_CID=zeros(1,length(TI)); %%%%%%%%%%%%%%%% PD_IMD

for L=1:length(TI)
    PD_CID(1,L) = sum(PDO_CID1(:,L).*Pd(:,1))+sum(PDO_CID2(:,L).*Pd2(:,1));    
end

PD=zeros(1,length(TI)); %%%%%%%%%%%%%%%%% PD
for L=1:length(TI)
    PD(1,L)=(PH1*(1-pd)*PD_IMD(L,1).'+PH0*(1-pf)*PD_CID(1,L))/(PH1*(1-pd)+PH0*(1-pf));
end




RO_TI=zeros(1,length(TI));
R1_TI=zeros(1,length(TI));
R_TI=zeros(1,length(TI)); %%%%%%%%%%%%%%%% �־��� pd, pf, Ts => TI�� ���� R
for L=1:length(TI)
    R0_TI(1,L)=(TI(L,1)-Ts)/TI(L,1)*(1-0.1297)*6.6582;
    R1_TI(1,L)=(TI(L,1)-Ts)/TI(L,1)*(1-0.9)*6.6137;
    R_TI(1,L)=PH1*R1_TI(1,L)+PH0*R0_TI(1,L);
    R_TI(1,L)=R_TI(1,L)/5;
end

IDLE00=zeros(1,length(TI)); % (TI-TS) 
IDLE01=zeros(1,length(TI));
BUSY00=zeros(1,length(TI));
IDLE01=zeros(1,length(TI));
IDLE00_TI=zeros(1,length(TI));
IDLE01_TI=zeros(1,length(TI));
BUSY00_TI=zeros(1,length(TI));
BUSY01_TI=zeros(1,length(TI)); 

I=zeros(1,length(TI)); %%%%%%%%%%%%% �־��� pd, pf, Ts => TI�� ���� I
for L=1:length(TI)  
    IDLE00=(TI(L)-Ts) - PH1*( (TI(L)-Ts) + (exp(-(a+b)*(TI(L)-Ts))-1)*(a+b)^(-1) );        
    IDLE01=PH0 * ( (TI(L)-Ts) + (exp(-(a+b)*(TI(L)-Ts))-1) * (a+b)^(-1) );
    BUSY00=(TI(L)-Ts)-IDLE00;       
    BUSY01=(TI(L)-Ts)-IDLE01;       
    IDLE00_TI=TI(L) - PH1*( TI(L) + (exp(-(a+b)*TI(L))-1)*(a+b)^(-1) );     
    BUSY00_TI=TI(L)-IDLE00_TI;       
    IDLE01_TI=PH0*(TI(L) +(exp(-(a+b)*TI(L))-1) * (a+b)^(-1));  
    BUSY01_TI=TI(L)-IDLE01_TI;   
    
    I(L)=( PH0*(1-pf)*BUSY00 + PH1*(1-pd)*BUSY01 ) / ( PH0*BUSY00_TI + PH1*BUSY01_TI );
end

for L=1:length(TI)
    if (PD(L)-TBDP)>0.00005
        e_PD=L;
        PD_req_TI=TI(L);
    end
end

for L=1:length(TI)
    if (IR-I(L))>0.00005
        e_I=L;
    end
end


if e_PD<e_I % e_PD �� e_I �� �� ������ = e_min 
    e_min=e_PD;
else
    e_min=e_I;
end

max_R=0; % 1~ e_min ���� �߿��� R�� �ִ밡 �Ǵ� Lã�� => TI(L)=Optimal_TI(f,j)
for L=1:e_min
    if max_R<R_TI(L)
        max_R=R_TI(L);
        m_index=L;
        OPTIMALTI=TI(L);      %    OPTIMAL�� SENSING INTERVAL 
    end
end

OPTIMALTBDP = PD(1,L);  %   optimal�� TBDP
OPTIMALIR = I(1,L);     %   optimal�� IR
OPTIMALTH = R_TI(1,L);  %    OPTIMAL�� THROUGHPUT 

set(handles.text_tit,'string',num2str(TTIT));
set(handles.text_optimal,'string',num2str(OPTIMALTI));
set(handles.text_tbdp,'string',num2str(OPTIMALTBDP));
set(handles.text_ir,'string',num2str(OPTIMALIR));
set(handles.text_throughput,'string',num2str(OPTIMALTH ));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%% pulse plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
index_TI=round(OPTIMALTI*10^4);
index_Ts=round(Ts*10^4);
index_total=round(index_TI*13);
total=zeros(1,index_total);

for w=1:13
    for s=(index_TI)*(w-1)+1 : (index_TI)*(w-1)+1+index_Ts
        total(s)=1;    
    end
end

pulsex=10^(-4):10^(-4):(index_total)*10^(-4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UIWAIT makes gui_intervaldecision wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%TBDP
axes(handles.axes_tbdp)
cla;
plot(TI,PD,'b'); hold on;
plot(TI,TBDP);
ylabel('TBDP');

%IR
axes(handles.axes_ir);
cla;
plot(TI,I,'m'); hold on;
plot(TI,IR);
axis([0 0.1 0 0.2]);
ylabel('IR');

%Throuput
axes(handles.axes_throughput)
cla;
plot(TI,R_TI,'g');
axis([0 0.1 0 1]);
ylabel('Throughput');
xlabel('Sensing Interval');

% pulse
axes(handles.axes_pulse)
stairs(pulsex,total) % axes_ pulse ?????
axis([0 0.15 0 1.1])
% title('Sensing Time=0.01sec�� �� Optimal�� Sensing Interval')
T=['Ts=' num2str(Ts)]; text(0.025, 1, T);
S=['TI*=' num2str(OPTIMALTI)]; text(0.025, 0.85, S);

% Ÿ��Ʋ�׸�
axes(handles.axes_title)
Aim=imread('title_interval.jpg','jpg');
imshow(Aim);

% --- Outputs from this function are returned to the command line.
function varargout = gui_intervaldecision_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%% BUTTON %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Pushbotton_ok.
function Pushbotton_ok_Callback(hObject, eventdata, handles)
% hObject    handle to Pushbotton_ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%========== file open ===================%
data =importdata('data.txt');
user_type=data(1);            %radio
noise_type=data(2);           %radio
algorithm=data(3);            %radio
sampling_freq=data(4);        %edit
primary_active=data(5);       %edit PH1
target=data(6);               %edit
primary_network=data(7);      %edit Target SNR 
second_network=data(8);       %edit
frame=data(9);                %edit
detection_time=data(10);       %edit
simulate_no=data(11);          %popup
alpha = data(12);       %edit
beta = data(13);        %edit
tbdp =  data(14);       %edit
tit =  data(15);        %edit
ir =  data(16);         %edit
%========== file open ===================%
pd_str = get(handles.edit_pd,'string'); % ó���� 0.9��, 4��° â������ �Է� �� reset �� �� �ֵ��� 
pd = str2num(pd_str);
pf_str = get(handles.edit_pf,'string'); % ó���� 0.1��, 4��° â������ �Է� �� reset �� �� �ֵ��� 
pf = str2num(pf_str);
PH1 = primary_active; % Main â���� �Է�
PH0 = 1-PH1;
a_str = get(handles.edit_alpha,'string');
a = str2num(a_str); % alpha Main â���� �Է� , 4��°â������ �Է� �� reset �� �� �ֵ���  
b_str = get(handles.edit_beta,'string');
b = str2num(b_str); % beta Main â���� �Է� , 4��°â������ �Է� �� reset �� �� �ֵ���  
TTIT = (1/10)*(1/a); % Mainâ���� �⺻�� 0.3 , 4��° â���� alpha �ٲ㼭 reset �ϸ� ���ǵ��� 
d = 0.0001; % ��� interval����
TBDP_str = get(handles.edit_tbdp,'string');
TBDP = str2num(TBDP_str); % Main â���� �⺻�� 0.9 
IR_str = get(handles.edit_ir,'string');
IR = str2num(IR_str); % Main â���� �⺻�� 0.1

error = 0;
%�����޼���
if ( pd < 0.9 | pd > 0.99)
    errordlg('Please insert pd value from 0.9 to 0.99','Input error');
    error = 1;
elseif ( pf < 0.01 | pf > 0.49)
    errordlg('Please insert pf value from 0.01 to 0.49','Input error');
    error = 1;
end

if error==0
%================== sensing time ��� =====================%
v_dB = primary_network; % Mainâ���� Target SNR �� �Է¹޴� ���� �������� 
v=10^(v_dB/10);
C0= log2(1+v); C1=log2(1+(v/(1+v)));
fs=sampling_freq*10^6; % Mainâ���� sampling freq �� �Է¹޴� ���� ������ 

N_min=zeros(length(pf),length(pd));
Optimal_Ts=zeros(length(pf),length(pd));
N_min=(1/v^2).*(qfuncinv(pf)-qfuncinv(pd).*(2*v+1)^1/2).^2;
Ts=N_min/fs; % sensing time
set(handles.text_sensingtime,'string',num2str(Ts*1000));
%==========================================================%


TI=[Ts:d:TTIT].';

num=zeros(length(TI),1);
for L=1:length(TI)
    num(L,1)=floor(TTIT/TI(L));
end

Pd=zeros(max(num)+1,1); %%%%%%%%%%%%%%%% Pd
for i=0:max(num)
    Pd(i+1,1)=1-(1-pd)^(i);
end

Pd2=zeros(max(num)+2,1); %%%%%%%%%%%%%%%% Pd2
for i=0:max(num)+1
    Pd2(i+1,1)=1-(1-pd)^(i);
end

PDO_IMD=zeros(length(TI),max(num)); %%%%%%%%%%%%%%%% PDO_IMD
for L=1:length(TI)
    for i=0:num(L,1)
        if i==num(L,1)
            PDO_IMD(L,i+1)=exp((-a)*(i)*TI(L,1));
        else
            PDO_IMD(L,i+1)=(exp((-a)*(i)*TI(L,1))-exp((-a)*(i+1)*TI(L,1)));
        end
    end   
end

PD_IMD=zeros(length(TI),1); %%%%%%%%%%%%%%%% PD_IMD
for L=1:length(TI)
    PD_IMD(L,1) = sum(PDO_IMD(L,:).*Pd(:,1).');    
end

ts=zeros(1,length(TI));
for L=1:length(TI)
    ts(1,L)=((num(L,1)+1)*(TI(L,1)))-TTIT;
end

PDO_CID1=zeros(max(num)+1,length(TI)); %%%%%%%%%%%%%%%% PDO_CID

for L=1:length(TI)
    for i=0:num(L,1)
        if i == 0
            PDO_CID1(i+1,L)=((a-b)*(1-exp(-b*ts(L))) - b*exp(-a*TI(L))*(exp((a-b)*ts(L))-1))/((a-b)*(1-exp(-b*TI(L))));
            
        elseif (i == num(L,1))
            PDO_CID1(i+1,L)=b*exp(-a*(i)*TI(L))*(exp((a-b)*ts(L))-1)/((a-b)*(1-exp(-b*TI(L))));
            
        else
            PDO_CID1(i+1,L)=b*exp(-a*(i)*TI(L))*(1-exp(-a*TI(L)))*(exp((a-b)*ts(L))-1)/((a-b)*(1-exp(-b*TI(L))));
            
        end
        
    end
end

PDO_CID2=zeros(max(num)+2,length(TI));

for L=1:length(TI)
    for i=0:num(L,1)+1
        if i == 0
            PDO_CID2(i+1,L)=((a-b)*(exp(-b*ts(L))-exp(-b*TI(L))) - b*exp(-a*TI(L))*(exp((a-b)*TI(L))-exp((a-b)*ts(L))))/((a-b)*(1-exp(-b*TI(L))));
            
        elseif (i == num(L,1)+1)
            PDO_CID2(i+1,L)=b*exp(-a*(i)*TI(L))*(exp((a-b)*TI(L))-exp((a-b)*ts(L)))/((a-b)*(1-exp(-b*TI(L))));
        else
            PDO_CID2(i+1,L)=b*exp(-a*(i)*TI(L))*(1-exp(-a*TI(L)))*(exp((a-b)*TI(L))-exp((a-b)*ts(L)))/((a-b)*(1-exp(-b*TI(L))));
            
        end
        
    end
end

PD_CID=zeros(1,length(TI)); %%%%%%%%%%%%%%%% PD_IMD

for L=1:length(TI)
    PD_CID(1,L) = sum(PDO_CID1(:,L).*Pd(:,1))+sum(PDO_CID2(:,L).*Pd2(:,1));    
end

PD=zeros(1,length(TI)); %%%%%%%%%%%%%%%%% PD
for L=1:length(TI)
    PD(1,L)=(PH1*(1-pd)*PD_IMD(L,1).'+PH0*(1-pf)*PD_CID(1,L))/(PH1*(1-pd)+PH0*(1-pf));
end




RO_TI=zeros(1,length(TI));
R1_TI=zeros(1,length(TI));
R_TI=zeros(1,length(TI)); %%%%%%%%%%%%%%%% �־��� pd, pf, Ts => TI�� ���� R
for L=1:length(TI)
    R0_TI(1,L)=(TI(L,1)-Ts)/TI(L,1)*(1-0.1297)*6.6582;
    R1_TI(1,L)=(TI(L,1)-Ts)/TI(L,1)*(1-0.9)*6.6137;
    R_TI(1,L)=PH1*R1_TI(1,L)+PH0*R0_TI(1,L);
    R_TI(1,L)=R_TI(1,L)/5;
end

IDLE00=zeros(1,length(TI)); % (TI-TS) 
IDLE01=zeros(1,length(TI));
BUSY00=zeros(1,length(TI));
IDLE01=zeros(1,length(TI));
IDLE00_TI=zeros(1,length(TI));
IDLE01_TI=zeros(1,length(TI));
BUSY00_TI=zeros(1,length(TI));
BUSY01_TI=zeros(1,length(TI)); 

I=zeros(1,length(TI)); %%%%%%%%%%%%% �־��� pd, pf, Ts => TI�� ���� I
for L=1:length(TI)  
    IDLE00=(TI(L)-Ts) - PH1*( (TI(L)-Ts) + (exp(-(a+b)*(TI(L)-Ts))-1)*(a+b)^(-1) );        
    IDLE01=PH0 * ( (TI(L)-Ts) + (exp(-(a+b)*(TI(L)-Ts))-1) * (a+b)^(-1) );
    BUSY00=(TI(L)-Ts)-IDLE00;       
    BUSY01=(TI(L)-Ts)-IDLE01;       
    IDLE00_TI=TI(L) - PH1*( TI(L) + (exp(-(a+b)*TI(L))-1)*(a+b)^(-1) );     
    BUSY00_TI=TI(L)-IDLE00_TI;       
    IDLE01_TI=PH0*(TI(L) +(exp(-(a+b)*TI(L))-1) * (a+b)^(-1));  
    BUSY01_TI=TI(L)-IDLE01_TI;   
    
    I(L)=( PH0*(1-pf)*BUSY00 + PH1*(1-pd)*BUSY01 ) / ( PH0*BUSY00_TI + PH1*BUSY01_TI );
end

for L=1:length(TI)
    if (PD(L)-TBDP)>0.00005
        e_PD=L;
        PD_req_TI=TI(L);
    end
end

for L=1:length(TI)
    if (IR-I(L))>0.00005
        e_I=L;
    end
end


if e_PD<e_I % e_PD �� e_I �� �� ������ = e_min 
    e_min=e_PD;
else
    e_min=e_I;
end

max_R=0; % 1~ e_min ���� �߿��� R�� �ִ밡 �Ǵ� Lã�� => TI(L)=Optimal_TI(f,j)
for L=1:e_min
    if max_R<R_TI(L)
        max_R=R_TI(L);
        m_index=L;
        OPTIMALTI=TI(L);      %    OPTIMAL�� SENSING INTERVAL 
    end
end

OPTIMALTBDP = PD(1,L);  %   optimal�� TBDP
OPTIMALIR = I(1,L);     %   optimal�� IR
OPTIMALTH = R_TI(1,L);  %    OPTIMAL�� THROUGHPUT 

set(handles.text_tit,'string',num2str(TTIT));
set(handles.text_optimal,'string',num2str(OPTIMALTI));
set(handles.text_tbdp,'string',num2str(OPTIMALTBDP));
set(handles.text_ir,'string',num2str(OPTIMALIR));
set(handles.text_throughput,'string',num2str(OPTIMALTH ));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%% pulse plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
index_TI=round(OPTIMALTI*10^4);
index_Ts=round(Ts*10^4);
index_total=round(index_TI*13);
total=zeros(1,index_total);

for w=1:13
    for s=(index_TI)*(w-1)+1 : (index_TI)*(w-1)+1+index_Ts
        total(s)=1;    
    end
end

pulsex=10^(-4):10^(-4):(index_total)*10^(-4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UIWAIT makes gui_intervaldecision wait for user response (see UIRESUME)
% uiwait(handles.figure1);


%TBDP
axes(handles.axes_tbdp)
cla;
plot(TI,PD,'b'); hold on;
plot(TI,TBDP);
ylabel('TBDP');

%IR
axes(handles.axes_ir);
cla;
plot(TI,I,'m'); hold on;
plot(TI,IR);
axis([0 0.1 0 0.2]);
ylabel('IR');

%Throuput
axes(handles.axes_throughput)
cla;
plot(TI,R_TI,'g');
axis([0 0.1 0 1]);
ylabel('Throughput');
xlabel('Sensing Interval');

% pulse
axes(handles.axes_pulse)
cla;
stairs(pulsex,total) % axes_ pulse ?????
axis([0 0.15 0 1.1])
xlabel('(sec)'); 
% title('Sensing Time=0.01sec�� �� Optimal�� Sensing Interval')
T=['Ts=' num2str(Ts)]; text(0.025, 1, T);
S=['TI*=' num2str(OPTIMALTI)]; text(0.025, 0.85, S);

end %error if

% --- Executes on button press in pushbutton_reset.
function pushbutton_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit_tbdp,'string',0.9);
set(handles.edit_ir,'string',0.1);
set(handles.edit_alpha,'string',0.3);
set(handles.edit_beta,'string',0.2);
set(handles.edit_pd,'string',0.9);
set(handles.edit_pf,'string',0.1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%% BUTTON %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%% EDIT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function edit_alpha_Callback(hObject, eventdata, handles)
% hObject    handle to edit_alpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_alpha as text
%        str2double(get(hObject,'String')) returns contents of edit_alpha as a double


% --- Executes during object creation, after setting all properties.
function edit_alpha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_alpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_beta_Callback(hObject, eventdata, handles)
% hObject    handle to edit_beta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_beta as text
%        str2double(get(hObject,'String')) returns contents of edit_beta as a double


% --- Executes during object creation, after setting all properties.
function edit_beta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_beta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_pd_Callback(hObject, eventdata, handles)
% hObject    handle to edit_pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_pd as text
%        str2double(get(hObject,'String')) returns contents of edit_pd as a double


% --- Executes during object creation, after setting all properties.
function edit_pd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_pf_Callback(hObject, eventdata, handles)
% hObject    handle to edit_pf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_pf as text
%        str2double(get(hObject,'String')) returns contents of edit_pf as a double


% --- Executes during object creation, after setting all properties.
function edit_pf_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_pf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%% EDIT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
